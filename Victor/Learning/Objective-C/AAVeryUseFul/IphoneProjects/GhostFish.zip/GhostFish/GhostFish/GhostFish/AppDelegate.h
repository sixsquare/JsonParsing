//
//  AppDelegate.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContainerViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow                  *window;
@property (strong, nonatomic) UINavigationController    *nav_;
@property (strong, nonatomic) ContainerViewController   *container_;

@end
