//
//  ChatRoomViewController.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSMessageInputView.h"
#import <MessageUI/MessageUI.h>

@interface ChatRoomViewController : UIViewController<UITextViewDelegate, JSDismissiveTextViewDelegate, UITableViewDataSource, UITableViewDelegate, UIActionSheetDelegate, MFMailComposeViewControllerDelegate, MFMessageComposeViewControllerDelegate> {
    UIEdgeInsets originalTableViewContentInset_;
    BOOL         teamsViewShown_;
    CGFloat      progressFinalWidth_;
    
    BOOL         messageSending_;
    BOOL         sendingProgressing_;
    
    BOOL         reloading_;
    BOOL         reloadProgressing_;
    CGFloat      tableViewContentInsetTop_;
    
    BOOL          shouldReload_;
    BOOL          refreshing_;
    
@public
    int           roomCharacterLimit_;
    int           roomLimistSecond_;
}

@property (weak, nonatomic) IBOutlet JSMessageInputView *inputView_;
@property (weak, nonatomic) IBOutlet UIView *containerView_;
@property (weak, nonatomic) IBOutlet UITableView *tableViewMain_;
@property (assign, nonatomic) CGFloat previousTextViewContentHeight;
@property (strong, nonatomic) IBOutlet UIView *viewTeams_;
@property (strong, nonatomic) NSMutableDictionary *roomDict_;
@property (strong, nonatomic) IBOutlet UILabel *labelTeamA_;
@property (strong, nonatomic) IBOutlet UILabel *labelTeamB_;

@property (strong, nonatomic) UIImageView *progressView_;
@property (strong, nonatomic) UIActivityIndicatorView *progressIndicator_;

@property (strong, nonatomic) NSMutableArray *messages_;

//- (NSMutableDictionary*)callbackIds;
//- (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
//- (void)cancelAllLocalNotifications:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;
//- (NSMutableArray*)pendingNotifications;
//- (void)registerDevice:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;
//- (void)didFailToRegisterForRemoteNotificationsWithError:(NSError*)error;
//- (void)didReceiveRemoteNotification:(NSDictionary*)userInfo;
//- (void)getPendingNotifications:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;
//+ (NSMutableDictionary*)getRemoteNotificationStatus;
//- (void)getRemoteNotificationStatus:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;

@end
