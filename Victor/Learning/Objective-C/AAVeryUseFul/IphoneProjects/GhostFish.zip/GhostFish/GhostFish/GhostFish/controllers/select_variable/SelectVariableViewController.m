//
//  SelectVariableViewController.m
//  GhostFish
//
//  Created by Mountain on 11/29/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "SelectVariableViewController.h"
#import "MainMenuViewController.h"
#import "SettingViewController.h"
#import "ContainerViewController.h"

@interface SelectVariableViewController ()

@end

@implementation SelectVariableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.navigationBarHidden = NO;
    
    self.title = @"Choose Team";
    
    if (!self.canGoBack_) {
        UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                  style:UIBarButtonItemStyleBordered
                                                                 target:self
                                                                 action:@selector(onDone:)];
        self.navigationItem.rightBarButtonItem = barButton;
        self.navigationItem.hidesBackButton = YES;
    } else {
        
    }

    self.imageViewCheckMark1_.hidden = YES;
    self.imageViewCheckMark2_.hidden = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction) onDone:(id)sender {
    MainMenuViewController *controller2 = [[MainMenuViewController alloc] initWithNibName:@"MainMenuViewController" bundle:nil];
    SettingViewController *controller3 = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:nil];
    
    ContainerViewController *container = [[ContainerViewController alloc] init];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:controller2];
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:controller3];
    
    nav2.navigationBarHidden = YES;
    self.navigationController.navigationBarHidden = YES;
    
    APP_DELEGATE.container_ = container;
    
    container.viewControllers = [NSArray arrayWithObjects:nav2, nav3, nil];
    
    [container addCustomTab];
    [self.navigationController pushViewController:container animated:YES];
}

- (IBAction)onChooseVariableX:(id)sender {
    [self chooseVariable:0];
}

- (IBAction)onChooseVariableY:(id)sender {
    [self chooseVariable:1];
}

- (void) chooseVariable:(int)idx {
    if (idx == 0) {
        self.imageViewCheckMark1_.hidden = NO;
        self.imageViewCheckMark2_.hidden = YES;
    } else {
        self.imageViewCheckMark1_.hidden = YES;
        self.imageViewCheckMark2_.hidden = NO;
    }
}

#pragma mark UITableView method
-(int)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 5;
}

-(int)numberOfSectionsInTableView:(UITableView *)tableView {
    return 6;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"Team-%d", indexPath.row + 1];
    
    if (selectedCategory_ == indexPath.section && selectedTeam_ == indexPath.row) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 
    selectedCategory_ = indexPath.section;
    selectedTeam_ = indexPath.row;
    [tableView reloadData];
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return [NSString stringWithFormat:@"Category - %d", section + 1];
}

-(void) reloadTable:(UITableView *)tableView {
    [tableView reloadData];
}

@end