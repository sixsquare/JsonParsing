//
//  RegisterViewController.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "PECropViewController.h"

@interface RegisterViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate, PECropViewControllerDelegate, UIActionSheetDelegate>

@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollViewMain_;
@property (weak, nonatomic) IBOutlet UITextField *textFieldUserName_;
@property (weak, nonatomic) IBOutlet UITextField *textFieldEmail_;
@property (weak, nonatomic) IBOutlet UITextField *textFieldPassword_;
@property (weak, nonatomic) IBOutlet UITextField *textFieldConfirmPassword_;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewProfilePhotoView_;

@property (strong, nonatomic) UIImage *profilePhoto_;

- (IBAction)onChoosePhoto:(id)sender;

@end
