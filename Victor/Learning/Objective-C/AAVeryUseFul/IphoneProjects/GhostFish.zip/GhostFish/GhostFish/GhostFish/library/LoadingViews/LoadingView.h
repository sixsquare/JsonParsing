//
//  MRLoadingView.h
//  mathruzzle
//
//  Created by Mountain on 1/3/13.
//  Copyright (c) 2013 chinasoft.dk. All rights reserved.
//

#import <UIKit/UIKit.h>

#define LOADING_VIEW_WIDTH      237
#define LOADING_VIEW_HEIGHT     111
#define LOADING_MESSAGE_FONT    20

@interface LoadingView : UIView {
    BOOL animating;
}

@property (nonatomic, strong) UIImageView *_spinnerView;

-(id) initWithText:(NSString *)text frame:(CGRect)frame;

@end
