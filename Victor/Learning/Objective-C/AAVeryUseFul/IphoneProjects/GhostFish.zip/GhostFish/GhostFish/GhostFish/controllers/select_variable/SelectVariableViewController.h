//
//  SelectVariableViewController.h
//  GhostFish
//
//  Created by Mountain on 11/29/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectVariableViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    int     selectedCategory_;
    int     selectedTeam_;
    int    expandedSection_;
}

@property (weak, nonatomic) IBOutlet UIImageView *imageViewCheckMark1_;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewCheckMark2_;
@property (readwrite, nonatomic) BOOL canGoBack_;

- (IBAction)onChooseVariableX:(id)sender;
- (IBAction)onChooseVariableY:(id)sender;

@end
