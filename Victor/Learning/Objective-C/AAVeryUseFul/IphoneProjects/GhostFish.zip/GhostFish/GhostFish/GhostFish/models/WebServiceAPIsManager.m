//
//  WebServiceAPIsManager.m
//  GhostFish
//
//  Created by Mountain on 12/5/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "WebServiceAPIsManager.h"
#import "SBJSON.h"
#import "SBJsonParser.h"
#import "SBJsonWriter.h"
#import "DataManager.h"

@implementation WebServiceAPIsManager

static WebServiceAPIsManager *instance;

+(WebServiceAPIsManager *) sharedInstance {
    if (instance == nil) {
        instance = [WebServiceAPIsManager new];
    }
    
    return instance;
}

+ (NSMutableDictionary*) dictFromJson: (NSString*) jsonString
{
    SBJsonParser* parser = [SBJsonParser new];
    NSMutableDictionary* retDict = [parser objectWithString: jsonString];
    return retDict;
}

- (void)appendFileToBody:(NSMutableData *)data filenamekey:(NSString*)filenamekey filenamevalue:(NSString*)filenamevalue filedata:(NSData*)filedata {
    NSString *multipartBoundary = @"---------------------------14737809831466499882746641449";
    [data appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n", multipartBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [data appendData:[[NSString stringWithString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n", filenamekey, filenamevalue]] dataUsingEncoding:NSUTF8StringEncoding]];
    [data appendData:[@"Content-type: application/octet-stream\r\n\r\n" dataUsingEncoding: NSUTF8StringEncoding]];
    [data appendData:filedata];
    [data appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", multipartBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
}

- (NSString*)sendMultipartRequest:(NSString *)strService data:(NSData *)data
{
    NSString *multipartBoundary = @"---------------------------14737809831466499882746641449";
    NSMutableString *strURL = [NSMutableString stringWithString:strService];
    
    NSURL *url = [NSURL URLWithString:strURL];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", multipartBoundary];
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:data];
    
    NSError *error;
    NSURLResponse *response;
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    if (!response) {
        NSLog(@"%@", [error description]);
        return @"Error";
    }
    
    NSString *respString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    
    return [respString stringByReplacingOccurrencesOfString:SPECIAL_CHAR_AMP withString:@"&"];
}

- (NSData *)makeMultipartBody:(NSMutableDictionary*)dic {
    
    NSString *multipartBoundary = @"---------------------------14737809831466499882746641449";
    NSMutableData *data = [NSMutableData data];
    
    for (NSString *key in dic) {
        NSString *value = [dic objectForKey:key];
        
        if ([value rangeOfString:@"\\&"].location != NSNotFound)
            NSLog(@"%@", value);
        
        value = [value stringByReplacingOccurrencesOfString:@"\\&" withString:SPECIAL_CHAR_AMP];
        
        if ([value rangeOfString:SPECIAL_CHAR_AMP].location != NSNotFound)
            NSLog(@"%@", value);
        
        // set boundary
        [data appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n", multipartBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
        
        //        if ([value containsEmojiSymbol]) {
        //            [data appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n%@", key, value] dataUsingEncoding:NSNonLossyASCIIStringEncoding]];
        //        } else {
        [data appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n%@", key, value] dataUsingEncoding:NSUTF8StringEncoding]];
        //        }
    }
    
    [data appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n", multipartBoundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    return data;
}

/*
 *****************************************************************************
 */

-(NSMutableDictionary *) registerWithUserName:(NSString *)userName
                       email:(NSString *)email
                    password:(NSString *)password
                    nickName:(NSString *)nickName
                profilePhoto:(UIImage *)profilePhoto {
    
    NSString* url = FEED_USER_REGISTER;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"email", @"password", @"user_name", @"nick_name", @"device_type", @"device_token", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:email, password, userName, nickName, @"0", [DataManager sharedInstance].deviceToken_, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSData *imageData;
    
    if (profilePhoto != nil) {
        imageData = UIImageJPEGRepresentation(profilePhoto, 90);
        [self appendFileToBody:body filenamekey:@"userfile" filenamevalue:[NSString stringWithFormat:@"%@%.0f.jpg", @"fromiOS_profile_photo", [[NSDate date] timeIntervalSince1970]] filedata:imageData];
    }
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) loginWithUserName:(NSString *)userName
                 password:(NSString *)password {
    NSString* url = FEED_USER_LOGIN;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"email", @"password", @"device_type", @"device_token", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userName, password, @"0", [DataManager sharedInstance].deviceToken_, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) userLogout:(NSString *)userId {
    NSString* url = FEED_USER_LOGOUT;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", @"device_type", @"device_token", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, @"0", [DataManager sharedInstance].deviceToken_,nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) userProfile:(NSString *)userId {
    NSString* url = FEED_USER_PROFILE;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) updatePofile:(NSString *)userId
                             userName:(NSString *)userName
                                email:(NSString *)email
                             password:(NSString *)password
                            userPhoto:(UIImage *)userPhoto {
    NSString* url = FEED_UPDATE_PROFILE;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", @"user_name", @"email", @"password", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, userName, email, password, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSData *imageData;
    
    if (userPhoto != nil) {
        imageData = UIImageJPEGRepresentation(userPhoto, 90);
        [self appendFileToBody:body filenamekey:@"userfile" filenamevalue:[NSString stringWithFormat:@"%@%.0f.jpg", @"fromiOS_profile_photo", [[NSDate date] timeIntervalSince1970]] filedata:imageData];
    }

    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) allTeams {
    NSString* url = FEED_ALL_TEAMS;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) chooseTeamForUser:(NSString *)userId catId:(NSString *)catId teamId:(NSString *)teamId {
    NSString* url = FEED_CHOOSE_TEAM;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", @"cat_id", @"team_id", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, catId, teamId, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableArray *) openGamesForUser:(NSString *)userId {
    return nil;
}

-(NSMutableDictionary *) openRoomsForUser:(NSString *)userId {
    NSString* url = FEED_OPEN_ROOMS;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) myTeams:(NSString *)userId {
    NSString* url = FEED_MY_TEAMS;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) enterRoom:(NSString *)userId roomId:(NSString *)roomId {
    NSString* url = FEED_ENTER_ROOM;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", @"room_id", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, roomId, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) exitRoom:(NSString *)userId roomId:(NSString *)roomId {
    NSString* url = FEED_EXIT_ROOM;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"user_id", @"room_id", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:userId, roomId, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) sendMessage:(NSString *)fromUId roomId:(NSString *)roomId message:(NSString *)message {
    NSString* url = FEED_SEND_MESSAGE;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"from_uid", @"room_id", @"message", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:fromUId, roomId, message, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

-(NSMutableDictionary *) messages:(NSString *)roomId sessionStart:(NSString *)sessionStart {
    NSString* url = FEED_MESSAGES;
    
    NSMutableData *body;
    NSArray *paramNames = [NSArray arrayWithObjects:@"room_id", @"session_start", nil];
    
    NSArray *paramDatas = [NSArray arrayWithObjects:roomId, sessionStart, nil];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjects:paramDatas forKeys:paramNames];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"api call : url - %@ , params - %@", url, dict);
#endif
    
    body = [NSMutableData dataWithData: [self makeMultipartBody:dict]];
    
    NSString *resultString = [self sendMultipartRequest:url data:body];
    
#ifdef DEV_ENVIRONMENT
    NSLog(@"response - %@", resultString);
#endif
    
    NSMutableDictionary *resultDict = [WebServiceAPIsManager dictFromJson:resultString];
    return [resultDict safeDictionaryForKey:@"results"];
}

@end
