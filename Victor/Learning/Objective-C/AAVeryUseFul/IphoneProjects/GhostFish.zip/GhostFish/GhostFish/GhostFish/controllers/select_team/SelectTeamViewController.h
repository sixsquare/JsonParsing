//
//  SelectVariableViewController.h
//  GhostFish
//
//  Created by Mountain on 11/29/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TeamCell.h"

@interface SelectTeamViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, TeamCellDelegate>  {
    int selectedCategoryIdx_;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewMain_;

@property (readwrite, nonatomic) BOOL canGoBack_;
@property (strong, nonatomic) NSMutableArray *allTeams_;
@property (strong, nonatomic) NSMutableArray *myTeams_;

@end
