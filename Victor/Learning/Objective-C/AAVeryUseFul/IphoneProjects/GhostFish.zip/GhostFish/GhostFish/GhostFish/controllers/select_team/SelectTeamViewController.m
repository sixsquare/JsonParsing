//
//  SelectVariableViewController.m
//  GhostFish
//
//  Created by Mountain on 11/29/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "SelectTeamViewController.h"
#import "MainMenuViewController.h"
#import "SettingViewController.h"
#import "ContainerViewController.h"
#import "ActionSheetStringPicker.h"
#import "TeamCell.h"

@interface SelectTeamViewController ()

@end

@implementation SelectTeamViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.navigationBarHidden = NO;
    
    self.title = @"Choose Your Teams";
    
    if (!self.canGoBack_) {
        self.navigationItem.hidesBackButton = YES;
    } else {
        
    }
    
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                  style:UIBarButtonItemStyleBordered
                                                                 target:self
                                                                 action:@selector(onDone:)];
    self.navigationItem.rightBarButtonItem = barButton;
    
    [self loadTeams];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction) onDone:(id)sender {
    [self chooseTeamProcess];
}

#pragma mark load
-(void) loadTeams {
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(teamsLoadThread) toTarget:self withObject:nil];
}

-(void) teamsLoadThread {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] allTeams];
    NSMutableDictionary *myTeams = [[WebServiceAPIsManager sharedInstance] myTeams:[DataManager sharedInstance].currentUserId_];
    
    self.myTeams_ = [myTeams safeArrayForKey:@"value"];
    
    if ([[dict safeStringForKey:@"status"] isEqualToString:@"success"]) {
        self.allTeams_ = [dict safeArrayForKey:@"value"];
        
        for (int idx = 0; idx < self.allTeams_.count; idx++) {
            NSMutableDictionary *dict = [self.allTeams_ objectAtIndex:idx];
            [dict putIntegerValueForKey:@"selected" value:-1];
            
            NSString *catId = [dict safeStringForKey:@"cid"];
            for (int jdx = 0; jdx < self.myTeams_.count; jdx++) {
                if ([[[self.myTeams_ objectAtIndex:jdx] safeStringForKey:@"team_cid"] isEqualToString:catId]) {
                    NSString *selectedTeamId = [[self.myTeams_ objectAtIndex:jdx] safeStringForKey:@"tid"];
                    
                    for (int kdx = 0; kdx < [dict safeArrayForKey:@"teams"].count; kdx++) {
                        if ([[[[dict safeArrayForKey:@"teams"] objectAtIndex:kdx] safeStringForKey:@"tid"] isEqualToString:selectedTeamId]) {
                            [dict putIntegerValueForKey:@"selected" value:kdx];
                            break;
                        }
                    }
                }
            }
        }
        
        [self performSelectorOnMainThread:@selector(teamsLoaded) withObject:nil waitUntilDone:YES];
        
    } else {
        
        [self performSelectorOnMainThread:@selector(loadFailed) withObject:nil waitUntilDone:YES];
        
    }
}

-(void) teamsLoaded {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    [self.tableViewMain_ reloadData];
}

-(void) loadFailed {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
}

#pragma mark UITableView methods
-(int)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allTeams_.count;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [TeamCell height];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TeamCell *cell = [tableView dequeueReusableCellWithIdentifier:[TeamCell reuseIdentifier]];
    if (cell == nil) {
        cell = [[TeamCell alloc] init];
        cell.delegate_ = self;
    }
    
    NSMutableDictionary *team = [self.allTeams_ objectAtIndex:indexPath.row];
    int selectedTeam = [team safeIntegerValueForKey:@"selected"];
    NSMutableArray *teams = [team safeArrayForKey:@"teams"];
    if (selectedTeam == -1)
        [cell configureWithTeamInfo:team selectedTeam:nil];
    else
        [cell configureWithTeamInfo:team selectedTeam:[teams objectAtIndex:selectedTeam]];
    
    return cell;
}


-(void) onChooseTeam:(NSMutableDictionary *)catInfo sender:(id)sender {
    
    NSMutableArray *teamNames = [NSMutableArray new];
    
    NSMutableArray *teams = [catInfo safeArrayForKey:@"teams"];
    
    for (int idx = 0; idx < teams.count; idx++) {
        NSString *team = [[teams objectAtIndex:idx] safeStringForKey:@"team_name"];
        [teamNames addObject:team];
    }
    
    int categoryIdx = -1;
    for (int idx = 0; idx < self.allTeams_.count; idx++) {
        if ([[[self.allTeams_ objectAtIndex:idx] safeStringForKey:@"cid"] isEqualToString:[catInfo safeStringForKey:@"cid"]]) {
            categoryIdx = idx;
            break;
        }
    }
    
    int initialSelection = [[self.allTeams_ objectAtIndex:categoryIdx] safeIntegerValueForKey:@"selected"];
    if (initialSelection == -1) initialSelection = 0;
    
    selectedCategoryIdx_ = categoryIdx;
    
    [ActionSheetStringPicker showPickerWithTitle:@"Choose Team" rows:teamNames initialSelection:initialSelection target:self successAction:@selector(teamSelected:element:) cancelAction:nil origin:sender];

}

-(void) teamSelected:(NSNumber *)selectedIndex element:(id)element {
    [[self.allTeams_ objectAtIndex:selectedCategoryIdx_] putIntegerValueForKey:@"selected" value:[selectedIndex intValue]];
    [self.tableViewMain_ reloadData];
}

-(void) gotoMainMenu {
    MainMenuViewController *controller2 = [[MainMenuViewController alloc] initWithNibName:@"MainMenuViewController" bundle:nil];
    SettingViewController *controller3 = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:nil];
    
    ContainerViewController *container = [[ContainerViewController alloc] init];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:controller2];
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:controller3];
    
    nav2.navigationBarHidden = YES;
    self.navigationController.navigationBarHidden = YES;
    
    APP_DELEGATE.container_ = container;
    
    container.viewControllers = [NSArray arrayWithObjects:nav2, nav3, nil];
    
    [container addCustomTab];
    [self.navigationController pushViewController:container animated:YES];
}

-(void) chooseTeamProcess {
    if (![self teamSelected]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please select at least one team" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(selectTeamProcess) toTarget:self withObject:nil];
}

-(BOOL) teamSelected {
    for (int idx = 0; idx < self.allTeams_.count; idx++) {
        NSMutableDictionary *team = [self.allTeams_ objectAtIndex:idx];
        
        if ([team safeIntegerValueForKey:@"selected"] > -1) {
            return YES;
        }
    }
    
    return NO;
}

-(void) selectTeamProcess {
    for (int idx = 0; idx < self.allTeams_.count; idx++) {
        NSMutableDictionary *team = [self.allTeams_ objectAtIndex:idx];
        
        if ([team safeIntegerValueForKey:@"selected"] > -1) {
            NSMutableDictionary *selectedTeam = [[team safeArrayForKey:@"teams"] objectAtIndex:[team safeIntegerValueForKey:@"selected"]];
            
            NSString *teamId = [selectedTeam safeStringForKey:@"tid"];
            NSString *catId = [team safeStringForKey:@"cid"];
            
            [[WebServiceAPIsManager sharedInstance] chooseTeamForUser:[DataManager sharedInstance].currentUserId_ catId:catId teamId:teamId];
        }
    }

    [self performSelectorOnMainThread:@selector(teamSelectProcessFinished) withObject:nil waitUntilDone:YES];
}

-(void) teamSelectProcessFinished {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    if (!self.canGoBack_) {
        [self gotoMainMenu];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

@end