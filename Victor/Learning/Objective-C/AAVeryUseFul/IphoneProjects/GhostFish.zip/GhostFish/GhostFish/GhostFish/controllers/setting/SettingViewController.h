//
//  SettingViewController.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "PECropViewController.h"

@interface SettingViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate, PECropViewControllerDelegate, UIActionSheetDelegate>

@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollViewMain_;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewProfilePhoto_;
@property (strong, nonatomic) IBOutlet UITextField *textFieldUserName_;
@property (strong, nonatomic) IBOutlet UITextField *textFieldEmail_;
@property (strong, nonatomic) IBOutlet UITextField *textFieldPassword_;
@property (strong, nonatomic) IBOutlet UITextField *textFieldConfirmPassword_;

@property (strong, nonatomic) UIImage *profilePhoto_;


- (IBAction)onChoosePhoto:(id)sender;
- (IBAction)onChooseTeam:(id)sender;


@end
