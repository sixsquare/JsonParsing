//
//  SplashViewController.m
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "SplashViewController.h"
#import "LoginViewController.h"
#import "MainMenuViewController.h"
#import "SettingViewController.h"

@interface SplashViewController ()

@end

@implementation SplashViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if ([[DataManager sharedInstance] userIdSaved]) {
        SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
        [NSThread detachNewThreadSelector:@selector(loadProfile) toTarget:self withObject:nil];
    } else {
        [self performSelector:@selector(gotoLogin) withObject:nil afterDelay:1];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) gotoLogin {
    
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    
    LoginViewController *controller = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
}

-(void) loadProfile {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] userProfile:[DataManager sharedInstance].currentUserId_];
    if ([[dict safeStringForKey:@"status"] isEqualToString:@"success"]) {
        [DataManager sharedInstance].currentUserProfile_ = [dict safeDictionaryForKey:@"value"];
        [self performSelectorOnMainThread:@selector(gotoMainMenu) withObject:nil waitUntilDone:YES];
    } else {
        [self performSelectorOnMainThread:@selector(gotoLogin) withObject:nil waitUntilDone:YES];
    }
}

-(void) gotoMainMenu {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    MainMenuViewController *controller2 = [[MainMenuViewController alloc] initWithNibName:@"MainMenuViewController" bundle:nil];
    SettingViewController *controller3 = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:nil];
    
    ContainerViewController *container = [[ContainerViewController alloc] init];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:controller2];
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:controller3];
    
    nav2.navigationBarHidden = YES;
    self.navigationController.navigationBarHidden = YES;
    
    container.viewControllers = [NSArray arrayWithObjects:nav2, nav3, nil];
    
    APP_DELEGATE.container_ = container;
    
    [container addCustomTab];
    [self.navigationController pushViewController:container animated:YES];
}

@end
