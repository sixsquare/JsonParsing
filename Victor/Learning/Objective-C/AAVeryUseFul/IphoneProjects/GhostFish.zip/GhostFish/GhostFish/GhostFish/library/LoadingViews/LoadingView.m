//
//  MRLoadingView.m
//  mathruzzle
//
//  Created by Mountain on 1/3/13.
//  Copyright (c) 2013 chinasoft.dk. All rights reserved.
//

#import "LoadingView.h"

@implementation LoadingView

@synthesize _spinnerView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:frame];
        imageView.image = [UIImage imageNamed:@"loadingbar.png"];
        [self addSubview:imageView];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(id) initWithText:(NSString *)text frame:(CGRect)frame {
    self = [super initWithFrame:frame];
   
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f];
        
        CGRect imageFrame = CGRectMake((frame.size.width - LOADING_VIEW_WIDTH) / 2, (frame.size.height - LOADING_VIEW_HEIGHT) / 2, LOADING_VIEW_WIDTH, LOADING_VIEW_HEIGHT);
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:imageFrame];
        imageView.image = [UIImage imageNamed:@"loading_bar_bg.png"];
        
        self._spinnerView = [[UIImageView alloc] initWithFrame:CGRectMake((frame.size.width - LOADING_VIEW_WIDTH) / 2 + 98, (frame.size.height - LOADING_VIEW_HEIGHT) / 2 + 22, 36, 36)];
        self._spinnerView.image = [UIImage imageNamed:@"loading_spinner.png"];
        [self addSubview:self._spinnerView];
        
        UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake((frame.size.width - LOADING_VIEW_WIDTH) / 2, (frame.size.height - LOADING_VIEW_HEIGHT) / 2 + 66, LOADING_VIEW_WIDTH, 27)];
        
        messageLabel.text = text;
        messageLabel.textAlignment = NSTextAlignmentCenter;
        messageLabel.font = [UIFont boldSystemFontOfSize:LOADING_MESSAGE_FONT];
        messageLabel.textColor = [UIColor colorWithRed:91 / 255.0f green:89 / 255.0f blue:87 / 255.0f alpha:1];
        messageLabel.shadowColor = [UIColor clearColor];
        messageLabel.backgroundColor = [UIColor clearColor];
        
        animating = NO;
        [self startSpin];
    }
    
    return self;
}

- (void) spinWithOptions: (UIViewAnimationOptions) options {
    // this spin completes 360 degrees every 2 seconds
    [UIView animateWithDuration: 1.2f
                          delay: 0.0f
                        options: options
                     animations: ^{
                         self._spinnerView.transform = CGAffineTransformRotate(self._spinnerView.transform, M_PI / 2);
                     }
                     completion: ^(BOOL finished) {
                         if (finished) {
                             if (animating) {
                                 // if flag still set, keep spinning with constant speed
                                 [self spinWithOptions: UIViewAnimationOptionCurveLinear];
                             } else if (options != UIViewAnimationOptionCurveEaseOut) {
                                 // one last spin, with deceleration
                                 [self spinWithOptions: UIViewAnimationOptionCurveEaseOut];
                             }
                         }
                     }];
}

- (void) startSpin {
    if (!animating) {
        animating = YES;
        [self spinWithOptions: UIViewAnimationOptionCurveEaseIn];
    }
}

- (void) stopSpin {
    // set the flag to stop spinning after one last 90 degree increment
    animating = NO;
}

@end
