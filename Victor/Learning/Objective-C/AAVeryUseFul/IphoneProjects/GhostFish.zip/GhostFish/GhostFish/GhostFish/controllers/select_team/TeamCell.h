//
//  ProfilesGroupCell.h
//  Jurhood
//
//  Created by Mountain on 5/1/13.
//  Copyright (c) 2013 ChinaSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TeamCellDelegate <NSObject>

-(void) onChooseTeam:(NSMutableDictionary *)catInfo sender:(id)sender;

@end

@interface TeamCell : UITableViewCell {
    
}

@property (strong, nonatomic) IBOutlet UIView *content_;
@property (strong, nonatomic) IBOutlet UILabel *labelCategory_;
@property (strong, nonatomic) IBOutlet UIButton *buttonTeam_;
@property (strong, nonatomic) NSMutableDictionary *catInfo_;
@property (weak, nonatomic) id<TeamCellDelegate> delegate_;

+ (NSString *)reuseIdentifier;
+ (CGFloat) height;
- (void) configureWithTeamInfo:(NSMutableDictionary *)catInfo selectedTeam:(NSMutableDictionary *)selectedTeam;

@end
