//
//  DataManager.h
//  Jurhood
//
//  Created by Mountain on 6/6/13.
//  Copyright (c) 2013 ChinaSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataManager : NSObject

@property (nonatomic, strong) NSString *deviceToken_;
@property (nonatomic, strong) NSString *currentUserId_;
@property (nonatomic, strong) NSMutableDictionary *currentUserProfile_;
@property (nonatomic, strong) NSString *currentEnteredRoomId_;

+(DataManager *) sharedInstance;

-(BOOL) userIdSaved;
-(void) saveUserId;
-(void) removeUserId;

@end
