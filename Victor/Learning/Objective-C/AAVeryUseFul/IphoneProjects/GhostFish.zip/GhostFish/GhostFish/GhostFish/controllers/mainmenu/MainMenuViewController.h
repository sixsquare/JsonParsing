//
//  MainMenuViewController.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainMenuViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    BOOL shouldReload_;
    BOOL loading_;
}

- (IBAction)onRoom1:(id)sender;
- (IBAction)onRoom2:(id)sender;

@property (strong, nonatomic) NSMutableArray            *rooms_;
@property (strong, nonatomic) IBOutlet UITableView      *tableViewRooms_;

@end
