//
//  ProfilesGroupCell.h
//  Jurhood
//
//  Created by Mountain on 5/1/13.
//  Copyright (c) 2013 ChinaSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatCell : UITableViewCell {
}

@property (strong, nonatomic) IBOutlet UIView *content_;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewProfilePhoto_;
@property (weak, nonatomic) IBOutlet UILabel *labelUserName_;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewChatBack_;
@property (weak, nonatomic) IBOutlet UITextView *textViewMessage_;
@property (weak, nonatomic) IBOutlet UILabel *labelMessage_;

+ (NSString *)reuseIdentifier;
+ (CGFloat) heightForMessage:(NSString *)message;
- (void) configureWithMessage:(NSString *)message cellType:(int)cellType photoUrl:(NSString *)photoUrl userName:(NSString*)userName;

@end
