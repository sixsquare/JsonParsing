//
//  SplashViewController.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashViewController : UIViewController

@end
