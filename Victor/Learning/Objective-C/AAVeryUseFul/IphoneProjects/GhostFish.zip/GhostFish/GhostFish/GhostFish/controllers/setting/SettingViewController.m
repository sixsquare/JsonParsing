//
//  SettingViewController.m
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "SettingViewController.h"
#import "UIImage+fixOrientation.h"
#import "SelectTeamViewController.h"
#import "LoginViewController.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.scrollViewMain_ contentSizeToFit];
    
    if (IS_OS_7_OR_LATER)
        self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.navigationController.navigationBarHidden = NO;
    
    self.title = @"Settings";
    
    [self setProfiles];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated {
    self.title = @"Settings";
}

- (void) viewWillDisappear:(BOOL)animated {
    self.title = @"";
}

- (IBAction)onSignOut:(id)sender {
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(userLogoutThread) toTarget:self withObject:nil];
}

-(void) userLogoutThread {
    if ([DataManager sharedInstance].currentEnteredRoomId_ != nil) {
        [[WebServiceAPIsManager sharedInstance] exitRoom:[DataManager sharedInstance].currentUserId_ roomId:[DataManager sharedInstance].currentEnteredRoomId_];
    }
    
    [[WebServiceAPIsManager sharedInstance] userLogout:[DataManager sharedInstance].currentUserId_];
    
    [[DataManager sharedInstance] removeUserId];
    
    [self performSelectorOnMainThread:@selector(logoutFinished) withObject:nil waitUntilDone:YES];
}

-(void) logoutFinished {
    
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    
    UINavigationController *parentNav = self.tabBarController.navigationController;
    UIViewController *viewController = [parentNav.viewControllers objectAtIndex:1];
    if ([viewController isKindOfClass:[LoginViewController class]]) {
        [parentNav popToViewController:viewController animated:YES];
    } else {
        LoginViewController *controller = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        NSMutableArray *array = [NSMutableArray arrayWithArray:parentNav.viewControllers];
        [array insertObject:controller atIndex:1];
        parentNav.viewControllers = array;
        [parentNav popToViewController:controller animated:YES];
    }

}

- (IBAction)onUpdateProfile:(id)sender {
    if (![self.textFieldPassword_.text isEqualToString:self.textFieldConfirmPassword_.text]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Password does not match" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    if ([self.textFieldEmail_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter the email address" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    if ([self.textFieldUserName_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter the user name" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(profileUpdateThread) toTarget:self withObject:nil];
}

-(void) profileUpdateThread {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] updatePofile:[DataManager sharedInstance].currentUserId_ userName:self.textFieldUserName_.text email:self.textFieldEmail_.text password:self.textFieldPassword_.text userPhoto:self.profilePhoto_];
    if ([[dict safeStringForKey:@"status"] isEqualToString:@"success"]) {
        [DataManager sharedInstance].currentUserProfile_ = [dict safeDictionaryForKey:@"value"];
        [self performSelectorOnMainThread:@selector(profileUpdated) withObject:nil waitUntilDone:YES];
    } else {
        [self performSelectorOnMainThread:@selector(updateFailed:) withObject:[dict safeStringForKey:@"report"] waitUntilDone:YES];
    }
}

-(void) updateFailed:(NSString *)errorReport {
    
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:errorReport delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
}

-(void) profileUpdated {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
}

#pragma mark profile photo process
- (IBAction)onChoosePhoto:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:_T(@"Cancel") destructiveButtonTitle:_T(@"Camera") otherButtonTitles:_T(@"Photo Library"), _T(@"Saved Album"), nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
}

- (IBAction)onChooseTeam:(id)sender {
    SelectTeamViewController *controller = [[SelectTeamViewController alloc] initWithNibName:@"SelectTeamViewController" bundle:nil];
    controller.canGoBack_ = YES;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if ([_T(@"Camera") isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([_T(@"Photo Library") isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([_T(@"Saved Album") isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerControllerDelegate
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSMutableDictionary *)info {
    UIImage *originalImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
#ifdef DEV_ENVIRONMENT
    NSLog (@"Image Size, %f, %f", originalImage.size.width, originalImage.size.height
           );
#endif
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self openCropEditor:[[UIImage memoryOptimizedImageWithImage:originalImage] fixOrientation]];
    }];
}

#pragma mark photo cropper

-(void) openCropEditor:(UIImage *) image {
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = image;
    controller.cropAspectRatio = 1;
    
    controller.keepingCropAspectRatio = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        navigationController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage {
    
    [controller dismissViewControllerAnimated:YES completion:NULL];
    self.imageViewProfilePhoto_.image = croppedImage;
        self.profilePhoto_ = croppedImage;
}

-(void) cropViewControllerDidCancel:(PECropViewController *)controller {
    [controller dismissViewControllerAnimated:YES completion:NULL];
}

-(void) setProfiles {
    self.textFieldUserName_.text = [[DataManager sharedInstance].currentUserProfile_ safeStringForKey:@"user_name"];
    self.textFieldEmail_.text = [[DataManager sharedInstance].currentUserProfile_ safeStringForKey:@"user_email"];
    
    NSLog(@"photo - %@", [[DataManager sharedInstance].currentUserProfile_ safeStringForKey:@"user_photo"]);
    LOAD_IMAGE_FROM_URL(self.imageViewProfilePhoto_, [[DataManager sharedInstance].currentUserProfile_ safeStringForKey:@"user_photo"], nil)
}

@end
