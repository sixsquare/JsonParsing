//
//  ChatRoomViewController.m
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "ChatRoomViewController.h"
#import "JSMessageInputView.h"
#import "NSString+JSMessagesView.h"
#import "ChatCell.h"
#import "UIViewController+BackButtonHandler.h"


@interface ChatRoomViewController ()

@end

@implementation ChatRoomViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (IS_OS_7_OR_LATER)
        self.automaticallyAdjustsScrollViewInsets = NO;
    
    UIBarButtonItem *button = [[UIBarButtonItem alloc]
                               initWithBarButtonSystemItem:UIBarButtonSystemItemAction
                               target:self
                               action:@selector(shareApp:)];
    self.navigationItem.rightBarButtonItem = button;

    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0.0, 0.0, 180.0, 44.0)];
    [label setBackgroundColor:[UIColor clearColor]];
    [label setTextColor:[UIColor darkGrayColor]];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont boldSystemFontOfSize:14]];
    NSString *titleStr  = [NSString stringWithFormat:@"%@ VS %@\nArena %d", [self.roomDict_ safeStringForKey:@"teamA"], [self.roomDict_ safeStringForKey:@"teamB"], [self.roomDict_ safeIntegerValueForKey:@"room_index"] + 1];
    self.labelTeamA_.text = [self.roomDict_ safeStringForKey:@"teamA"];
    self.labelTeamB_.text = [self.roomDict_ safeStringForKey:@"teamB"];
    
    self->roomCharacterLimit_ = [self.roomDict_ safeIntegerValueForKey:@"room_character_limit"];
    self->roomLimistSecond_   = [self.roomDict_ safeIntegerValueForKey:@"room_limit_second"];
    
    tableViewContentInsetTop_ = 33;
    
    [label setNumberOfLines:2];

    [label setText:titleStr];
    self.navigationItem.titleView = label;
    
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.tableViewMain_ addGestureRecognizer:singleFingerTap];
    
    teamsViewShown_ = YES;

    [self sendViewInit];
    
    refreshing_ = YES;
    [self loadMessages];
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    originalTableViewContentInset_ = self.tableViewMain_.contentInset;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(handleWillShowKeyboardNotification:)
												 name:UIKeyboardWillShowNotification
                                               object:nil];
    
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(handleWillHideKeyboardNotification:)
												 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    [APP_DELEGATE.container_ hideCustomTab];
    
    shouldReload_ = YES;
    
    if (!refreshing_) {
        [self refreshMessages];
    }
}

-(void) viewWillDisappear:(BOOL)animated {
    shouldReload_ = NO;
}

-(BOOL) navigationShouldPopOnBackButton {
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(exitRoom) toTarget:self withObject:nil];
    return NO;
}

-(void) exitRoom {
    [[WebServiceAPIsManager sharedInstance] exitRoom:[DataManager sharedInstance].currentUserId_ roomId:[self.roomDict_ safeStringForKey:@"rid"]];
    [DataManager sharedInstance].currentEnteredRoomId_ = nil;
    [self performSelectorOnMainThread:@selector(back) withObject:nil waitUntilDone:YES];
}

-(void) back {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark message view init
-(void) sendViewInit {
    CGSize size = self.containerView_.frame.size;
    
    JSMessageInputViewStyle inputViewStyle = JSMessageInputViewStyleFlat;
    CGFloat inputViewHeight = (inputViewStyle == JSMessageInputViewStyleFlat) ? 45.0f : 40.0f;
    
    CGRect inputFrame = CGRectMake(0.0f,
                                   size.height - inputViewHeight,
                                   size.width,
                                   inputViewHeight);
    JSMessageInputView *inputView = [[JSMessageInputView alloc] initWithFrame:inputFrame
                                                                        style:inputViewStyle
                                                                     delegate:self
                                                         panGestureRecognizer:self.tableViewMain_.panGestureRecognizer];
    
    inputView.sendButton.enabled = NO;
    [inputView.sendButton addTarget:self
                          action:@selector(sendPressed:)
                          forControlEvents:UIControlEventTouchUpInside];
    
    [self.containerView_ addSubview:inputView];
    
    self.inputView_ = inputView;
}

#pragma mark - Keyboard notifications

- (void)handleWillShowKeyboardNotification:(NSNotification *)notification
{
    [self keyboardWillShowHide:notification];
}

- (void)handleWillHideKeyboardNotification:(NSNotification *)notification
{
    [self keyboardWillShowHide:notification];
}

- (void)keyboardWillShowHide:(NSNotification *)notification
{
    CGRect keyboardRect = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
	double duration = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         CGFloat keyboardY = [self.containerView_ convertRect:keyboardRect fromView:nil].origin.y;
                         
                         CGRect inputViewFrame = self.inputView_.frame;
                         CGFloat inputViewFrameY = keyboardY - inputViewFrame.size.height;
                         
                         // for ipad modal form presentations
                         CGFloat messageViewFrameBottom = self.containerView_.frame.size.height - inputViewFrame.size.height;
                         if(inputViewFrameY > messageViewFrameBottom)
                             inputViewFrameY = messageViewFrameBottom;
						 
                         self.inputView_.frame = CGRectMake(inputViewFrame.origin.x,
																  inputViewFrameY,
																  inputViewFrame.size.width,
																  inputViewFrame.size.height);
                         
                         UIEdgeInsets insets = originalTableViewContentInset_;
                         insets.bottom = self.containerView_.frame.size.height - self.inputView_.frame.origin.y - inputViewFrame.size.height;
                         
                         self.tableViewMain_.contentInset = insets;
                         self.tableViewMain_.scrollIndicatorInsets = insets;
                     }
                     completion:^(BOOL finished) {
                     }];
}

#pragma mark - Dismissive text view delegate

- (void)keyboardDidScrollToPoint:(CGPoint)point
{
    CGRect inputViewFrame = self.inputView_.frame;
    CGPoint keyboardOrigin = [self.containerView_ convertPoint:point fromView:nil];
    inputViewFrame.origin.y = keyboardOrigin.y - inputViewFrame.size.height;
    self.inputView_.frame = inputViewFrame;
}

- (void)keyboardWillBeDismissed
{
    CGRect inputViewFrame = self.inputView_.frame;
    inputViewFrame.origin.y = self.containerView_.bounds.size.height - inputViewFrame.size.height;
    self.inputView_.frame = inputViewFrame;
}

- (void)keyboardWillSnapBackToPoint:(CGPoint)point
{
    CGRect inputViewFrame = self.inputView_.frame;
    CGPoint keyboardOrigin = [self.containerView_ convertPoint:point fromView:nil];
    inputViewFrame.origin.y = keyboardOrigin.y - inputViewFrame.size.height;
    self.inputView_.frame = inputViewFrame;
}

#pragma mark - Text view delegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [textView becomeFirstResponder];
	
    if(!self.previousTextViewContentHeight)
		self.previousTextViewContentHeight = textView.contentSize.height;
    
    [self scrollToBottomAnimated:YES];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [textView resignFirstResponder];
}

- (void)textViewDidChange:(UITextView *)textView
{
    CGFloat maxHeight = [JSMessageInputView maxHeight];
    
    CGSize size = [textView sizeThatFits:CGSizeMake(textView.frame.size.width, maxHeight)];
    CGFloat textViewContentHeight = size.height;
    
    BOOL isShrinking = textViewContentHeight < self.previousTextViewContentHeight;
    CGFloat changeInHeight = textViewContentHeight - self.previousTextViewContentHeight;
    
    if(!isShrinking && (self.previousTextViewContentHeight == maxHeight || textView.text.length == 0)) {
        changeInHeight = 0;
    }
    else {
        changeInHeight = MIN(changeInHeight, maxHeight - self.previousTextViewContentHeight);
    }
    
    if(changeInHeight != 0.0f) {
        
        [UIView animateWithDuration:0.25f
                         animations:^{
                             UIEdgeInsets insets = UIEdgeInsetsMake(tableViewContentInsetTop_,
                                                                    0.0f,
                                                                    self.tableViewMain_.contentInset.bottom + changeInHeight,
                                                                    0.0f);
                             
                             self.tableViewMain_.contentInset = insets;
                             self.tableViewMain_.scrollIndicatorInsets = insets;
                             [self scrollToBottomAnimated:NO];
                             
                             if(isShrinking) {
                                 // if shrinking the view, animate text view frame BEFORE input view frame
                                 [self.inputView_ adjustTextViewHeightBy:changeInHeight];
                             }
                             
                             CGRect inputViewFrame = self.inputView_.frame;
                             self.inputView_.frame = CGRectMake(0.0f,
                                                                      inputViewFrame.origin.y - changeInHeight,
                                                                      inputViewFrame.size.width,
                                                                      inputViewFrame.size.height + changeInHeight);
                             
                             if(!isShrinking) {
                                 // growing the view, animate the text view frame AFTER input view frame
                                 [self.inputView_ adjustTextViewHeightBy:changeInHeight];
                             }
                         }
                         completion:^(BOOL finished) {
                         }];
        
        self.previousTextViewContentHeight = MIN(textViewContentHeight, maxHeight);
    }
    
    self.inputView_.sendButton.enabled = ([textView.text js_stringByTrimingWhitespace].length > 0);
}

#pragma mark scroll controls
- (void)scrollToBottomAnimated:(BOOL)animated
{
    if (![self shouldAllowScroll]) return;
    
    NSInteger rows = [self.tableViewMain_ numberOfRowsInSection:0];
    
    if(rows > 0) {
        [self.tableViewMain_ scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:rows - 1 inSection:0]
                              atScrollPosition:UITableViewScrollPositionBottom
                                      animated:animated];
    }
}

- (void)scrollToRowAtIndexPath:(NSIndexPath *)indexPath
			  atScrollPosition:(UITableViewScrollPosition)position
					  animated:(BOOL)animated
{
    if (![self shouldAllowScroll]) return;
    
	[self.tableViewMain_ scrollToRowAtIndexPath:indexPath
						  atScrollPosition:position
								  animated:animated];
}

- (BOOL)shouldAllowScroll
{
    return NO;
}

#pragma mark send processing
- (void)sendPressed:(UIButton *)sender
{
    [self.inputView_.textView resignFirstResponder];
    
    if ([self.inputView_.textView.text isEqualToString:@""]) {
        
    } else if (self.inputView_.textView.text.length > self->roomCharacterLimit_) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:[NSString stringWithFormat:@"Message should be less than %d characters", self->roomCharacterLimit_] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
        
    } else {
    
        [self startSendProgressing];
    
        
        messageSending_ = YES;
        
        [NSThread detachNewThreadSelector:@selector(messageSendThread) toTarget:self withObject:nil];
        
    }
}

-(void) sendFinished {
    self.inputView_.textView.text = @"";
    self.inputView_.sendButton.enabled = NO;
}

-(void) startSendProgressing {
    self.progressView_ = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_message_box.jpg"]];
    CGRect frame = [self.inputView_.textView convertRect:self.inputView_.textView.bounds toView:self.inputView_];
    
    progressFinalWidth_ = frame.size.width;
    
    self.progressView_.frame = CGRectMake(frame.origin.x, frame.origin.y, 0, frame.size.height);
    
    self.progressView_.alpha = 0.7f;
    
    [self.inputView_ addSubview:self.progressView_];
    
    self.progressIndicator_ = [[UIActivityIndicatorView alloc] initWithFrame:frame];
    [self.progressIndicator_ startAnimating];
    [self.inputView_ addSubview:self.progressIndicator_];
    
    sendingProgressing_ = YES;
    
    [UIView beginAnimations:@"sending" context:nil];
    [UIView setAnimationDuration:0.3f];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(sendingAnimationFinished)];
    
    self.progressView_.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width * 0.6f, frame.size.height);
    
    [UIView commitAnimations];
}

-(void) messageSendThread {
    [[WebServiceAPIsManager sharedInstance] sendMessage:[DataManager sharedInstance].currentUserId_ roomId:[self.roomDict_ safeStringForKey:@"rid"] message:self.inputView_.textView.text];
    
    [self performSelectorOnMainThread:@selector(messageSent) withObject:nil waitUntilDone:YES];
}

-(void) messageSent {
    messageSending_ = NO;
    
    if (!sendingProgressing_) {
        [NSThread detachNewThreadSelector:@selector(reloadThread) toTarget:self withObject:nil];
        
        [self startReloadProgressing];
    }
}

-(void) sendingAnimationFinished {
    sendingProgressing_ = NO;
    
    if (!messageSending_) {
        
        reloadProgressing_ = YES;
        reloading_ = YES;
        [NSThread detachNewThreadSelector:@selector(reloadThread) toTarget:self withObject:nil];
        [self startReloadProgressing];
    }
}

-(void) reloadThread {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] messages:[self.roomDict_ safeStringForKey:@"rid"] sessionStart:[self.roomDict_ safeStringForKey:@"session_start"]];
    self.messages_ = [dict safeArrayForKey:@"value"];
    
    [self performSelectorOnMainThread:@selector(reloadDidEnd) withObject:self waitUntilDone:YES];
}

-(void) startReloadProgressing {
    
    CGRect frame = self.progressView_.frame;
    
    [UIView beginAnimations:@"reloading" context:nil];
    [UIView setAnimationDuration:0.2f];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(reloadingAnimationFinished)];
    
    self.progressView_.frame = CGRectMake(frame.origin.x, frame.origin.y, progressFinalWidth_ * 0.85f, frame.size.height);
    
    [UIView commitAnimations];
}

-(void) reloadDidEnd {
    reloading_ = NO;
    
    if (!reloadProgressing_) {
        [self startFinishAnimation];
    }
}

-(void) reloadingAnimationFinished {
    reloadProgressing_ = NO;
    
    if (!reloading_) {
        [self startFinishAnimation];
    }
}

-(void) startFinishAnimation {
    CGRect frame = self.progressView_.frame;
    
    [UIView beginAnimations:@"finishing" context:nil];
    [UIView setAnimationDuration:0.2f];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationCompleted)];
    
    self.progressView_.frame = CGRectMake(frame.origin.x, frame.origin.y, progressFinalWidth_, frame.size.height);
    
    [UIView commitAnimations];
}

-(void) animationCompleted {
    [self.progressView_ removeFromSuperview];
    [self.progressIndicator_ removeFromSuperview];
    
    self.inputView_.textView.text = @"";
    self.inputView_.sendButton.enabled = NO;
    
    [self textViewDidChange:self.inputView_.textView];
    
    [self.tableViewMain_ reloadData];
    
    if (self.messages_ != nil && self.messages_.count > 0) {
        NSIndexPath* ipath = [NSIndexPath indexPathForRow: self.messages_.count - 1 inSection: 0];
        [self.tableViewMain_ scrollToRowAtIndexPath: ipath atScrollPosition: UITableViewScrollPositionTop animated: YES];
    }
    
    self.inputView_.userInteractionEnabled = NO;
    [self performSelector:@selector(enableInput) withObject:nil afterDelay:self->roomLimistSecond_];
}

-(void) enableInput {
//    if(messageSending_ == YES)
//    {
//        [NSThread sleepForTimeInterval:20];
//    }

    self.inputView_.userInteractionEnabled = YES;
}

#pragma mark UITableView Methods
-(int)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.messages_.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [ChatCell heightForMessage:[[self.messages_ objectAtIndex:indexPath.row] safeStringForKey:@"message_content"]];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ChatCell *cell = [tableView dequeueReusableCellWithIdentifier:[ChatCell reuseIdentifier]];
    if (cell == nil) {
        cell = [[ChatCell alloc] init];
    }
    
    int cellType = 0;
    
    NSMutableDictionary *messageDict = [self.messages_ objectAtIndex:indexPath.row];
    
    if([[messageDict safeStringForKey:@"tid"] isEqualToString:[self.roomDict_ safeStringForKey:@"A_tid"]]) {
        cellType = 0;
    } else {
        cellType = 1;
    }
    
    [cell configureWithMessage:[messageDict safeStringForKey:@"message_content"] cellType:cellType photoUrl:[messageDict safeStringForKey:@"user_photo"] userName:[messageDict safeStringForKey:@"user_name"]];
    
    return cell;
}

#pragma mark teams view process

- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer {
    
    if (teamsViewShown_) {
        [self hideTeamView];
    } else {
        [self showTeamView];
    }
    
    teamsViewShown_ = !teamsViewShown_;
}

-(void) hideTeamView {
    CGRect teamFrame = self.viewTeams_.frame;
    teamFrame.origin.y -= teamFrame.size.height;
    [UIView beginAnimations:@"teams" context:nil];
    [UIView setAnimationDuration:0.3f];
    self.viewTeams_.frame = teamFrame;
    self.tableViewMain_.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    tableViewContentInsetTop_ = 0;
    [UIView commitAnimations];
}

-(void) showTeamView {
    CGRect teamFrame = self.viewTeams_.frame;
    teamFrame.origin.y += teamFrame.size.height;
    [UIView beginAnimations:@"teams" context:nil];
    [UIView setAnimationDuration:0.3f];
    self.viewTeams_.frame = teamFrame;

    self.tableViewMain_.contentInset = UIEdgeInsetsMake(33, 0, 0, 0);
    tableViewContentInsetTop_ = 33;
    
    if (self.tableViewMain_.contentOffset.y < 33) {
        [self.tableViewMain_ setContentOffset:CGPointMake(0, -33) animated:YES];
    }

    [UIView commitAnimations];
}

-(void) loadMessages {
    [NSThread detachNewThreadSelector:@selector(messageLoadThread) toTarget:self withObject:nil];
}

-(void) messageLoadThread {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] messages:[self.roomDict_ safeStringForKey:@"rid"] sessionStart:[self.roomDict_ safeStringForKey:@"session_start"]];
    self.messages_ = [dict safeArrayForKey:@"value"];
    
    [self performSelectorOnMainThread:@selector(messagesLoaded) withObject:self waitUntilDone:YES];

}

-(void) messagesLoaded {
    reloading_ = NO;
    [self.tableViewMain_ reloadData];
    
    
    [self refreshMessages];
}


-(void) refreshMessages {
    
    refreshing_ = YES;
    [NSThread detachNewThreadSelector:@selector(messageRefreshThread) toTarget:self withObject:nil ];
    
}

-(void) messageRefreshThread {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] messages:[self.roomDict_ safeStringForKey:@"rid"] sessionStart:[self.roomDict_ safeStringForKey:@"session_start"]];
    self.messages_ = [dict safeArrayForKey:@"value"];
    
   
    [self performSelectorOnMainThread:@selector(messageRefreshThreadDidEnd) withObject:self waitUntilDone:YES];
}

-(void) messageRefreshThreadDidEnd {
    
    [self.tableViewMain_ reloadData];
    
    refreshing_ = NO;
    
    if (shouldReload_) {
        
        [self performSelector:@selector(refreshMessages) withObject:nil afterDelay:0.5f];
        
    }
}

-(IBAction)shareApp:(id)sender {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:_T(@"Cancel") destructiveButtonTitle:_T(@"Share via mail") otherButtonTitles:_T(@"Share via message"), nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
    
}

#pragma mark UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if ([_T(@"Share via mail") isEqualToString:title]) {
        [self sendEmailSharing];
    } else if ([_T(@"Share via message") isEqualToString:title]) {
        [self sendMessageSharing];
    }
}


-(void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    [controller dismissViewControllerAnimated:YES completion:nil];
}

-(void) messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    [controller dismissViewControllerAnimated:YES completion:nil];
}

-(void) sendEmailSharing {
    if ([MFMailComposeViewController canSendMail])
    {
        MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
        mailer.mailComposeDelegate = self;
        
        
        NSString *emailBody = [NSString stringWithFormat:@"I would like to invite you to Ghost Fish Chat. This is where people play chat for the games. Download the app here. http://itunes....."];
        [mailer setMessageBody:emailBody isHTML:YES];
        [mailer setSubject:@"Hi, Friend, Enjoy Ghost Fish Chat!"];
        [self presentViewController:mailer animated:YES completion:nil];
    } else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"Sorry, your device cannot send email. Please go to Settings and set the email account for your device" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
    }
}

-(void) sendMessageSharing {
    if ([MFMessageComposeViewController canSendText])
    {
        MFMessageComposeViewController *mailer = [[MFMessageComposeViewController alloc] init];
        mailer.messageComposeDelegate = self;
        
        
        NSString *emailBody = [NSString stringWithFormat:@"I would like to invite you to Ghost Fish Chat. This is where people play chat for the games. Download the app here. http://itunes....."];
        [mailer setBody:emailBody];
        [self presentViewController:mailer animated:YES completion:nil];
    } else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"Sorry, your device cannot send text message." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
    }
}

@end
