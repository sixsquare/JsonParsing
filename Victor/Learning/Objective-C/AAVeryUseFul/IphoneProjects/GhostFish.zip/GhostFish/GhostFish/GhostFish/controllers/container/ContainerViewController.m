//
//  TabMainViewController.m
//  holistica
//
//  Created by Mountain on 10/31/13.
//  Copyright (c) 2013 chinasoft. All rights reserved.
//

#import "ContainerViewController.h"

@interface ContainerViewController ()

@end

@implementation ContainerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.viewCustomizedTabBar_ = [[[NSBundle mainBundle] loadNibNamed:@"ContainerViewController" owner:self options:nil] lastObject];
    
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.hidesBackButton = YES;
    
    [self customizedTabBarInit];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    self.tabBar.hidden = YES;
//    [self showTabBar:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showTabBar:(BOOL)show {
    UITabBar* tabBar = self.tabBar;
    if (show != tabBar.hidden)
        return;
    
    UIView* subview = [self.view.subviews objectAtIndex:0];
    CGRect frame = subview.frame;
    frame.size.height += tabBar.frame.size.height * (show ? -1 : 1);
    subview.frame = frame;
    tabBar.hidden = !show;
}

-(void) addCustomTab {
    if (!self.viewCustomizedTabBar_.superview)
        [self.view addSubview:self.viewCustomizedTabBar_];
    
    self.viewCustomizedTabBar_.frame = CGRectMake(0, self.view.frame.size.height, 320, self.viewCustomizedTabBar_.frame.size.height);
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3f];
    self.viewCustomizedTabBar_.frame = CGRectMake(0, self.view.frame.size.height - self.viewCustomizedTabBar_.frame.size.height, 320, self.viewCustomizedTabBar_.frame.size.height);
    customTabAppeared_ = YES;
    [UIView commitAnimations];
}

-(void) hideCustomTab {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3f];
    self.viewCustomizedTabBar_.frame = CGRectMake(0, self.view.frame.size.height, 320, self.viewCustomizedTabBar_.frame.size.height);
    customTabAppeared_ = NO;
    [UIView commitAnimations];
}

-(BOOL) customTabAppeared {
    return customTabAppeared_;
}

- (IBAction)onTab1:(id)sender {
    [self hideAllTabMenus];
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:1]).selected = YES;
    
    [self showMainMenu];
}

- (IBAction)onTab2:(id)sender {
    [self hideAllTabMenus];
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:2]).selected = YES;
    
    [self showGameTime];
}

- (IBAction)onTab3:(id)sender {
    [self hideAllTabMenus];
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:3]).selected = YES;
    
    [self showSettings];
}

-(void) customizedTabBarInit {
    [self hideAllTabMenus];
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:2]).selected = YES;
}

-(void) hideAllTabMenus {
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:1]).selected = NO;
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:2]).selected = NO;
    ((UIButton *)[self.viewCustomizedTabBar_ viewWithTag:3]).selected = NO;
}

-(void) showSettings {
    self.selectedIndex = 1;
}

-(void) showMainMenu {
    
//    int currentSelectedIdx = self.selectedIndex;
//    
//    self.selectedIndex = 0;
//    
//    if (currentSelectedIdx == 0) {
//        UINavigationController *controller = [self.viewControllers objectAtIndex:0];
//        
//        for (int idx = 0; idx < controller.viewControllers.count; idx++) {
//            UIViewController *child = [controller.viewControllers objectAtIndex:idx];
//            if ([child isKindOfClass:[MenuViewController class]]) {
//                [controller popToViewController:child animated:YES];
//                break;
//            }
//        }
//    }
    
}

-(void) showInfoBox {
    [self.view addSubview:self.viewInfoPopup_];
    
    for (UIGestureRecognizer *recognizer in self.viewInfoPopup_.gestureRecognizers) {
        [self.viewInfoPopup_ removeGestureRecognizer:recognizer];
    }
    
    UITapGestureRecognizer *singleFingerTap =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(handleSingleTap:)];
    [self.viewInfoPopup_ addGestureRecognizer:singleFingerTap];
}

-(void) showGameTime {
    self.selectedIndex = 0;
}

- (void):(UITapGestureRecognizer *)recognizer {
    [self hideInfoBox];
}

-(void) hideInfoBox {
    [self hideAllTabMenus];
    [self.viewCustomizedTabBar_ viewWithTag:oldSelectedIdx_ + 1].hidden = NO;
    [self.viewInfoPopup_ removeFromSuperview];
}

@end
