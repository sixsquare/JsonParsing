//
//  LoginViewController.m
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "MainMenuViewController.h"
#import "ContainerViewController.h"
#import "SettingViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.scrollViewMain_ contentSizeToFit];
    
    if (IS_OS_7_OR_LATER)
        self.automaticallyAdjustsScrollViewInsets = NO;
}

-(void) viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithTitle:@"Register"
                                                                  style:UIBarButtonItemStyleBordered
                                                                 target:self
                                                                 action:@selector(createNewAccount:)];
    self.navigationItem.rightBarButtonItem = barButton;
    
    self.title = @"Login";
}

-(void) viewWillDisappear:(BOOL)animated {
    self.title = @"";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)createNewAccount:(id)sender {
    RegisterViewController *controller = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)onLogin:(id)sender {
    [self loginProcess];
}

- (IBAction)onKeepSignin:(id)sender {
    self.buttonKeepSign_.selected = !self.buttonKeepSign_.selected;
}

- (IBAction)onDidEndOnExitOnTextFields:(id)sender {
    [sender resignFirstResponder];
    if (sender == self.textFieldEmail_) {
        [self.textFieldPassword_ becomeFirstResponder];
    } else if (sender == self.textFieldPassword_) {

    }
}

#pragma mark login process

-(void) loginProcess {
    
    [self.view endEditing:YES];
    
    if ([self.textFieldEmail_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter your email or username." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    if ([self.textFieldPassword_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter your password." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(loginThread) toTarget:self withObject:nil];
}

-(void) loginThread {
    NSMutableDictionary *loginDict = [[WebServiceAPIsManager sharedInstance] loginWithUserName:self.textFieldEmail_.text password:self.textFieldPassword_.text];
    
    if ([[loginDict safeStringForKey:@"status"] isEqualToString:@"success"]) {
        
        [DataManager sharedInstance].currentUserId_ = [[loginDict safeDictionaryForKey:@"value"] safeStringForKey:@"uid"];
        [DataManager sharedInstance].currentUserProfile_ = [loginDict safeDictionaryForKey:@"value"];
        
        if (self.buttonKeepSign_.selected) {
            [[DataManager sharedInstance] saveUserId];
        }
        
        [self performSelectorOnMainThread:@selector(loginDidEnd) withObject:self waitUntilDone:YES];
    } else {
        [self performSelectorOnMainThread:@selector(loginFailed:) withObject:[loginDict safeStringForKey:@"report"] waitUntilDone:YES];
    }
}

-(void) loginDidEnd {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    [self gotoMainMenu];
}

-(void) loginFailed:(NSString *)errorReport {
    HIDE_LOADING_VIEW_IN_CONTROLLER()

    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:errorReport delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
}

-(void) gotoMainMenu {
    MainMenuViewController *controller2 = [[MainMenuViewController alloc] initWithNibName:@"MainMenuViewController" bundle:nil];
    SettingViewController *controller3 = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:nil];
    
    ContainerViewController *container = [[ContainerViewController alloc] init];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:controller2];
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:controller3];
    
    nav2.navigationBarHidden = YES;
    self.navigationController.navigationBarHidden = YES;
    
    container.viewControllers = [NSArray arrayWithObjects:nav2, nav3, nil];
    
    APP_DELEGATE.container_ = container;
    
    [container addCustomTab];
    [self.navigationController pushViewController:container animated:YES];
}

@end
