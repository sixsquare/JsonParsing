//
//  ProfilesGroupCell.m
//  Jurhood
//
//  Created by Mountain on 5/1/13.
//  Copyright (c) 2013 ChinaSoft. All rights reserved.
//

#import "ChatCell.h"
#import <QuartzCore/QuartzCore.h>
#import "UIImage+JSMessagesView.h"

@implementation ChatCell

@synthesize content_;

+ (NSString *)reuseIdentifier {
    return NSStringFromClass([self class]);
}

+ (NSString *)nibName {
    return @"ChatCell";
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        // Initialization code
        self.selectedBackgroundView = [[UIView alloc] init];
    }
    
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (id)init {
    UITableViewCellStyle style = UITableViewCellStyleDefault;
    NSString *identifier = NSStringFromClass([self class]);
    
    if ((self = [super initWithStyle:style reuseIdentifier:identifier])) {
        NSString *nibName = [[self class] nibName];
        if (nibName) {
            
            [[NSBundle mainBundle] loadNibNamed:nibName
                                          owner:self
                                        options:nil];
            NSAssert(self.content_ != nil, @"NIB file loaded but content property not set.");
            [self.contentView addSubview:self.content_];
            
            self.contentView.backgroundColor = [UIColor clearColor];
            self.backgroundColor = [UIColor clearColor];
            self.content_.backgroundColor = [UIColor clearColor];
            
            self.selectedBackgroundView = [[UIView alloc] init];
            
            
            self.textViewMessage_.contentInset = UIEdgeInsetsZero;
            self.textViewMessage_.textColor = [UIColor blackColor];
            self.textViewMessage_.editable = NO;
            self.textViewMessage_.userInteractionEnabled = YES;
            self.textViewMessage_.showsHorizontalScrollIndicator = NO;
            self.textViewMessage_.showsVerticalScrollIndicator = NO;
            self.textViewMessage_.scrollEnabled = NO;
            self.textViewMessage_.backgroundColor = [UIColor clearColor];
            self.textViewMessage_.contentInset = UIEdgeInsetsZero;
            self.textViewMessage_.scrollIndicatorInsets = UIEdgeInsetsZero;
            self.textViewMessage_.contentOffset = CGPointZero;
            self.textViewMessage_.dataDetectorTypes = UIDataDetectorTypeAll;
            
            if([self.textViewMessage_ respondsToSelector:@selector(textContainerInset)]) {
                self.textViewMessage_.textContainerInset = UIEdgeInsetsMake(4.0f, 4.0f, 4.0f, 4.0f);
            }
            
            self.textViewMessage_.hidden = YES;

        }
    }
    return self;
}

+ (CGFloat) heightForMessage:(NSString *)message {
    CGSize size = [message measureWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(200, CGFLOAT_MAX)];
    return 55 + size.height + 10;
}

- (void) configureWithMessage:(NSString *)message cellType:(int)cellType photoUrl:(NSString *)photoUrl userName:(NSString*)userName {
    
    [self replaceElementsWithType:cellType];
    
    self.imageViewProfilePhoto_.layer.masksToBounds = YES;
    self.imageViewProfilePhoto_.layer.cornerRadius = 3;
    
    LOAD_IMAGE_FROM_URL(self.imageViewProfilePhoto_, photoUrl, [UIImage imageNamed:@"bg_photo_frame.png"]);
    
    self.labelUserName_.text = userName;
    self.labelMessage_.text = message;
    
    CGSize size = [message measureWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(200, CGFLOAT_MAX)];
    self.labelMessage_.frame = CGRectMake(self.labelMessage_.frame.origin.x, self.labelMessage_.frame.origin.y, self.labelMessage_.frame.size.width, size.height);
    
    self.imageViewChatBack_.frame = CGRectMake(self.imageViewChatBack_.frame.origin.x, self.imageViewChatBack_.frame.origin.y, self.imageViewChatBack_.frame.size.width, size.height + 25);
}

-(void) replaceElementsWithType:(int)cellType {
    if (cellType == 1) {
        self.imageViewProfilePhoto_.frame = CGRectMake(265, 5, 30, 30);
        self.labelUserName_.frame = CGRectMake(260 - 185, 10, 185, 20);
        self.labelUserName_.textAlignment = NSTextAlignmentRight;
        self.imageViewChatBack_.frame = CGRectMake(300 - 5 - 210, 35, 210, 76);
        self.labelMessage_.frame = CGRectMake(300 - 10 - 200, 50, 200, 30);
        UIEdgeInsets capInsets = UIEdgeInsetsMake(10, 5, 5, 16);
        UIImage *normalBubble = [UIImage imageNamed:@"bg_right_bubble.png"];
        self.imageViewChatBack_.image = [normalBubble js_stretchableImageWithCapInsets:capInsets];;
    } else {
        self.imageViewProfilePhoto_.frame = CGRectMake(5, 5, 30, 30);
        self.labelUserName_.frame = CGRectMake(40, 10, 185, 20);
        self.labelUserName_.textAlignment = NSTextAlignmentLeft;
        self.imageViewChatBack_.frame = CGRectMake(5, 35, 210, 76);
        self.labelMessage_.frame = CGRectMake(10, 50, 200, 30);
        UIEdgeInsets capInsets = UIEdgeInsetsMake(10, 16, 5, 5);
        UIImage *normalBubble = [UIImage imageNamed:@"bg_left_bubble.png"];
        self.imageViewChatBack_.image = [normalBubble js_stretchableImageWithCapInsets:capInsets];;
    }
}

@end
