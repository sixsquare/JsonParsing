//
//  DataManager.m
//  Jurhood
//
//  Created by Mountain on 6/6/13.
//  Copyright (c) 2013 ChinaSoft. All rights reserved.
//

#import "DataManager.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@implementation DataManager

static DataManager *instance;

+(DataManager *) sharedInstance {
    
    if (instance == nil) {
        instance = [DataManager new];
        instance.deviceToken_ = @"EMPTY";
        
        //        [NSThread detachNewThreadSelector:@selector(fetchTagDatabase) toTarget:instance withObject:nil];
    }
    
    return instance;
}

-(void) saveUserId {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"user_id_saved"];
    [[NSUserDefaults standardUserDefaults] setValue:self.currentUserId_ forKey:@"user_id"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

-(void) removeUserId {
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"user_id_saved"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

-(BOOL) userIdSaved {
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"user_id_saved"]) {
        self.currentUserId_ = [NSString stringWithFormat:@"%d", [[NSUserDefaults standardUserDefaults] integerForKey:@"user_id"]];
        NSLog(@"Saved user id - %@", self.currentUserId_);
        return YES;
    } else {
        return NO;
    }
}

@end

