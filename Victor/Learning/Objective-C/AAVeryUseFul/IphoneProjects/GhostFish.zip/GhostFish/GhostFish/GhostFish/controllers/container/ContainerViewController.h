//
//  TabMainViewController.h
//  holistica
//
//  Created by Mountain on 10/31/13.
//  Copyright (c) 2013 chinasoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContainerViewController : UITabBarController {
    int     oldSelectedIdx_;
    BOOL    customTabAppeared_;
}

@property (strong, nonatomic) IBOutlet UIView *viewCustomizedTabBar_;
@property (strong, nonatomic) IBOutlet UIView *viewInfoPopup_;

-(void)showTabBar:(BOOL)show;
-(void)addCustomTab;
-(void) hideCustomTab;
-(BOOL) customTabAppeared;

- (IBAction)onTab1:(id)sender;
- (IBAction)onTab2:(id)sender;
- (IBAction)onTab3:(id)sender;

@end
