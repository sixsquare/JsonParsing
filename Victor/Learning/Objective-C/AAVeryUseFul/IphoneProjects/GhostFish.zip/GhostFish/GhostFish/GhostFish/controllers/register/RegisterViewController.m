//
//  RegisterViewController.m
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "RegisterViewController.h"
#import "SelectTeamViewController.h"
#import "UIImage+fixOrientation.h"

@interface RegisterViewController ()

@end

@implementation RegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.scrollViewMain_ contentSizeToFit];

    self.navigationController.navigationBarHidden = NO;
    self.title = @"Register";
    
    if (IS_OS_7_OR_LATER)
        self.automaticallyAdjustsScrollViewInsets = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onRegister:(id)sender {
    [self registerProcess];
}

#pragma mark profile photo process
- (IBAction)onChoosePhoto:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:_T(@"Cancel") destructiveButtonTitle:_T(@"Camera") otherButtonTitles:_T(@"Photo Library"), _T(@"Saved Album"), nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
}

#pragma mark UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet f:(NSInteger)buttonIndex {
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if ([_T(@"Camera") isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([_T(@"Photo Library") isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([_T(@"Saved Album") isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerControllerDelegate
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSMutableDictionary *)info {
    UIImage *originalImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
#ifdef DEV_ENVIRONMENT
    NSLog (@"Image Size, %f, %f", originalImage.size.width, originalImage.size.height
           );
#endif
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self openCropEditor:[[UIImage memoryOptimizedImageWithImage:originalImage] fixOrientation]];
    }];
}

#pragma mark photo cropper

-(void) openCropEditor:(UIImage *) image {
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = image;
    controller.cropAspectRatio = 1;
    
    controller.keepingCropAspectRatio = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        navigationController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage {
    
    [controller dismissViewControllerAnimated:YES completion:NULL];
    self.imageViewProfilePhotoView_.image = croppedImage;
    self.profilePhoto_ = croppedImage;
}

-(void) cropViewControllerDidCancel:(PECropViewController *)controller {
    [controller dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark register process
-(void) registerProcess {
    if ([self.textFieldUserName_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter your user name." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        
        return;
    }
    
    if ([self.textFieldPassword_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter your password." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        
        return;
    }
    
    if (![self.textFieldPassword_.text isEqualToString:self.textFieldConfirmPassword_.text]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Password does not match." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        
        return;
    }
    
    if ([self.textFieldEmail_.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please enter your email." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        
        return;
    }
    
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(registerThread) toTarget:self withObject:nil];
}

-(void) registerThread {
    NSMutableDictionary *result = [[WebServiceAPIsManager sharedInstance] registerWithUserName:self.textFieldUserName_.text email:self.textFieldEmail_.text password:self.textFieldPassword_.text nickName:@"" profilePhoto:self.profilePhoto_];
    
    if ([[result safeStringForKey:@"status"] isEqualToString:@"success"]) {
        
        [DataManager sharedInstance].currentUserId_ = [[result safeDictionaryForKey:@"value"] safeStringForKey:@"uid"];
        [DataManager sharedInstance].currentUserProfile_ = [result safeDictionaryForKey:@"value"];
        [[DataManager sharedInstance] saveUserId];
        
        [self performSelectorOnMainThread:@selector(registered) withObject:nil waitUntilDone:YES];
    } else {
        [self performSelectorOnMainThread:@selector(registerFailed:) withObject:[result safeStringForKey:@"report"] waitUntilDone:YES];
    }
}

-(void) registered {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    [self gotoTeamSelectPage];
}

-(void) registerFailed:(NSString *)errorReport {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:errorReport delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
}

-(void) gotoTeamSelectPage {
    SelectTeamViewController *controller = [[SelectTeamViewController alloc] initWithNibName:@"SelectTeamViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
}

@end
