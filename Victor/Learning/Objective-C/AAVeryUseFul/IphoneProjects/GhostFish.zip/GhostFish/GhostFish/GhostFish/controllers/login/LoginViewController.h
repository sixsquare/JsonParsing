//
//  LoginViewController.h
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"

@interface LoginViewController : UIViewController {
    CGFloat animatedDistance_;
}

@property (weak, nonatomic) IBOutlet UIButton                       *buttonKeepSign_;
@property (weak, nonatomic) IBOutlet UITextField                    *textFieldEmail_;
@property (weak, nonatomic) IBOutlet UITextField                    *textFieldPassword_;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView   *scrollViewMain_;

- (IBAction)onLogin:(id)sender;
- (IBAction)onKeepSignin:(id)sender;
- (IBAction)onDidEndOnExitOnTextFields:(id)sender;

@end
