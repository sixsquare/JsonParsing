//
//  WebServiceAPIsManager.h
//  GhostFish
//
//  Created by Mountain on 12/5/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import <Foundation/Foundation.h>

#define BASE_FEED                           @"http://ghostfishchat.com/appdev/ghostfishchat/index.php/apis/"

#define FEED_FROM(service_name)             [NSString stringWithFormat:@"%@%@", BASE_FEED, service_name]

#define FEED_USER_REGISTER                  FEED_FROM(@"user/register")
#define FEED_USER_LOGIN                     FEED_FROM(@"user/login_normaluser")
#define FEED_USER_LOGOUT                    FEED_FROM(@"user/logout")
#define FEED_USER_PROFILE                   FEED_FROM(@"user/user_profile")
#define FEED_UPDATE_PROFILE                 FEED_FROM(@"user/update_profile")
#define FEED_ALL_CATEGORIES                 FEED_FROM(@"teams_games/categories_list")
#define FEED_ALL_TEAMS                      FEED_FROM(@"teams_games/teams")
#define FEED_CHOOSE_TEAM                    FEED_FROM(@"teams_games/add_team")
#define FEED_OPEN_GAMES                     FEED_FROM(@"teams_games/open_games")
#define FEED_OPEN_ROOMS                     FEED_FROM(@"message/open_rooms")
#define FEED_MY_TEAMS                       FEED_FROM(@"teams_games/my_teams")
#define FEED_ENTER_ROOM                     FEED_FROM(@"message/enter_room")
#define FEED_EXIT_ROOM                      FEED_FROM(@"message/exit_room")
#define FEED_SEND_MESSAGE                   FEED_FROM(@"message/send_message")
#define FEED_MESSAGES                       FEED_FROM(@"message/messages")

@interface WebServiceAPIsManager : NSObject

+(WebServiceAPIsManager *) sharedInstance;

-(NSMutableDictionary *) registerWithUserName:(NSString *)userName
                       email:(NSString *)email
                    password:(NSString *)password
                    nickName:(NSString *)nickName
                profilePhoto:(UIImage *)profilePhoto;

-(NSMutableDictionary *) loginWithUserName:(NSString *)userName
                 password:(NSString *)password;

-(NSMutableDictionary *) userLogout:(NSString *)userId;

-(NSMutableDictionary *) userProfile:(NSString *)userId;

-(NSMutableDictionary *) updatePofile:(NSString *)userId
                             userName:(NSString *)userName
                                email:(NSString *)email
                             password:(NSString *)password
                            userPhoto:(UIImage *)userPhoto;

-(NSMutableDictionary *) allTeams;

-(NSMutableDictionary *) chooseTeamForUser:(NSString *)userId catId:(NSString *)catId teamId:(NSString *)teamId;

-(NSMutableArray *) openGamesForUser:(NSString *)userId;

-(NSMutableDictionary *) openRoomsForUser:(NSString *)userId;

-(NSMutableDictionary *) myTeams:(NSString *)userId;

-(NSMutableDictionary *) enterRoom:(NSString *)userId roomId:(NSString *)roomId;

-(NSMutableDictionary *) exitRoom:(NSString *)userId roomId:(NSString *)roomId;

-(NSMutableDictionary *) sendMessage:(NSString *)fromUId roomId:(NSString *)roomId message:(NSString *)message;

-(NSMutableDictionary *) messages:(NSString *)roomId sessionStart:(NSString *)sessionStart;

@end
