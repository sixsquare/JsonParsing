//
//  MainMenuViewController.m
//  GhostFish
//
//  Created by Mountain on 11/28/13.
//  Copyright (c) 2013 Mountain. All rights reserved.
//

#import "MainMenuViewController.h"
#import "SettingViewController.h"
#import "ChatRoomViewController.h"
#import "JSDemoViewController.h"


@interface MainMenuViewController ()

@end

@implementation MainMenuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    self.title = @"DashBoard";
    
    loading_ = YES;
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(loadRooms) toTarget:self withObject:nil];
}

-(void) viewWillDisappear:(BOOL)animated {
    self.title = @"";
    
    shouldReload_ = NO;
}

-(void) viewWillAppear:(BOOL)animated {
    self.title = @"Choose Team";
    
    if (![APP_DELEGATE.container_ customTabAppeared]) {
        [APP_DELEGATE.container_ addCustomTab];
    }
    
    shouldReload_ = YES;
    
    if (!loading_) {
        [self startLoadRoomsRepeatThread];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) onSetting:(id) sender {
    SettingViewController *controller = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)onRoom1:(id)sender {
    JSDemoViewController *controller = [[JSDemoViewController alloc] init];
    controller.title = @"Room 1";
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)onRoom2:(id)sender {
    JSDemoViewController *controller = [[JSDemoViewController alloc] init];
    controller.title = @"Room 2";
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark UITableView methods
-(int) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.rooms_.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellIdentifier = @"game_cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    NSMutableDictionary *room = [self.rooms_ objectAtIndex:indexPath.row];
    
    NSString *roomUsers = [room safeStringForKey:@"room_users"];
    int usersCount;
    if ([roomUsers isEqualToString:@""]) {
        usersCount = 0;
    } else {
        usersCount = [roomUsers componentsSeparatedByString:@" "].count - 1;
        if (usersCount < 0) usersCount = 0;
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ VS %@, Arena %d (%d)", [room safeStringForKey:@"teamA"], [room safeStringForKey:@"teamB"], [room safeIntegerValueForKey:@"room_index"] + 1, usersCount];
    cell.textLabel.font = [UIFont systemFontOfSize:13];
    
    return cell;
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self enterIntoRoom:[self.rooms_ objectAtIndex:indexPath.row]];
}

#pragma mark load rooms
-(void) loadRooms {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] openRoomsForUser:[DataManager sharedInstance].currentUserId_];
    if ([[dict safeStringForKey:@"status"] isEqualToString:@"success"]) {
        self.rooms_ = [dict safeArrayForKey:@"value"];
        [self performSelectorOnMainThread:@selector(roomsLoaded) withObject:nil waitUntilDone:YES];
    } else {
        [self performSelectorOnMainThread:@selector(loadFailed:) withObject:[dict safeStringForKey:@"report"] waitUntilDone:YES];
    }
}

-(void) loadFailed:(NSString *)errorReport {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:errorReport delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alertView show];
    
    loading_ = NO;
}

-(void) roomsLoaded {
    
    loading_ = NO;
    
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    [self.tableViewRooms_ reloadData];
    
    [self startLoadRoomsRepeatThread];
}

-(void) enterIntoRoom:(NSMutableDictionary *)roomDict {
    SHOW_LOADING_VIEW_IN_CONTROLLER(nil)
    [NSThread detachNewThreadSelector:@selector(enterRoomThread:) toTarget:self withObject:roomDict];
}

-(void) gotoRoomViewController:(NSMutableDictionary *)roomDict {
    ChatRoomViewController *controller = [[ChatRoomViewController alloc] initWithNibName:@"ChatRoomViewController" bundle:nil];
    controller.roomDict_ = roomDict;
    [self.navigationController pushViewController:controller animated:YES];
}

-(void) enterRoomThread:(NSMutableDictionary *)roomDict {
    NSMutableDictionary *resultDict = [[WebServiceAPIsManager sharedInstance] enterRoom:[DataManager sharedInstance].currentUserId_ roomId:[roomDict safeStringForKey:@"rid"]];
    [roomDict setObject:[resultDict safeStringForKey:@"session_start"] forKey:@"session_start"];
    [DataManager sharedInstance].currentEnteredRoomId_ = [roomDict safeStringForKey:@"rid"];
    [self performSelectorOnMainThread:@selector(roomEntered:) withObject:roomDict waitUntilDone:YES];
}

-(void) roomEntered:(NSMutableDictionary *)roomDict {
    HIDE_LOADING_VIEW_IN_CONTROLLER()
    [self gotoRoomViewController:roomDict];
}

#pragma mark start load rooms thread

-(void) startLoadRoomsRepeatThread {
    loading_ = YES;
    [NSThread detachNewThreadSelector:@selector(roomsLoadThread) toTarget:self withObject:nil];
}

-(void) roomsLoadThread {
    NSMutableDictionary *dict = [[WebServiceAPIsManager sharedInstance] openRoomsForUser:[DataManager sharedInstance].currentUserId_];
    if ([[dict safeStringForKey:@"status"] isEqualToString:@"success"]) {
        self.rooms_ = [dict safeArrayForKey:@"value"];
        [self performSelectorOnMainThread:@selector(roomsReloaded) withObject:nil waitUntilDone:YES];
    } else {
        loading_ = NO;
    }
}

-(void) roomsReloaded {
    
    [self.tableViewRooms_ reloadData];
    
    loading_ = NO;

    if (shouldReload_) {
        [self performSelector:@selector(startLoadRoomsRepeatThread) withObject:nil afterDelay:0.5f];
    }
}

@end
