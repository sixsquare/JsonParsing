//
//  LeagueAndMatchController.h
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlayerDetailsController.h"


@interface LeagueAndMatchController : UIViewController

- (IBAction)leagueButtonClicked:(id)sender;
- (IBAction)viewMatchReportClicked:(id)sender;
- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

@end
