//
//  PlayerDetailsController.m
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "PlayerDetailsController.h"
#import <QuartzCore/QuartzCore.h>

@implementation PlayerDetailsController

@synthesize scrollView;
@synthesize txtFieldName;
@synthesize txtFieldBirthDate;
@synthesize txtField3;
@synthesize txtFieldEmail;
@synthesize txtFieldMobile;
@synthesize txtFieldCountry;
@synthesize txtField7;
@synthesize txtFieldTeam;
@synthesize txtFieldConfirm;
@synthesize btnYES;
@synthesize btnNO;
@synthesize txtView;
@synthesize playerId;
@synthesize activityIndicator;
@synthesize isLeaugeList;
@synthesize isMatchList;
@synthesize leaugeList;
@synthesize matchList;
@synthesize selectedLeauge1;
@synthesize selectedMatch1;
@synthesize selectedPlayer1;
@synthesize pickerBackGround;
@synthesize pickerView;
@synthesize isPlayerList;
@synthesize playerList;
@synthesize btnLeauge1;
@synthesize btnLeauge2;
@synthesize btnMatch1;
@synthesize btnPlayer1;
@synthesize datePicker;
@synthesize datePickerBackground;
@synthesize isPlayerAvailable;
@synthesize alertText;
@synthesize pushDictionary;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void) fetchUpcomingMatch:(NSString *)userId{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fecthUpcomingMatchFailed:) name:kFetchUpcomingMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fecthUpcomingMatchSuccess:) name:kFetchUpcomingMatchSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userId,ktxtUserId, nil];
    [[WebService sharedWebService] callFetchUpcomingMatchWebService:dictionary];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [txtFieldName setReturnKeyType:UIReturnKeyNext];
    [txtField3 setReturnKeyType:UIReturnKeyNext];
    [txtFieldMobile setReturnKeyType:UIReturnKeyNext];
    [txtFieldCountry setReturnKeyType:UIReturnKeyNext];
    [txtField7 setReturnKeyType:UIReturnKeyNext];
    [txtFieldTeam setReturnKeyType:UIReturnKeyDone];
    [txtFieldConfirm setReturnKeyType:UIReturnKeyDone];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editPlayerProfileFailed:) name:kEditPlayerProfileFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editPlayerProfileSuccess:) name:kEditPlayerProfileSuccess object:nil];
    
    [scrollView setContentSize:CGSizeMake(self.view.frame.size.width,1025)];
    
    [datePicker setMaximumDate:[NSDate date]];
    
    isPlayerAvailable = YES;
    [txtFieldConfirm setUserInteractionEnabled:NO];
}

- (void) editPlayerProfileFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditPlayerProfileFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditPlayerProfileSuccess object:nil];
    NSDictionary *dictionary = [notification object];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void) editPlayerProfileSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditPlayerProfileFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditPlayerProfileSuccess object:nil];
    NSDictionary *dictionary = [notification object];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPlayerProfileFailed:) name:kGetPlayerProfileFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPlayerProfileSuccess:) name:kGetPlayerProfileSuccess object:nil];
    
    NSDictionary *getDictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callGetPlayerProfileWebService:getDictionary];
}

- (void) getPlayerProfileFailed:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetPlayerProfileFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetPlayerProfileSuccess object:nil];
}

- (void) getPlayerProfileSuccess:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetPlayerProfileFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetPlayerProfileSuccess object:nil];
    NSDictionary *dictionary = [notification object];
    
    [[NSUserDefaults standardUserDefaults] setObject:[dictionary objectForKey:@"UserProfile"] forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self reloadData];
}

- (void) reloadData{
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    txtFieldName.text = [dictionary objectForKey:@"Name"];
    txtFieldBirthDate.text = [dictionary objectForKey:@"Player_DOB"];
    txtField3.text = [dictionary objectForKey:@"Shirt_no"];
    txtFieldEmail.text = [dictionary objectForKey:@"Emailid"];
    txtFieldMobile.text = [dictionary objectForKey:@"Mobileno"];
    txtFieldCountry.text = [dictionary objectForKey:@"Nationality"];
    txtField7.text = [dictionary objectForKey:@"Child_club"];
    txtFieldTeam.text = [dictionary objectForKey:@"Team_Name"];
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [txtFieldEmail setUserInteractionEnabled:NO];
    [self reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)btnSubmit1Clicked:(id)sender{
    if([txtFieldName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldBirthDate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select date of birth" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtField3.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter shirt number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter email id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldMobile.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter mobile" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldCountry.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter nationality" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtField7.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter child club" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldTeam.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter team name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        [activityIndicator startAnimating];
        [txtFieldName resignFirstResponder];
        [txtFieldBirthDate resignFirstResponder];
        [txtField3 resignFirstResponder];
        [txtFieldEmail resignFirstResponder];
        [txtFieldMobile resignFirstResponder];
        [txtFieldCountry resignFirstResponder];
        [txtField7 resignFirstResponder];
        [txtFieldConfirm resignFirstResponder];
        [txtView resignFirstResponder];
        [txtFieldTeam resignFirstResponder];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:txtFieldName.text,ktxtPlayerName,txtFieldBirthDate.text,ktxtDOB,txtField3.text,ktxtShirtNo,txtFieldMobile.text,ktxtMobileNo,txtFieldCountry.text,ktxtNationality,playerId,ktxtUserId,txtField7.text,ktxtChildClub,txtFieldTeam.text,ktxtTeamName, nil];
        [[WebService sharedWebService] callEditPlayerProfileWebService:dictionary];
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if([text isEqualToString:@"\n"]){
        [txtView resignFirstResponder];
    }
    return YES;
}
- (void) fecthUpcomingMatchFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFetchUpcomingMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFetchUpcomingMatchSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void) savePlayerFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerSuccess object:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Error in saving data" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void) savePlayerSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerSuccess object:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Data saved successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void) fecthUpcomingMatchSuccess:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFetchUpcomingMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFetchUpcomingMatchSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    pushDictionary = dictionary;
    txtFieldConfirm.text = [[dictionary objectForKey:@"MatchObject"] objectForKey:@"SecondTeamName"];
}
- (IBAction)btnSubmit2Clicked:(id)sender{
    if([txtFieldConfirm.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0 && ![txtFieldConfirm.text isEqualToString:@"No Match Available"]){
        NSString *selected;
        if(isPlayerAvailable){
            selected = @"1";
        }
        else{
            selected = @"0";
        }
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(savePlayerFailed:) name:kSavePlayerFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(savePlayerSuccess:) name:kSavePlayerSuccess object:nil];
        
        NSDictionary *newDictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId,[pushDictionary objectForKey:@"MatchID"],ktxtMatchId,[pushDictionary objectForKey:@"PlayerTeamId"],ktxtPlayerTeamId,selected,ktxtisAvailable, nil];
        [[WebService sharedWebService] callSavePlayerForUpcomingMatchWebService:newDictionary];
    }
}

- (void)commentsFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCommentsOnMatchByPlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCommentsOnMatchByPlayerSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Error in saving comment" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void)commentsSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCommentsOnMatchByPlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kCommentsOnMatchByPlayerSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Comment added successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (IBAction)btnSaveClicked:(id)sender{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(commentsFailed:) name:kCommentsOnMatchByPlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(commentsSuccess:) name:kCommentsOnMatchByPlayerSuccess object:nil];
    
    [activityIndicator startAnimating];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeauge1 objectForKey:@"LeagueId"],ktxtLeagueId,[selectedMatch1 objectForKey:@"MatchId"],ktxtMatchId,playerId,ktxtUserId,txtView.text,ktxtComment,@"0",ktxtCommentId, nil];
    [[WebService sharedWebService] callCommentsOnMatchByPlayerWebService:dictionary];
}

- (void) voteFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kVoteForPlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kVoteForPlayerSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Error in saving vote" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void) voteSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kVoteForPlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kVoteForPlayerSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Vote added successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (IBAction)btnVoteClicked:(id)sender{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(voteFailed:) name:kVoteForPlayerFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(voteSuccess:) name:kVoteForPlayerSuccess object:nil];
    
    [activityIndicator startAnimating];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeauge1 objectForKey:@"LeagueId"],ktxtLeagueId,[selectedMatch1 objectForKey:@"MatchId"],ktxtMatchId,playerId,ktxtUserId,[selectedPlayer1 objectForKey:@"Playerid"],ktxtVoteForPlayerId,@"0",ktxtVoteId, nil];
    [[WebService sharedWebService] callVoteForPlayerWebService:dictionary];
}
- (IBAction)toggleButton:(id)sender{
    UIButton *button = (UIButton *)sender;
    if([button tag] == 101){
        [btnYES setBackgroundImage:[UIImage imageNamed:@"screen3radiobtnselected.png"] forState:UIControlStateNormal];
        [btnNO setBackgroundImage:[UIImage imageNamed:@"screen3radiobtn.png"] forState:UIControlStateNormal];
        isPlayerAvailable = YES;
    }
    else{
        [btnYES setBackgroundImage:[UIImage imageNamed:@"screen3radiobtn.png"] forState:UIControlStateNormal];
        [btnNO setBackgroundImage:[UIImage imageNamed:@"screen3radiobtnselected.png"] forState:UIControlStateNormal];
        isPlayerAvailable = NO;
    }
}

- (void) leaugeListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
}
- (void) leaugeListSuccess:(NSNotification *)notification{
    isLeaugeList = true;
    isMatchList = false;
    isPlayerList = false;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    leaugeList = [notification.object objectForKey:@"LeagueList"];
    if([leaugeList count] > 0){
        selectedLeauge1 = [leaugeList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackGround setFrame:CGRectMake(pickerBackGround.frame.origin.x,self.view.frame.size.height-pickerBackGround.frame.size.height,pickerBackGround.frame.size.width,pickerBackGround.frame.size.height)];
        [UIView commitAnimations];
        [pickerView selectRow:0 inComponent:0 animated:NO];
        [pickerView reloadAllComponents];
        NSLog(@"Leauge List=%@",notification.object);
    }
}
- (IBAction)buttonLeauge1Clicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}
- (IBAction)buttonLeauge2Clicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}

- (void) matchListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"No Match Found" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void) matchListSuccess:(NSNotification *)notification{
    isMatchList = true;
    isLeaugeList = false;
    isPlayerList = false;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    matchList = [notification.object objectForKey:@"MatchList"];
    if([matchList count] > 0){
        selectedMatch1 = [matchList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackGround setFrame:CGRectMake(pickerBackGround.frame.origin.x,self.view.frame.size.height-pickerBackGround.frame.size.height,pickerBackGround.frame.size.width,pickerBackGround.frame.size.height)];
        [UIView commitAnimations];
        [pickerView selectRow:0 inComponent:0 animated:NO];
        [pickerView reloadAllComponents];
        NSLog(@"Leauge List=%@",notification.object);
    }
}

- (void) playerListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListSuccess object:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"No Player Found" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void) playerListSuccess:(NSNotification *)notification{
    isMatchList = false;
    isLeaugeList = false;
    isPlayerList = true;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListSuccess object:nil];
    playerList = [notification.object objectForKey:@"PlayerList"];
    if([playerList count] > 0){
        selectedPlayer1 = [playerList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackGround setFrame:CGRectMake(pickerBackGround.frame.origin.x,self.view.frame.size.height-pickerBackGround.frame.size.height,pickerBackGround.frame.size.width,pickerBackGround.frame.size.height)];
        [UIView commitAnimations];
        [pickerView selectRow:0 inComponent:0 animated:NO];
        [pickerView reloadAllComponents];
        NSLog(@"PlayerList List=%@",notification.object);
    }
}

- (IBAction)buttonMatch1Clicked:(id)sender{
    if(selectedLeauge1){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerListFailed:) name:kSelectPlayerListFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerListSuccess:) name:kSelectPlayerListSuccess object:nil];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeauge1 objectForKey:@"LeagueId"],ktxtLeagueId,playerId,ktxtUserId, nil];
        [[WebService sharedWebService] callSelectPlayerListWebService:dictionary];
    }
}
- (IBAction)buttonMatch2Clicked:(id)sender{
    if(selectedLeauge1){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchListFailed:) name:kMatchScheduleFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchListSuccess:) name:kMatchScheduleSuccess object:nil];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeauge1 objectForKey:@"LeagueId"],ktxtLeagueId,playerId,ktxtUserId, nil];
        [[WebService sharedWebService] callMatchScheduleWebService:dictionary];
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtFieldName){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldName.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldBirthDate){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [datePickerBackground setFrame:CGRectMake(datePickerBackground.frame.origin.x,self.view.frame.size.height-datePickerBackground.frame.size.height,datePickerBackground.frame.size.width,datePickerBackground.frame.size.height)];
        [UIView commitAnimations];
        return NO;
    }
    else if(textField == txtField3){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtField3.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldEmail){
        return NO;
    }
    else if(textField == txtFieldMobile){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldMobile.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldCountry){
       [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldCountry.frame.origin.y) animated:YES];
    }
    else if(textField == txtField7){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtField7.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldTeam){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldTeam.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldConfirm){
        return NO;
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldName){
        [txtFieldName resignFirstResponder];
        [txtField3 becomeFirstResponder];
    }
    else if(textField == txtField3){
        [txtField3 resignFirstResponder];
        [txtFieldMobile becomeFirstResponder];
    }
    else if(textField == txtFieldMobile){
        [txtFieldMobile resignFirstResponder];
        [txtFieldCountry becomeFirstResponder];
    }
    else if(textField == txtFieldCountry){
        [txtFieldCountry resignFirstResponder];
        [txtField7 becomeFirstResponder];
    }
    else if(textField == txtField7){
        [txtField7 resignFirstResponder];
        [txtFieldTeam becomeFirstResponder];
    }
    else if(textField == txtFieldTeam)
    {
        [txtFieldTeam resignFirstResponder];
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,0) animated:YES];
    }
    else if(textField == txtFieldConfirm){
        [txtFieldConfirm resignFirstResponder];
    }
    return YES;
}

- (IBAction)buttonDoneClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGround setFrame:CGRectMake(pickerBackGround.frame.origin.x,1200,pickerBackGround.frame.size.width,pickerBackGround.frame.size.height)];
    if(isLeaugeList){
        [btnLeauge1 setTitle:[selectedLeauge1 objectForKey:@"Title"] forState:UIControlStateNormal];
        [btnLeauge2 setTitle:[selectedLeauge1 objectForKey:@"Title"] forState:UIControlStateNormal];
    }
    else if(isPlayerList){
        [btnPlayer1 setTitle:[selectedPlayer1 objectForKey:@"PlayerName"] forState:UIControlStateNormal];
    }
    else{
        [btnMatch1 setTitle:[NSString stringWithFormat:@"%@ - %@",[selectedMatch1 objectForKey:@"FirstTeamName"],[selectedMatch1 objectForKey:@"SecondTeamName"]] forState:UIControlStateNormal];
    }
    isLeaugeList = false;
    isPlayerList = false;
    isMatchList = false;
    [UIView commitAnimations];
}
- (IBAction)buttonCancelClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGround setFrame:CGRectMake(pickerBackGround.frame.origin.x,1200,pickerBackGround.frame.size.width,pickerBackGround.frame.size.height)];
    [UIView commitAnimations];
    
    isLeaugeList = false;
    isPlayerList = false;
    isMatchList = false;
    selectedLeauge1 = nil;
    selectedMatch1 = nil;
    selectedPlayer1 = nil;
    
    [btnLeauge1 setTitle:@"Select leauge" forState:UIControlStateNormal];
    [btnLeauge2 setTitle:@"Select leauge" forState:UIControlStateNormal];
    [btnPlayer1 setTitle:@"Select Player" forState:UIControlStateNormal];
    [btnMatch1 setTitle:@"Select Match" forState:UIControlStateNormal];
}

- (IBAction)datePickerDoneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [datePickerBackground setFrame:CGRectMake(datePickerBackground.frame.origin.x,1200,datePickerBackground.frame.size.width,datePickerBackground.frame.size.height)];
    [UIView commitAnimations];
    NSDate *date = datePicker.date;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *stringDate = [dateFormatter stringFromDate:date];
    txtFieldBirthDate.text = stringDate;
}
- (IBAction)datePickerCancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [datePickerBackground setFrame:CGRectMake(datePickerBackground.frame.origin.x,1200,datePickerBackground.frame.size.width,datePickerBackground.frame.size.height)];
    [UIView commitAnimations];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(isLeaugeList){
        return [leaugeList count];
    }
    else if(isPlayerList){
        return [playerList count];
    }
    else{
        return [matchList count];
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(isLeaugeList){
        return [[leaugeList objectAtIndex:row] objectForKey:@"Title"];
    }
    else if(isPlayerList){
        return [[playerList objectAtIndex:row] objectForKey:@"PlayerName"];
    }
    else{
        return [NSString stringWithFormat:@"%@ - %@",[[matchList objectAtIndex:row] objectForKey:@"FirstTeamName"],[[matchList objectAtIndex:row] objectForKey:@"SecondTeamName"]];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(isLeaugeList){
        selectedLeauge1 = [leaugeList objectAtIndex:row];
    }
    else if(isPlayerList){
        selectedPlayer1 = [playerList objectAtIndex:row];
    }
    else{
        selectedMatch1 = [matchList objectAtIndex:row];
    }
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popViewControllerAnimated:YES];
}
@end
