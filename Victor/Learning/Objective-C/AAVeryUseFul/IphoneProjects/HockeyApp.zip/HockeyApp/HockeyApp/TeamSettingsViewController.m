//
//  TeamSettingsViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 25/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "TeamSettingsViewController.h"

@implementation TeamSettingsViewController
@synthesize txtFieldPerGoalPoints;
@synthesize txtFieldPerAssistPoints;
@synthesize txtFieldPenaltyPoints;
@synthesize txtFieldPerYellowCardPoints;
@synthesize pickerBackground;
@synthesize pickerView;
@synthesize btnLeague;
@synthesize activityIndicator;
@synthesize selectedDictionary;
@synthesize leagueList;
@synthesize playerId;
@synthesize backGroundView;
@synthesize lbl1;
@synthesize lbl2;
@synthesize lbl3;
@synthesize lbl4;
@synthesize settingDictionary;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}
- (void)getPointsFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [backGroundView setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetLeaugePointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetLeaugePointSuccess object:nil];
}
- (void) reloadViews{
    lbl1.text = [selectedDictionary objectForKey:@"Title"];
    lbl2.text = [settingDictionary objectForKey:@"PerGoalPoint"];
    lbl3.text = [settingDictionary objectForKey:@"PerAssistPoint"];
    lbl4.text = [settingDictionary objectForKey:@"PerPenaltyCardPoint"];
}
- (void)getPointsSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetLeaugePointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kGetLeaugePointSuccess object:nil];
    NSArray *array = [notification.object objectForKey:@"LeagueSetting"];
    if([array count] > 0){
        [backGroundView setHidden:NO];
        settingDictionary = [array objectAtIndex:0];
        [self reloadViews];
    }
    else{
        [backGroundView setHidden:YES];
    }
    
}
- (void) getPointsData{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPointsFailed:) name:kGetLeaugePointFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPointsSuccess:) name:kGetLeaugePointSuccess object:nil];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedDictionary objectForKey:@"LeagueId"],ktxtLeagueId, nil];
    [[WebService sharedWebService] callGetLeaugePointSettingWebService:dictionary];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
}


- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) leaugeListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
}
- (void) leaugeListSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    leagueList = [notification.object objectForKey:@"LeagueList"];
    if([leagueList count] > 0){
        selectedDictionary = [leagueList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [pickerView reloadAllComponents];
    }
}

- (IBAction)leagueButtonClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}

- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    [btnLeague setTitle:[selectedDictionary objectForKey:@"Title"] forState:UIControlStateNormal];
    [self getPointsData];
}
- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    [btnLeague setTitle:@"Select League" forState:UIControlStateNormal];
    selectedDictionary = nil;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [leagueList count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [[leagueList objectAtIndex:row] objectForKey:@"Title"];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    selectedDictionary = [leagueList objectAtIndex:row];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtFieldPenaltyPoints){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-50,self.view.frame.size.width, self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldPerYellowCardPoints){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-100,self.view.frame.size.width, self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldPerGoalPoints){
        [txtFieldPerGoalPoints resignFirstResponder];
        [txtFieldPerAssistPoints becomeFirstResponder];
    }
    else if(textField == txtFieldPerAssistPoints){
        [txtFieldPerAssistPoints resignFirstResponder];
        [txtFieldPenaltyPoints becomeFirstResponder];
    }
    else if(textField == txtFieldPenaltyPoints){
        [txtFieldPenaltyPoints resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,0,self.view.frame.size.width, self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}
- (void) addPointsFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddPointsToLeaugeFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddPointsToLeaugeSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void) addPointsSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddPointsToLeaugeFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddPointsToLeaugeSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [self getPointsData];
}

- (IBAction)saveButtonClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addPointsFailed:) name:kAddPointsToLeaugeFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addPointsSuccess:) name:kAddPointsToLeaugeSuccess object:nil];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedDictionary objectForKey:@"LeagueId"],ktxtLeagueId,txtFieldPerGoalPoints.text,kPerGoalPoint,txtFieldPerAssistPoints.text,kPerAssistPoint,txtFieldPenaltyPoints.text,kPerPenaltyCardPoint,nil];
    [[WebService sharedWebService] callAddPointsToLeaugeWebService:dictionary];
}

@end
