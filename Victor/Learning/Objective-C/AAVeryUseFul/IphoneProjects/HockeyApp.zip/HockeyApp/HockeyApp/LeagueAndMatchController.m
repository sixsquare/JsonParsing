//
//  LeagueAndMatchController.m
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "LeagueAndMatchController.h"
#import "LeagueViewController.h"
#import "ViewMatchReportViewController.h"

@implementation LeagueAndMatchController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)leagueButtonClicked:(id)sender{
    LeagueViewController *leagueViewController = [[LeagueViewController alloc] initWithNibName:@"LeagueViewController" bundle:nil];
    [self.navigationController pushViewController:leagueViewController animated:YES];
}
- (IBAction)viewMatchReportClicked:(id)sender{
    ViewMatchReportViewController *viewMatchreport = [[ViewMatchReportViewController alloc] initWithNibName:@"ViewMatchReportViewController" bundle:nil];
    [self.navigationController pushViewController:viewMatchreport animated:YES];
}
- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
