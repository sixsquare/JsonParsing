//
//  WebService.m
//  HockeyApp
//
//  Created by Amit Parmar on 21/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "WebService.h"
#import "ASIFormDataRequest.h"

static WebService *webService;
@implementation WebService


+(WebService *)sharedWebService{
    if(!webService){
        webService = [[WebService alloc] init];
    }
    return webService;
}

- (void) loginResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary) {
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSuccess object:dictionary];
        }
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Error in login please try again later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}

- (void) callLoginWebService:(NSDictionary *)dictionary{
    // Add device Toke Here
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/login.php?txtEMail=%@&txtPassword=%@&DeviceToken=%@",[dictionary objectForKey:kUserName],[dictionary objectForKey:kPassword],[dictionary objectForKey:kDeviceToken]];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(loginResponse:)];
    [request startAsynchronous];
}

- (void) forgotPassResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary) {
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kForgorPassFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kForgorPassSuccess object:dictionary];
        }
    }
}


- (void) callForgotPasswordWebService:(NSDictionary *)dictionary{
    // Add device Toke Here
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/forgot-password.php?txtEMail=%@",[dictionary objectForKey:@"txtEMail"]];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(forgotPassResponse:)];
    [request startAsynchronous];
}

- (void) leaugeListResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kLeaugeListFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kLeaugeListSuccess object:dictionary];
        }
    }
}

- (void) callLeaugeListWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/leaguelist.php?txtUserId=%@",[dictionary objectForKey:ktxtUserId]];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(leaugeListResponse:)];
    [request startAsynchronous];
}

- (void) matchScheduleResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kMatchScheduleFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kMatchScheduleSuccess object:dictionary];
        }
    }
}

- (void) callMatchScheduleWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/matchlist.php?txtUserId=%@&txtLeagueId=%@",[dictionary objectForKey:ktxtUserId],[dictionary objectForKey:ktxtLeagueId]];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(matchScheduleResponse:)];
    [request startAsynchronous];
}


- (void) teamSelectionResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kTeamSelectionFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kTeamSelectionSuccess object:dictionary];
        }
    }
}

- (void) callTeamSelectionWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/add-selected-team.php?txtLeagueId=%@&txtMatchId=%@&txtTeamId=%@&txtPlayersId=%@&txtComments=%@",[dictionary objectForKey:ktxtLeagueId],[dictionary objectForKey:ktxtMatchId],[dictionary objectForKey:ktxtTeamId],[dictionary objectForKey:ktxtPlayersId],[dictionary objectForKey:ktxtComments]];
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(teamSelectionResponse:)];
    [request startAsynchronous];
}

- (void) playerListResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kPlayerListFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kPlayerListSuccess object:dictionary];
        }
    }
}

- (void) callPlayerListWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/playerlist.php?txtLeagueId=%@&txtUserId=%@",[dictionary objectForKey:ktxtLeagueId],[dictionary objectForKey:ktxtUserId]];
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(playerListResponse:)];
    [request startAsynchronous];
}

- (void) addPointsToLeaugeResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kAddPointsToLeaugeFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kAddPointsToLeaugeSuccess object:dictionary];
        }
    }
}

- (void) callAddPointsToLeaugeWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/league-setting.php?txtLeagueId=%@&txtPerGoalPoint=%@&txtPerAssistPoint=%@&txtPerPenaltyCardPoint=%@",[dictionary objectForKey:ktxtLeagueId],[dictionary objectForKey:kPerGoalPoint],[dictionary objectForKey:kPerAssistPoint],[dictionary objectForKey:kPerPenaltyCardPoint]];
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(addPointsToLeaugeResponse:)];
    [request startAsynchronous];
}

- (void) getLeaugePointResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetLeaugePointFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetLeaugePointSuccess object:dictionary];
        }
    }
}

- (void) callGetLeaugePointSettingWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/get-league-setting.php?txtLeagueId=%@",[dictionary objectForKey:ktxtLeagueId]];
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(getLeaugePointResponse:)];
    [request startAsynchronous];
}

- (void) addFinanceDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kAddFinanceFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kAddFinanceSuccess object:dictionary];
        }
    }
}

- (void) callAddFinanceDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"INSERT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtCategory] forKey:ktxtCategory];
    [request addPostValue:[dictionary objectForKey:ktxtCharges] forKey:ktxtCharges];
    [request addPostValue:[dictionary objectForKey:ktxtPaidCharges] forKey:ktxtPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtUnPaidCharges] forKey:ktxtUnPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtEntryDate] forKey:ktxtEntryDate];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    //[request addPostValue:[dictionary objectForKey:ktxtFinanceId] forKey:ktxtFinanceId];
    
    [request setDidFinishSelector:@selector(addFinanceDetailResponse:)];
    [request startAsynchronous];
}

- (void) editFinanceDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kEditFinanceFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kEditFinanceSuccess object:dictionary];
        }
    }
}

- (void) callEditFinanceDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtCategory] forKey:ktxtCategory];
    [request addPostValue:[dictionary objectForKey:ktxtCharges] forKey:ktxtCharges];
    [request addPostValue:[dictionary objectForKey:ktxtPaidCharges] forKey:ktxtPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtUnPaidCharges] forKey:ktxtUnPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtEntryDate] forKey:ktxtEntryDate];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    [request addPostValue:[dictionary objectForKey:ktxtFinanceId] forKey:ktxtFinanceId];
    [request setDidFinishSelector:@selector(editFinanceDetailResponse:)];
    [request startAsynchronous];
}

- (void) deleteFinanceDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteFinanceFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteFinanceSuccess object:dictionary];
        }
    }
}

- (void) callDeleteFinanceDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"DELETE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtFinanceId] forKey:ktxtFinanceId];
    [request setDidFinishSelector:@selector(deleteFinanceDetailResponse:)];
    [request startAsynchronous];
}

- (void) selectFinanceDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectFinanceFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectFinanceSuccess object:dictionary];
        }
    }
}

- (void) callSelectFinanceDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    [request setDidFinishSelector:@selector(selectFinanceDetailResponse:)];
    [request startAsynchronous];
}

- (void) addTransactionDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kAddTransactionFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kAddTransactionSuccess object:dictionary];
        }
    }
}

- (void) callAddTransactionDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-transaction-to-finance.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"INSERT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerName] forKey:ktxtPlayerName];
    [request addPostValue:[dictionary objectForKey:ktxtCharges] forKey:ktxtCharges];
    [request addPostValue:[dictionary objectForKey:ktxtPaidCharges] forKey:ktxtPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtUnPaidCharges] forKey:ktxtUnPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtTransactionDate] forKey:ktxtTransactionDate];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    //[request addPostValue:[dictionary objectForKey:ktxtTransactionId] forKey:ktxtTransactionId];
    [request setDidFinishSelector:@selector(addTransactionDetailResponse:)];
    [request startAsynchronous];
}

- (void) editTransactionDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kEditTransactionFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kEditTransactionSuccess object:dictionary];
        }
    }
}

- (void) callEditTransactionDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-transaction-to-finance.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerName] forKey:ktxtPlayerName];
    [request addPostValue:[dictionary objectForKey:ktxtCharges] forKey:ktxtCharges];
    [request addPostValue:[dictionary objectForKey:ktxtPaidCharges] forKey:ktxtPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtUnPaidCharges] forKey:ktxtUnPaidCharges];
    [request addPostValue:[dictionary objectForKey:ktxtTransactionDate] forKey:ktxtTransactionDate];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    [request addPostValue:[dictionary objectForKey:ktxtTransactionId] forKey:ktxtTransactionId];
    [request setDidFinishSelector:@selector(editTransactionDetailResponse:)];
    [request startAsynchronous];
}

- (void) deleteTransactionDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteTransactionFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteTransactionSuccess object:dictionary];
        }
    }
}

- (void) callDeleteTransactionDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-transaction-to-finance.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"DELETE" forKey:kCRUDMethod];
     [request addPostValue:[dictionary objectForKey:ktxtTransactionId] forKey:ktxtTransactionId];
    [request setDidFinishSelector:@selector(deleteTransactionDetailResponse:)];
    [request startAsynchronous];
}

- (void) selectTransactionDetailResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectTransactionFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectTransactionSuccess object:dictionary];
        }
    }
}


- (void) callSelectTransactionDetailWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-transaction-to-finance.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    [request setDidFinishSelector:@selector(selectTransactionDetailResponse:)];
    [request startAsynchronous];
}

- (void) getPlayerProfileResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetPlayerProfileFailed object:dictionary];
        }
        else{
            NSDictionary *finalDictionary = [NSDictionary dictionaryWithObjectsAndKeys:[[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtChildClub"],@"Child_club", [[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtDOB"],@"Player_DOB",[[[NSUserDefaults standardUserDefaults] objectForKey:kProfileData] objectForKey:@"Emailid"],@"Emailid",[[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtMobileNo"],@"Mobileno",[[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtNationality"],@"Nationality",[[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtPlayerName"],@"Name",[[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtShirtNo"],@"Shirt_no",[[dictionary objectForKey:@"PlayerObject"] objectForKey:@"txtUserId"],@"Playerid",[[[NSUserDefaults standardUserDefaults] objectForKey:kProfileData] objectForKey:@"RoleId"],@"RoleId",[[[NSUserDefaults standardUserDefaults] objectForKey:kProfileData] objectForKey:@"RoleName"],@"RoleName",nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetPlayerProfileSuccess object:[NSDictionary dictionaryWithObjectsAndKeys:finalDictionary,@"UserProfile", nil]];
        }
    }
}

- (void) callGetPlayerProfileWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/edit-player-profile.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request setDidFinishSelector:@selector(getPlayerProfileResponse:)];
    [request startAsynchronous];
}

- (void) editPlayerProfileResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kEditPlayerProfileFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kEditPlayerProfileSuccess object:dictionary];
        }
    }
}

- (void) callEditPlayerProfileWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/edit-player-profile.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerName] forKey:ktxtPlayerName];
    [request addPostValue:[dictionary objectForKey:ktxtNationality] forKey:ktxtNationality];
    [request addPostValue:[dictionary objectForKey:ktxtChildClub] forKey:ktxtChildClub];
    [request addPostValue:[dictionary objectForKey:ktxtShirtNo] forKey:ktxtShirtNo];
    [request addPostValue:[dictionary objectForKey:ktxtMobileNo] forKey:ktxtMobileNo];
    [request addPostValue:[dictionary objectForKey:ktxtDOB] forKey:ktxtDOB];
    
    [request setDidFinishSelector:@selector(editPlayerProfileResponse:)];
    [request startAsynchronous];
}

- (void) fetchUpcomingMatchResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kFetchUpcomingMatchFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kFetchUpcomingMatchSuccess object:dictionary];
        }
    }
}

- (void) callFetchUpcomingMatchWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/save-get-player-availability.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request setDidFinishSelector:@selector(fetchUpcomingMatchResponse:)];
    [request startAsynchronous];
}

- (void) savePlayerResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSavePlayerFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSavePlayerSuccess object:dictionary];
        }
    }
}

- (void) callSavePlayerForUpcomingMatchWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/save-get-player-availability.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtMatchId] forKey:ktxtMatchId];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerTeamId] forKey:ktxtPlayerTeamId];
    [request addPostValue:[dictionary objectForKey:ktxtisAvailable] forKey:ktxtisAvailable];
    [request setDidFinishSelector:@selector(savePlayerResponse:)];
    [request startAsynchronous];
}

- (void) finishedMatchListResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kFinishedMatchFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kFinishedMatchSuccess object:dictionary];
        }
    }
}

- (void) callGetFinishedMatchListWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/get-finished-match-list.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request setDidFinishSelector:@selector(finishedMatchListResponse:)];
    [request startAsynchronous];
}

- (void) saveMatchPointResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSaveMatchPointFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSaveMatchPointSuccess object:dictionary];
        }
    }
}


- (void) callSaveMatchPointWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-points-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"INSERT-UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtMatchId] forKey:ktxtMatchId];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtPointId] forKey:ktxtPointId];
    [request addPostValue:[dictionary objectForKey:ktxtHomeTeamId] forKey:ktxtHomeTeamId];
    [request addPostValue:[dictionary objectForKey:ktxtHTGoal] forKey:ktxtHTGoal];
    [request addPostValue:[dictionary objectForKey:ktxtHTAssist] forKey:ktxtHTAssist];
    [request addPostValue:[dictionary objectForKey:ktxtHTRedCard] forKey:ktxtHTRedCard];
    [request addPostValue:[dictionary objectForKey:ktxtHTYellowPoint] forKey:ktxtHTYellowPoint];
    [request addPostValue:[dictionary objectForKey:ktxtHTPoints] forKey:ktxtHTPoints];
    [request addPostValue:[dictionary objectForKey:ktxtAwayTeamId] forKey:ktxtAwayTeamId];
    [request addPostValue:[dictionary objectForKey:ktxtATGoal] forKey:ktxtATGoal];
    [request addPostValue:[dictionary objectForKey:ktxtATAssist] forKey:ktxtATAssist];
    [request addPostValue:[dictionary objectForKey:ktxtATRedCard] forKey:ktxtATRedCard];
    [request addPostValue:[dictionary objectForKey:ktxtATYellowPoint] forKey:ktxtATYellowPoint];
    [request addPostValue:[dictionary objectForKey:ktxtATPoints] forKey:ktxtATPoints];
    [request addPostValue:[dictionary objectForKey:ktxtMatchStatus] forKey:ktxtMatchStatus];
    [request addPostValue:[dictionary objectForKey:ktxtWonTeamId] forKey:ktxtWonTeamId];
    [request addPostValue:[dictionary objectForKey:ktxtRemarks] forKey:ktxtRemarks];
    [request setDidFinishSelector:@selector(saveMatchPointResponse:)];
    [request startAsynchronous];
}

- (void) selectMatchPointResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectMatchPointFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectMatchPointSuccess object:dictionary];
        }
    }
}


- (void) callSelectMatchPointWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-points-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtMatchId] forKey:ktxtMatchId];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request setDidFinishSelector:@selector(selectMatchPointResponse:)];
    [request startAsynchronous];
}

- (void) savePlayerPointResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSavePlayerPointFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSavePlayerPointSuccess object:dictionary];
        }
    }
}

- (void) callSavePlayerPointWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-points-to-player.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"INSERT-UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtMatchId] forKey:ktxtMatchId];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtPointId] forKey:ktxtPointId];
    [request addPostValue:[dictionary objectForKey:ktxtTeamId] forKey:ktxtTeamId];
    [request addPostValue:[dictionary objectForKey:ktxtHTGoal] forKey:ktxtHTGoal];
    [request addPostValue:[dictionary objectForKey:ktxtHTAssist] forKey:ktxtHTAssist];
    [request addPostValue:[dictionary objectForKey:ktxtHTRedCard] forKey:ktxtHTRedCard];
    [request addPostValue:[dictionary objectForKey:ktxtHTYellowPoint] forKey:ktxtHTYellowPoint];
    [request addPostValue:[dictionary objectForKey:ktxtHTPoints] forKey:ktxtHTPoints];
    [request addPostValue:[dictionary objectForKey:ktxtRemarks] forKey:ktxtRemarks];
    [request addPostValue:[dictionary objectForKey:ktxtPlayerId] forKey:ktxtPlayerId];
    [request setDidFinishSelector:@selector(savePlayerPointResponse:)];
    [request startAsynchronous];
}

- (void) selectPlayerPointResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectPlayerPointFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectPlayerPointSuccess object:dictionary];
        }
    }
}

- (void) callSelectPlayerPointWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-points-to-player.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtHomeTeamId] forKey:ktxtHomeTeamId];
    [request addPostValue:[dictionary objectForKey:ktxtAwayTeamId] forKey:ktxtAwayTeamId];
    [request setDidFinishSelector:@selector(selectPlayerPointResponse:)];
    [request startAsynchronous];
}

- (void) playerStandingListResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kPlayerStandingListFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kPlayerStandingListSuccess object:dictionary];
        }
    }
}

- (void) callPlayerStandingListWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/player-standing.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request setDidFinishSelector:@selector(playerStandingListResponse:)];
    [request startAsynchronous];
}

- (void) leaugeWiseTeamListResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kLeaugeWiseTeamListFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kLeaugeWiseTeamListSuccess object:dictionary];
        }
    }
}

- (void) callLeaugeWiseTeamListWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/leaguewise-team-list.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request setDidFinishSelector:@selector(leaugeWiseTeamListResponse:)];
    [request startAsynchronous];
}

- (void) teamWiseUpcomingMatchResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kTeamWiseUpcomingMatchFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kTeamWiseUpcomingMatchSuccess object:dictionary];
        }
    }
}

- (void) callTeamWiseUpcomingMatchWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/team-wise-upcoming-matches.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtTeamId] forKey:ktxtTeamId];
    [request setDidFinishSelector:@selector(teamWiseUpcomingMatchResponse:)];
    [request startAsynchronous];
}
- (void) commentsOnMatchByPlayerResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kCommentsOnMatchByPlayerFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kCommentsOnMatchByPlayerSuccess object:dictionary];
        }
    }
}

- (void) callCommentsOnMatchByPlayerWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-comments-to-match.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"INSERT-UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtMatchId] forKey:ktxtMatchId];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtComment] forKey:ktxtComment];
    [request addPostValue:[dictionary objectForKey:ktxtCommentId] forKey:ktxtCommentId];
    [request setDidFinishSelector:@selector(commentsOnMatchByPlayerResponse:)];
    [request startAsynchronous];
}

- (void) deleteCommentResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteCommentFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteCommentSuccess object:dictionary];
        }
    }
}

- (void) callDeleteCommentsWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-comments-to-match.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"DELETE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtCommentId] forKey:ktxtCommentId];
    [request setDidFinishSelector:@selector(deleteCommentResponse:)];
    [request startAsynchronous];
}

- (void) selectCommentResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectCommentFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectCommentSuccess object:dictionary];
        }
    }
}

- (void) callSelectCommentWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-comments-to-match.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request setDidFinishSelector:@selector(selectCommentResponse:)];
    [request startAsynchronous];
}

- (void) voteForPlayerResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kVoteForPlayerFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kVoteForPlayerSuccess object:dictionary];
        }
    }
}

- (void) callVoteForPlayerWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-vote-for-player.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"INSERT-UPDATE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtMatchId] forKey:ktxtMatchId];
    [request addPostValue:[dictionary objectForKey:ktxtUserId] forKey:ktxtUserId];
    [request addPostValue:[dictionary objectForKey:ktxtVoteForPlayerId] forKey:ktxtVoteForPlayerId];
    [request addPostValue:[dictionary objectForKey:ktxtVoteId] forKey:ktxtVoteId];
    [request setDidFinishSelector:@selector(voteForPlayerResponse:)];
    [request startAsynchronous];
}

- (void) deleteVoteResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteVoteFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kDeleteVoteSuccess object:dictionary];
        }
    }
}

- (void) callDeleteVoteWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-vote-for-player.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"DELETE" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtVoteId] forKey:ktxtVoteId];
    [request setDidFinishSelector:@selector(deleteVoteResponse:)];
    [request startAsynchronous];
}

- (void) getSelectedTeamResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetSelectedTeamFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kGetSelectedTeamSuccess object:dictionary];
        }
    }
}

- (void) callGetSelectedteamForSelectedMatchWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/get-selected-team-by-match.php?txtMatchId=%@&txtLeagueId=%@&txtTeamId=%@",[dictionary objectForKey:ktxtMatchId],[dictionary objectForKey:ktxtLeagueId],[dictionary objectForKey:ktxtTeamId]];
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(getSelectedTeamResponse:)];
    [request startAsynchronous];
}

- (void) selectPlayerListResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectPlayerListFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kSelectPlayerListSuccess object:dictionary];
        }
    }
}

- (void) callSelectPlayerListWebService:(NSDictionary *)dictionary{
    NSString *url = [NSString stringWithFormat:@"http://soccerapp.astrowow.com/webservice/get-playerlist-for-vote.php?txtLeagueId=%@",[dictionary objectForKey:ktxtLeagueId]];
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(selectPlayerListResponse:)];
    [request startAsynchronous];
}

- (void) teamStandingResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kTeamStandingFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kTeamStandingSuccess object:dictionary];
        }
    }
}


- (void) callTeamStaningWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/team-standing.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request setDidFinishSelector:@selector(teamStandingResponse:)];
    [request startAsynchronous];
}

- (void) previousMatchResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kPreviousMatchFailed object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kPreviousMatchSuccess object:dictionary];
        }
    }
}

- (void) callPreviousMatchResultWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/previous-match-results.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request addPostValue:@"SELECT" forKey:kCRUDMethod];
    [request addPostValue:[dictionary objectForKey:ktxtLeagueId] forKey:ktxtLeagueId];
    [request addPostValue:[dictionary objectForKey:ktxtTeamId] forKey:ktxtTeamId];
    [request setDidFinishSelector:@selector(previousMatchResponse:)];
    [request startAsynchronous];
}
@end
