//
//  PointsViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 27/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PointsViewController : UIViewController


@property (nonatomic, strong) IBOutlet UITextField *txtFieldGoal;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldAssist;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldRedcard;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldYellowCard;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldTotalPoints;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) IBOutlet UILabel *lblPlayerName;

@property (nonatomic, strong) NSDictionary *selectedMatch;
@property (nonatomic, strong) NSString *selectedLeague;
@property (nonatomic, strong) NSDictionary *selectedPlayer;

- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;
- (IBAction)saveButtonClicked:(id)sender;

@end
