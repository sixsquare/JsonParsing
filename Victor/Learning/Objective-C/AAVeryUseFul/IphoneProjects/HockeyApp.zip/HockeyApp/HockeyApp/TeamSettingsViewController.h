//
//  TeamSettingsViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 25/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamSettingsViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITextField *txtFieldPerGoalPoints;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPerAssistPoints;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPenaltyPoints;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPerYellowCardPoints;
@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;
@property (nonatomic, strong) IBOutlet UIButton *btnLeague;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) NSDictionary *selectedDictionary;
@property (nonatomic, strong) NSArray *leagueList;
@property (nonatomic, strong) NSString *playerId;

@property (nonatomic, strong) IBOutlet UIView *backGroundView;
@property (nonatomic, strong) IBOutlet UILabel *lbl1;
@property (nonatomic, strong) IBOutlet UILabel *lbl2;
@property (nonatomic, strong) IBOutlet UILabel *lbl3;
@property (nonatomic, strong) IBOutlet UILabel *lbl4;
@property (nonatomic, strong) NSDictionary *settingDictionary;

- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

- (IBAction)saveButtonClicked:(id)sender;
- (IBAction)leagueButtonClicked:(id)sender;

- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;

@end
