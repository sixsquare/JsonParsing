//
//  PlayerStandingCell.m
//  HockeyApp
//
//  Created by Amit Parmar on 25/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "PlayerStandingCell.h"

@implementation PlayerStandingCell

@synthesize lblPlayerName;
@synthesize lblMatch;
@synthesize lblG;
@synthesize lblA;
@synthesize lblR;
@synthesize lblY;
@synthesize lblPoints;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated{
    [super setSelected:selected animated:animated];
}

@end
