//
//  FinanceViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FinanceViewController : UIViewController



@property (nonatomic, strong) IBOutlet UIButton *btnLeague;
@property (nonatomic, strong) IBOutlet UIButton *btnPlayer;
@property (nonatomic, strong) IBOutlet UITableView *tblView1;
@property (nonatomic, strong) IBOutlet UITableView *tblView2;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIPickerView *picker;
@property (nonatomic, strong) IBOutlet UILabel *totalFinance;
@property (nonatomic, strong) IBOutlet UILabel *totalTransaction;

@property (nonatomic) BOOL isLeagueList;
@property (nonatomic) BOOL isPlayerList;
@property (nonatomic, strong) NSArray *leagueList;
@property (nonatomic, strong) NSArray *playerList;
@property (nonatomic, strong) NSDictionary *selectedLeague;
@property (nonatomic, strong) NSDictionary *selectedPlayer;
@property (nonatomic, strong) NSString *playerId;
@property (nonatomic, strong) NSArray *array1;
@property (nonatomic, strong) NSArray *array2;

- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;
- (IBAction)leagueButtonClicked:(id)sender;
- (IBAction)playerButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)addMoreFinanceClicked:(id)sender;
- (IBAction)addMoreTransactionClicked:(id)sender;

@end
