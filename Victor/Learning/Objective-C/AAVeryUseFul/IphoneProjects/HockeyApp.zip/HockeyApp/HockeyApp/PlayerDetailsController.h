//
//  PlayerDetailsController.h
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeagueAndMatchController.h"
#import "SelectYourChoiceController.h"


@interface PlayerDetailsController : UIViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate>{

}
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldBirthDate;
@property (nonatomic, strong) IBOutlet UITextField *txtField3;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldMobile;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldCountry;
@property (nonatomic, strong) IBOutlet UITextField *txtField7;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldTeam;

@property (nonatomic, strong) IBOutlet UITextField *txtFieldConfirm;
@property (nonatomic, strong) IBOutlet UIButton *btnYES;
@property (nonatomic, strong) IBOutlet UIButton *btnNO;

@property (nonatomic, strong) IBOutlet UITextView *txtView;
@property (nonatomic, strong) NSString *playerId;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic) BOOL isLeaugeList;
@property (nonatomic) BOOL isMatchList;
@property (nonatomic) BOOL isPlayerList;
@property (nonatomic, strong) NSArray *leaugeList;
@property (nonatomic, strong) NSArray *matchList;
@property (nonatomic, strong) NSArray *playerList;
@property (nonatomic, strong) NSDictionary *selectedLeauge1;
@property (nonatomic, strong) NSDictionary *selectedMatch1;
@property (nonatomic, strong) NSDictionary *selectedPlayer1;

@property (nonatomic, strong) IBOutlet UIView *pickerBackGround;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;

@property (nonatomic, strong) IBOutlet UIView *datePickerBackground;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;

@property (nonatomic, strong) IBOutlet UIButton *btnLeauge1;
@property (nonatomic, strong) IBOutlet UIButton *btnLeauge2;
@property (nonatomic, strong) IBOutlet UIButton *btnMatch1;
@property (nonatomic, strong) IBOutlet UIButton *btnPlayer1;
@property (nonatomic) BOOL isPlayerAvailable;
@property (nonatomic, strong) NSString *alertText;
@property (nonatomic, strong) NSDictionary *pushDictionary;


- (IBAction)btnSubmit1Clicked:(id)sender;
- (IBAction)btnSubmit2Clicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
- (IBAction)btnVoteClicked:(id)sender;
- (IBAction)toggleButton:(id)sender;
- (IBAction)buttonLeauge1Clicked:(id)sender;
- (IBAction)buttonLeauge2Clicked:(id)sender;
- (IBAction)buttonMatch1Clicked:(id)sender;
- (IBAction)buttonMatch2Clicked:(id)sender;
- (IBAction)buttonDoneClicked:(id)sender;
- (IBAction)buttonCancelClicked:(id)sender;

- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

- (IBAction)datePickerDoneButtonClicked:(id)sender;
- (IBAction)datePickerCancelButtonClicked:(id)sender;

- (void) editPlayerProfileFailed:(NSNotification *)notification;
- (void) editPlayerProfileSuccess:(NSNotification *)notification;
- (void) getPlayerProfileFailed:(NSNotification *)notification;
- (void) getPlayerProfileSuccess:(NSNotification *)notification;
- (void) reloadData;
- (void) fetchUpcomingMatch:(NSString *)userId;
@end
