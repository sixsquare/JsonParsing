//
//  TeamSettingAndMatchReportViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 25/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamSettingAndMatchReportViewController : UIViewController

- (IBAction)teamSettingsClicked:(id)sender;
- (IBAction)matchReportClicked:(id)sender;
- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

@end
