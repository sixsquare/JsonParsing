//
//  FinanceViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "FinanceViewController.h"
#import "FinanceCell.h"
#import "AddFinanceViewController.h"
#import "AddTransactionViewController.h"

@implementation FinanceViewController
@synthesize btnLeague;
@synthesize btnPlayer;
@synthesize tblView1;
@synthesize tblView2;
@synthesize activityIndicator;
@synthesize pickerBackground;
@synthesize picker;
@synthesize isLeagueList;
@synthesize isPlayerList;
@synthesize leagueList;
@synthesize playerList;
@synthesize selectedLeague;
@synthesize selectedPlayer;
@synthesize playerId;
@synthesize array1;
@synthesize array2;
@synthesize totalFinance;
@synthesize totalTransaction;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
    
    if(selectedLeague && selectedPlayer){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDetailFailed:) name:kSelectFinanceFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDetailSuccess:) name:kSelectFinanceSuccess object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDetailFailed:) name:kSelectTransactionFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDetailSuccess:) name:kSelectTransactionSuccess object:nil];
        [activityIndicator startAnimating];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId,[selectedPlayer objectForKey:@"Playerid"],ktxtPlayerId, nil];
        [[WebService sharedWebService] callSelectFinanceDetailWebService:dictionary];
        
        [[WebService sharedWebService] callSelectTransactionDetailWebService:dictionary];
    }
}


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) leaugeListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
}
- (void) leaugeListSuccess:(NSNotification *)notification{
    isLeagueList = true;
    isPlayerList = false;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    leagueList = [notification.object objectForKey:@"LeagueList"];
    if([leagueList count] > 0){
        selectedLeague = [leagueList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
    }
}


- (IBAction)leagueButtonClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}

- (void) playerListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerListSuccess object:nil];
}
- (void) playerListSuccess:(NSNotification *)notification{
    isLeagueList = false;
    isPlayerList = true;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerListSuccess object:nil];
    playerList = [notification.object objectForKey:@"PlayerList"];
    if([playerList count] > 0){
        selectedPlayer = [playerList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
        NSLog(@"Team List=%@",notification.object);
    }
}

- (IBAction)playerButtonClicked:(id)sender{
    if(selectedLeague){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerListFailed:) name:kPlayerListFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerListSuccess:) name:kPlayerListSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,playerId,ktxtUserId, nil];
        [[WebService sharedWebService] callPlayerListWebService:dictionary];
    }
}

- (void) financeDetailFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [self.tblView1 setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectFinanceFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectFinanceSuccess object:nil];
}

- (void) financeDetailSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectFinanceFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectFinanceSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    array1 = [dictionary objectForKey:@"FinanceList"];
    float charges = 0;
    float paid = 0;
    float unPaid = 0;
    for(int i=0;i<[array1 count];i++){
        charges = charges + [[[array1 objectAtIndex:i] objectForKey:@"txtCharges"] intValue];
        paid = paid + [[[array1 objectAtIndex:i] objectForKey:@"txtPaidCharges"] intValue];
        unPaid = unPaid + [[[array1 objectAtIndex:i] objectForKey:@"txtUnPaidCharges"] intValue];
    }
    if([array1 count] > 0){
        NSMutableArray *tempArray = [[NSMutableArray alloc] initWithArray:array1];
        NSDictionary *totalDictionary = [NSDictionary dictionaryWithObjectsAndKeys:@"Total",@"txtCategory",[NSString stringWithFormat:@"%.2f",charges],@"txtCharges",[NSString stringWithFormat:@"%.2f",paid],@"txtPaidCharges",[NSString stringWithFormat:@"%.2f",unPaid],@"txtUnPaidCharges", nil];
        [tempArray addObject:totalDictionary];
        array1 = tempArray;
        [self.tblView1 setHidden:NO];
        [self.tblView1 reloadData];
    }
    else{
        [self.tblView1 setHidden:YES];
    }
}

- (void) transactionDetailFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [self.tblView2 setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectTransactionSuccess object:nil];
}

- (void) transactionDetailSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectTransactionSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    array2 = [dictionary objectForKey:@"TransactionList"];
    float charges = 0;
    float paid = 0;
    float unPaid = 0;
    for(int i=0;i<[array2 count];i++){
        charges = charges + [[[array2 objectAtIndex:i] objectForKey:@"txtCharges"] intValue];
        paid = paid + [[[array2 objectAtIndex:i] objectForKey:@"txtPaidCharges"] intValue];
        unPaid = unPaid + [[[array2 objectAtIndex:i] objectForKey:@"txtUnPaidCharges"] intValue];
    }
    if([array2 count] > 0){
        NSMutableArray *tempArray = [[NSMutableArray alloc] initWithArray:array2];
        NSDictionary *totalDictionary = [NSDictionary dictionaryWithObjectsAndKeys:@"Total",@"PlayerName",[NSString stringWithFormat:@"%.2f",charges],@"txtCharges",[NSString stringWithFormat:@"%.2f",paid],@"txtPaidCharges",[NSString stringWithFormat:@"%.2f",unPaid],@"txtUnPaidCharges", nil];
        [tempArray addObject:totalDictionary];
        array2 = tempArray;
        
        [self.tblView2 setHidden:NO];
        [self.tblView2 reloadData];
    }
    else{
        [self.tblView2 setHidden:YES];
    }
}


- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    if(isLeagueList){
        [btnLeague setTitle:[selectedLeague objectForKey:@"Title"] forState:UIControlStateNormal];
    }
    else if(isPlayerList){
        [btnPlayer setTitle:[selectedPlayer objectForKey:@"PlayerName"] forState:UIControlStateNormal];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDetailFailed:) name:kSelectFinanceFailed object:nil];
         [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDetailSuccess:) name:kSelectFinanceSuccess object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDetailFailed:) name:kSelectTransactionFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDetailSuccess:) name:kSelectTransactionSuccess object:nil];
        [activityIndicator startAnimating];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId,[selectedPlayer objectForKey:@"Playerid"],ktxtPlayerId, nil];
        [[WebService sharedWebService] callSelectFinanceDetailWebService:dictionary];
        
        [[WebService sharedWebService] callSelectTransactionDetailWebService:dictionary];
        
    }
    isLeagueList = false;
    isPlayerList = false;
    [UIView commitAnimations];
}
- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    
    if(isLeagueList){
      isLeagueList = false;
      selectedLeague = nil;
      [btnLeague setTitle:@"Select League" forState:UIControlStateNormal];
    }
    else if(isPlayerList){
        isPlayerList = false;
        selectedPlayer = nil;
        [btnPlayer setTitle:@"Select Player" forState:UIControlStateNormal];
    }
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(isLeagueList){
        return [leagueList count];
    }
    else{
        return [playerList count];
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(isLeagueList){
        return [[leagueList objectAtIndex:row] objectForKey:@"Title"];
    }
    else {
        return [[playerList objectAtIndex:row] objectForKey:@"PlayerName"];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(isLeagueList){
        selectedLeague = [leagueList objectAtIndex:row];
    }
    else if(isPlayerList){
        selectedPlayer = [playerList objectAtIndex:row];
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    [view setBackgroundColor:[UIColor clearColor]];
    return view;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if(tableView == self.tblView1){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,21)];
        [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
        
        UILabel *lbl1 = [[UILabel alloc] init];
        [lbl1 setFrame:CGRectMake(22,0, 73, 21)];
        [lbl1 setText:@"Name"];
        [lbl1 setBackgroundColor:[UIColor clearColor]];
        [lbl1 setTextColor:[UIColor whiteColor]];
        [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl1];
        
        UILabel *lbl2 = [[UILabel alloc] init];
        [lbl2 setFrame:CGRectMake(100, 0, 65, 21)];
        [lbl2 setText:@"Charge"];
        [lbl2 setBackgroundColor:[UIColor clearColor]];
        [lbl2 setTextColor:[UIColor whiteColor]];
        [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl2];
        
        UILabel *lbl3 = [[UILabel alloc] init];
        [lbl3 setFrame:CGRectMake(165, 0, 55, 21)];
        [lbl3 setText:@"Paid"];
        [lbl3 setBackgroundColor:[UIColor clearColor]];
        [lbl3 setTextColor:[UIColor whiteColor]];
        [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl3];
        
        UILabel *lbl4 = [[UILabel alloc] init];
        [lbl4 setFrame:CGRectMake(220, 0,74,21)];
        [lbl4 setText:@"UnPaid"];
        [lbl4 setBackgroundColor:[UIColor clearColor]];
        [lbl4 setTextColor:[UIColor whiteColor]];
        [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl4];
        return view;
    }
    else{
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,40)];
        [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
        
        UILabel *lbl1 = [[UILabel alloc] init];
        [lbl1 setFrame:CGRectMake(22,0, 73, 21)];
        [lbl1 setText:@"Name"];
        [lbl1 setBackgroundColor:[UIColor clearColor]];
        [lbl1 setTextColor:[UIColor whiteColor]];
        [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl1];
        
        UILabel *lbl2 = [[UILabel alloc] init];
        [lbl2 setFrame:CGRectMake(100, 0, 65, 21)];
        [lbl2 setText:@"Charge"];
        [lbl2 setBackgroundColor:[UIColor clearColor]];
        [lbl2 setTextColor:[UIColor whiteColor]];
        [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl2];
        
        UILabel *lbl3 = [[UILabel alloc] init];
        [lbl3 setFrame:CGRectMake(165, 0, 55, 21)];
        [lbl3 setText:@"Paid"];
        [lbl3 setBackgroundColor:[UIColor clearColor]];
        [lbl3 setTextColor:[UIColor whiteColor]];
        [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl3];
        
        UILabel *lbl4 = [[UILabel alloc] init];
        [lbl4 setFrame:CGRectMake(220, 0,74,21)];
        [lbl4 setText:@"UnPaid"];
        [lbl4 setBackgroundColor:[UIColor clearColor]];
        [lbl4 setTextColor:[UIColor whiteColor]];
        [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl4];
        return view;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(tableView == self.tblView1){
        return [array1 count];
    }
    else{
       return [array2 count];
    }
}

- (void) editFinance:(id)sender{
    int tag = [sender tag]-1000.0;
    NSDictionary *financeDictionary = [array1 objectAtIndex:tag];
    if(selectedLeague && selectedPlayer){
        AddFinanceViewController *addFinance = [[AddFinanceViewController alloc] initWithNibName:@"AddFinanceViewController" bundle:nil];
        addFinance.playerId = [selectedPlayer objectForKey:@"Playerid"];
        addFinance.leagueId = [selectedLeague objectForKey:@"LeagueId"];
        addFinance.financeDictionary = financeDictionary;
        [self.navigationController pushViewController:addFinance animated:YES];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select league and player" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}

- (void)financeDeleteFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteFinanceFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteFinanceSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)financeDeleteSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteFinanceFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteFinanceSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDetailFailed:) name:kSelectFinanceFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDetailSuccess:) name:kSelectFinanceSuccess object:nil];
    [activityIndicator startAnimating];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId,[selectedPlayer objectForKey:@"Playerid"],ktxtPlayerId, nil];
    [[WebService sharedWebService] callSelectFinanceDetailWebService:dictionary];
    
}
- (void) deleteFinance:(id)sender{
    [activityIndicator startAnimating];
   int tag = [sender tag]-1000.0;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDeleteFailed:) name:kDeleteFinanceFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(financeDeleteSuccess:) name:kDeleteFinanceSuccess object:nil];
     NSDictionary *financeDictionary = [array1 objectAtIndex:tag];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[financeDictionary objectForKey:ktxtFinanceId],ktxtFinanceId, nil];
    [[WebService sharedWebService] callDeleteFinanceDetailWebService:dictionary];
}

- (void)editTransaction:(id) sender{
   int tag = [sender tag]-1000.0;
    NSDictionary *transactionDictionary = [array2 objectAtIndex:tag];
    if(selectedLeague && selectedPlayer){
        AddTransactionViewController *addFinance = [[AddTransactionViewController alloc] initWithNibName:@"AddTransactionViewController" bundle:nil];
        addFinance.playerId = [selectedPlayer objectForKey:@"Playerid"];
        addFinance.leagueId = [selectedLeague objectForKey:@"LeagueId"];
        addFinance.transactionDictionary = transactionDictionary;
        [self.navigationController pushViewController:addFinance animated:YES];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select league and player" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}

- (void)transactionDeleteFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteTransactionSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
}
- (void)transactionDeleteSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kDeleteTransactionSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDetailFailed:) name:kSelectTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDetailSuccess:) name:kSelectTransactionSuccess object:nil];
    [activityIndicator startAnimating];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId,[selectedPlayer objectForKey:@"Playerid"],ktxtPlayerId, nil];
    [[WebService sharedWebService] callSelectTransactionDetailWebService:dictionary];
}

- (void)deleteTransaction:(id)sender{
    [activityIndicator startAnimating];
   int tag = [sender tag]-1000.0;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDeleteFailed:) name:kDeleteTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transactionDeleteSuccess:) name:kDeleteTransactionSuccess object:nil];
    NSDictionary *transactionDictionary = [array2 objectAtIndex:tag];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[transactionDictionary objectForKey:ktxtTransactionId],ktxtTransactionId, nil];
    [[WebService sharedWebService] callDeleteTransactionDetailWebService:dictionary];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(tableView == self.tblView1){
        FinanceCell *cell =(FinanceCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"FinanceCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (FinanceCell *) currentObject;
                    break;
                }
            }
            [cell bringSubviewToFront:cell.btnEdit];
            [cell bringSubviewToFront:cell.btnDelete];
            [cell.btnEdit setUserInteractionEnabled:YES];
            [cell.btnDelete setUserInteractionEnabled:YES];
            
            [cell.btnEdit setTag:1000+indexPath.row];
            [cell.btnDelete setTag:1000+indexPath.row];
            [cell.btnEdit addTarget:self action:@selector(editFinance:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnDelete addTarget:self action:@selector(deleteFinance:) forControlEvents:UIControlEventTouchUpInside];
        }
        if(indexPath.row == [array1 indexOfObject:[array1 lastObject]]){
            [cell.btnEdit setHidden:YES];
            [cell.btnDelete setHidden:YES];
        }
        else{
            [cell.btnEdit setHidden:NO];
            [cell.btnDelete setHidden:NO];
        }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.lblFinance.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"txtCategory"];
        cell.lblCharge.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"txtCharges"];
        cell.lblPaid.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"txtPaidCharges"];
        cell.lblNotPaid.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"txtUnPaidCharges"];
        return cell;
    }
    else{
        FinanceCell *cell =(FinanceCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"FinanceCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (FinanceCell *) currentObject;
                    break;
                }
            }
            
            [cell bringSubviewToFront:cell.btnEdit];
            [cell bringSubviewToFront:cell.btnDelete];
            [cell.btnEdit setUserInteractionEnabled:YES];
            [cell.btnDelete setUserInteractionEnabled:YES];
            
            [cell.btnEdit setTag:1000+indexPath.row];
            [cell.btnDelete setTag:1000+indexPath.row];
            [cell.btnEdit addTarget:self action:@selector(editTransaction:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnDelete addTarget:self action:@selector(deleteTransaction:) forControlEvents:UIControlEventTouchUpInside];
        }
        if(indexPath.row == [array2 indexOfObject:[array2 lastObject]]){
            [cell.btnEdit setHidden:YES];
            [cell.btnDelete setHidden:YES];
        }
        else{
            [cell.btnEdit setHidden:NO];
            [cell.btnDelete setHidden:NO];
        }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.lblFinance.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"PlayerName"];
        cell.lblCharge.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"txtCharges"];
        cell.lblPaid.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"txtPaidCharges"];
        cell.lblNotPaid.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"txtUnPaidCharges"];
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 29;
}

- (IBAction)addMoreFinanceClicked:(id)sender{
    if(selectedLeague && selectedPlayer){
        AddFinanceViewController *addFinance = [[AddFinanceViewController alloc] initWithNibName:@"AddFinanceViewController" bundle:nil];
        addFinance.playerId = [selectedPlayer objectForKey:@"Playerid"];
        addFinance.leagueId = [selectedLeague objectForKey:@"LeagueId"];
        [self.navigationController pushViewController:addFinance animated:YES];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select league and player" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}
- (IBAction)addMoreTransactionClicked:(id)sender{
    if(selectedLeague && selectedPlayer){
        AddTransactionViewController *addFinance = [[AddTransactionViewController alloc] initWithNibName:@"AddTransactionViewController" bundle:nil];
        addFinance.playerId = [selectedPlayer objectForKey:@"Playerid"];
        addFinance.leagueId = [selectedLeague objectForKey:@"LeagueId"];
        [self.navigationController pushViewController:addFinance animated:YES];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select league and player" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}
@end
