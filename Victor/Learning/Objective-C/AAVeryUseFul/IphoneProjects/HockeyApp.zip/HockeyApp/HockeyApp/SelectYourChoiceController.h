//
//  SelectYourChoice.h
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectYourChoiceController.h"
#import "LoginViewController.h"

@interface SelectYourChoiceController : UIViewController
{
    
}
@property(strong,nonatomic)NSMutableArray *keysAndValuesArr;
@property(strong,nonatomic)UIButton *button;
@property(strong,nonatomic)UIViewController *moveToLoginController;
@property(strong,nonatomic)IBOutlet UIButton *playerDetailsButton;
@property(strong,nonatomic)IBOutlet UIButton *matchReportButton;
@property(strong,nonatomic)IBOutlet UIButton *teamSettingButton;
@property(strong,nonatomic)IBOutlet UIButton *matchScheduleButton;

- (IBAction)playerDetails:(id)sender;
- (IBAction)backAction:(id)sender;
- (IBAction)matchReportAction:(id)sender;
- (IBAction)teamSettingAction:(id)sender;
- (IBAction)matchSchedule:(id)sender;
- (void) pushReceivedMoveToNextPage:(NSString *)text;

@end
