//
//  TeamSelectionViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "TeamSelectionViewController.h"


@implementation TeamSelectionViewController

@synthesize btnLeague;
@synthesize btnDefenders;
@synthesize btnMidFielders;
@synthesize btnAttackers;
@synthesize btnOpponent;
@synthesize txtView;
@synthesize scrollView;
@synthesize pickerBackground;
@synthesize picker;
@synthesize activityIndicator;

@synthesize isLeagueList;
@synthesize isDefender;
@synthesize isMidFielder;
@synthesize isAttacker;
@synthesize isOpponent;
@synthesize leagueList;
@synthesize tempArray;
@synthesize opponentArray;

@synthesize selectedLeague;
@synthesize selectedDefender;
@synthesize selectedMidFielder;
@synthesize selectedAttacker;
@synthesize selectedOpponent;

@synthesize playerId;
@synthesize arrayPlayerIds;
@synthesize players;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    tempArray = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15", nil];
    arrayPlayerIds = [[NSMutableArray alloc] init];
    [txtView setReturnKeyType:UIReturnKeyDone];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
}


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) leaugeListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
}
- (void) leaugeListSuccess:(NSNotification *)notification{
    isLeagueList = true;
    isOpponent = false;
    isDefender = false;
    isMidFielder = false;
    isAttacker = false;
    
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    leagueList = [notification.object objectForKey:@"LeagueList"];
    if([leagueList count] > 0){
        selectedLeague = [leagueList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
    }
}

- (IBAction)btnLeagueClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}
- (IBAction)btnDefendersClicked:(id)sender{
    isLeagueList = false;
    isOpponent = false;
    isDefender = true;
    isMidFielder = false;
    isAttacker = false;
    selectedDefender = [tempArray objectAtIndex:0];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    [picker reloadAllComponents];
}
- (IBAction)btnMidFieldersClicked:(id)sender{
    isLeagueList = false;
    isOpponent = false;
    isDefender = false;
    isMidFielder = true;
    isAttacker = false;
    selectedMidFielder = [tempArray objectAtIndex:0];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    [picker reloadAllComponents];
}
- (IBAction)btnAttackersClicked:(id)sender{
    isLeagueList = false;
    isOpponent = false;
    isDefender = false;
    isMidFielder = false;
    isAttacker = true;
    selectedAttacker = [tempArray objectAtIndex:0];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    [picker reloadAllComponents];
}

- (void) teamListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kMatchScheduleFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kMatchScheduleSuccess object:nil];
}
- (void) teamListSuccess:(NSNotification *)notification{
    isLeagueList = false;
    isOpponent = true;
    isDefender = false;
    isMidFielder = false;
    isAttacker = false;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kMatchScheduleFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kMatchScheduleSuccess object:nil];
    opponentArray = [notification.object objectForKey:@"MatchList"];
    if([opponentArray count] > 0){
        selectedOpponent = [opponentArray objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
        NSLog(@"Team List=%@",notification.object);
    }
}

- (IBAction)btnOpponentClicked:(id)sender{
    if(selectedLeague){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamListFailed:) name:kMatchScheduleFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamListSuccess:) name:kMatchScheduleSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,playerId,ktxtUserId, nil];
        [[WebService sharedWebService] callMatchScheduleWebService:dictionary];
    }
}

- (void) checkBoxClicked:(id)sender{
    UIButton *button = (UIButton *)sender;
    int tag = [button.superview tag] - 1000;
    if([button tag] == 101){
        [button setBackgroundImage:[UIImage imageNamed:@"screen6checkboxselected.png"] forState:UIControlStateNormal];
        [arrayPlayerIds addObject:[[players objectAtIndex:tag] objectForKey:@"Playerid"]];
        [button setTag:102];
    }
    else{
        [button setBackgroundImage:[UIImage imageNamed:@"screen6checkbox.png"] forState:UIControlStateNormal];
        [arrayPlayerIds removeObject:[[players objectAtIndex:tag] objectForKey:@"Playerid"]];
        [button setTag:101];
    }
}

- (void) prepareScrollViewWithPlayer:(NSArray *)array{
    players = array;
    int x1 = 12;
    int y = 5;
    int width = 140;
    int height = 30;
    int tempCount = 0;
    for(int i=0;i<[array count];i++){
        if(tempCount >= 2){
            tempCount = 0;
            y = y + 8 + 30;
            x1 = 12;
        }
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(x1,y,width,height)];
        [view setBackgroundColor:[UIColor clearColor]];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(8,14,21,21)];
        [btn setBackgroundImage:[UIImage imageNamed:@"screen6checkbox.png"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(checkBoxClicked:) forControlEvents:UIControlEventTouchUpInside];
        [btn setTag:101];
        [view addSubview:btn];
        
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(37,14,97,21)];
        [lbl setBackgroundColor:[UIColor clearColor]];
        [lbl setTextColor:[UIColor whiteColor]];
        [lbl setText:[[array objectAtIndex:i] objectForKey:@"PlayerName"]];
        [view addSubview:lbl];
        
        [view setTag:i+1000];
        
        [scrollView addSubview:view];
        
        tempCount = tempCount + 1;
        x1 = x1 + 157;
        
    }
    int count = [array count];
    int modulo = count % 2;
    if(modulo  == 0){
        count = count/2;
    }
    else{
        count = (count/2) + modulo;
    }
    int scrollviewheight = 5+(count*50)+((count-1)*8);
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,scrollviewheight)];
}
- (void) playerListFailed:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListSuccess object:nil];
}

- (void) playerListSuccess:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerListSuccess object:nil];
    NSArray *array = [notification.object objectForKey:@"PlayerList"];
    [self prepareScrollViewWithPlayer:array];
}

- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    
    if(isLeagueList){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,211)];
        [arrayPlayerIds removeAllObjects];
        [btnLeague setTitle:[selectedLeague objectForKey:@"Title"] forState:UIControlStateNormal];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerListFailed:) name:kSelectPlayerListFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerListSuccess:) name:kSelectPlayerListSuccess object:nil];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,playerId,ktxtUserId, nil];
        [[WebService sharedWebService] callSelectPlayerListWebService:dictionary];
    }
    else if(isOpponent){
       [btnOpponent setTitle:[NSString stringWithFormat:@"%@ Vs %@",[selectedOpponent objectForKey:@"StartDate"],[selectedOpponent objectForKey:@"SecondTeamName"]] forState:UIControlStateNormal];
    }
    else if(isDefender){
        [btnDefenders setTitle:selectedDefender forState:UIControlStateNormal];
    }
    else if(isMidFielder){
        [btnMidFielders setTitle:selectedMidFielder forState:UIControlStateNormal];
    }
    else if(isAttacker){
        [btnAttackers setTitle:selectedAttacker forState:UIControlStateNormal];
    }
    isLeagueList = false;
    isOpponent = false;
    isDefender = false;
    isMidFielder = false;
    isAttacker = false;
}
- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    
    if(isLeagueList){
        [btnLeague setTitle:@"Select League" forState:UIControlStateNormal];
        selectedLeague = nil;
    }
    else if(isOpponent){
        [btnOpponent setTitle:@"Select Opponent Team" forState:UIControlStateNormal];
        selectedOpponent = nil;
    }
    else if(isDefender){
        [btnDefenders setTitle:@"Defenders" forState:UIControlStateNormal];
        selectedDefender = nil;
    }
    else if(isMidFielder){
        [btnMidFielders setTitle:@"Mid fielders" forState:UIControlStateNormal];
        selectedMidFielder = nil;
    }
    else if(isAttacker){
        [btnAttackers setTitle:@"Attackers" forState:UIControlStateNormal];
        selectedAttacker = nil;
    }
    isLeagueList = false;
    isOpponent = false;
    isDefender = false;
    isMidFielder = false;
    isAttacker = false;
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(isLeagueList){
        return [leagueList count];
    }
    else if(isOpponent){
        return [opponentArray count];
    }
    else{
        return [tempArray count];
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(isLeagueList){
        return [[leagueList objectAtIndex:row] objectForKey:@"Title"];
    }
    else if(isOpponent){
        return [NSString stringWithFormat:@"%@ Vs %@",[[opponentArray objectAtIndex:row] objectForKey:@"StartDate"],[[opponentArray objectAtIndex:row] objectForKey:@"SecondTeamName"]];
    }
    else {
        return [tempArray objectAtIndex:row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(isLeagueList){
        selectedLeague = [leagueList objectAtIndex:row];
    }
    else if(isOpponent){
        selectedOpponent = [opponentArray objectAtIndex:row];
    }
    else if(isDefender){
        selectedDefender = [tempArray objectAtIndex:row];
    }
    else if(isMidFielder){
        selectedMidFielder = [tempArray objectAtIndex:row];
    }
    else if(isAttacker){
        selectedAttacker = [tempArray objectAtIndex:row];
    }
}

- (void) teamSelectionFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamSelectionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamSelectionSuccess object:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void) teamSelectionSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamSelectionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamSelectionSuccess object:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (IBAction)saveButtonClicked:(id)sender{
    if(!selectedLeague){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select league" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if(!selectedOpponent){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select opponent team" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([players count] == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select at least one player" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter comment" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamSelectionFailed:) name:kTeamSelectionFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamSelectionSuccess:) name:kTeamSelectionSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,[selectedOpponent objectForKey:@"SecondTeamID"],ktxtTeamId,[arrayPlayerIds componentsJoinedByString:@","],ktxtPlayersId,txtView.text,ktxtComments,[selectedOpponent objectForKey:@"MatchId"],ktxtMatchId, nil];
        [[WebService sharedWebService] callTeamSelectionWebService:dictionary];
    }
}

- (void)textViewDidBeginEditing:(UITextView *)textView{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [self.view setFrame:CGRectMake(self.view.frame.origin.x,-180,self.view.frame.size.width, self.view.frame.size.height)];
    [UIView commitAnimations];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if([text isEqualToString:@"\n"]){
        [txtView resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,0,self.view.frame.size.width, self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}
@end
