//
//  ManagerCoachViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "ManagerCoachViewController.h"
#import "TeamSelectionViewController.h"
#import "FinanceViewController.h"

@interface ManagerCoachViewController ()

@end

@implementation ManagerCoachViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)teamSelectionButtonClicked:(id)sender{
    TeamSelectionViewController *teamSelectionViewController = [[TeamSelectionViewController alloc] initWithNibName:@"TeamSelectionViewController" bundle:nil];
    [self.navigationController pushViewController:teamSelectionViewController animated:YES];
}
- (IBAction)financeClicked:(id)sender{
    FinanceViewController *financeViewController = [[FinanceViewController alloc] initWithNibName:@"FinanceViewController" bundle:nil];
    [self.navigationController pushViewController:financeViewController animated:YES];
}
- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
