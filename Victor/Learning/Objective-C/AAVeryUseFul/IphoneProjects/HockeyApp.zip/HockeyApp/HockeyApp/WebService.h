//
//  WebService.h
//  HockeyApp
//
//  Created by Amit Parmar on 21/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebService : NSObject

+(WebService *)sharedWebService;

- (void) callLoginWebService:(NSDictionary *)dictionary;
- (void) callLeaugeListWebService:(NSDictionary *)dictionary;
- (void) callMatchScheduleWebService:(NSDictionary *)dictionary;
- (void) callTeamSelectionWebService:(NSDictionary *)dictionary;
- (void) callPlayerListWebService:(NSDictionary *)dictionary;
- (void) callAddPointsToLeaugeWebService:(NSDictionary *)dictionary;
- (void) callGetLeaugePointSettingWebService:(NSDictionary *)dictionary;
- (void) callAddFinanceDetailWebService:(NSDictionary *)dictionary;
- (void) callEditFinanceDetailWebService:(NSDictionary *)dictionary;
- (void) callDeleteFinanceDetailWebService:(NSDictionary *)dictionary;
- (void) callSelectFinanceDetailWebService:(NSDictionary *)dictionary;
- (void) callAddTransactionDetailWebService:(NSDictionary *)dictionary;
- (void) callEditTransactionDetailWebService:(NSDictionary *)dictionary;
- (void) callDeleteTransactionDetailWebService:(NSDictionary *)dictionary;
- (void) callSelectTransactionDetailWebService:(NSDictionary *)dictionary;
- (void) callGetPlayerProfileWebService:(NSDictionary *)dictionary;
- (void) callFetchUpcomingMatchWebService:(NSDictionary *)dictionary;
- (void) callSavePlayerForUpcomingMatchWebService:(NSDictionary *)dictionary;
- (void) callGetFinishedMatchListWebService:(NSDictionary *)dictionary;
- (void) callSaveMatchPointWebService:(NSDictionary *)dictionary;
- (void) callSelectMatchPointWebService:(NSDictionary *)dictionary;
- (void) callSavePlayerPointWebService:(NSDictionary *)dictionary;
- (void) callPlayerStandingListWebService:(NSDictionary *)dictionary;
- (void) callLeaugeWiseTeamListWebService:(NSDictionary *)dictionary;
- (void) callTeamWiseUpcomingMatchWebService:(NSDictionary *)dictionary;
- (void) callCommentsOnMatchByPlayerWebService:(NSDictionary *)dictionary;
- (void) callDeleteCommentsWebService:(NSDictionary *)dictionary;
- (void) callSelectCommentWebService:(NSDictionary *)dictionary;
- (void) callVoteForPlayerWebService:(NSDictionary *)dictionary;
- (void) callDeleteVoteWebService:(NSDictionary *)dictionary;
- (void) callGetSelectedteamForSelectedMatchWebService:(NSDictionary *)dictionary;
- (void) callSelectPlayerListWebService:(NSDictionary *)dictionary;
- (void) callTeamStaningWebService:(NSDictionary *)dictionary;
- (void) callPreviousMatchResultWebService:(NSDictionary *)dictionary;
- (void) callEditPlayerProfileWebService:(NSDictionary *)dictionary;
- (void) callSelectPlayerPointWebService:(NSDictionary *)dictionary;
- (void) callForgotPasswordWebService:(NSDictionary *)dictionary;

@end
