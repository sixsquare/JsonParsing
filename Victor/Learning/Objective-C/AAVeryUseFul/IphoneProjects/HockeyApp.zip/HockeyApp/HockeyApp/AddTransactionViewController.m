//
//  AddTransactionViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "AddTransactionViewController.h"

@implementation AddTransactionViewController

@synthesize txtFieldDate;
@synthesize txtFieldFinance;
@synthesize txtFieldCharge;
@synthesize txtFieldPaid;
@synthesize txtFieldNotPaid;
@synthesize scrollView;
@synthesize datePickerBackground;
@synthesize datePicker;
@synthesize activityIndicator;
@synthesize transactionDictionary;
@synthesize leagueId;
@synthesize playerId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,504)];
    [txtFieldFinance setReturnKeyType:UIReturnKeyNext];
    [txtFieldCharge setReturnKeyType:UIReturnKeyNext];
    [txtFieldPaid setReturnKeyType:UIReturnKeyNext];
    [txtFieldNotPaid setReturnKeyType:UIReturnKeyDone];
    
    //[datePicker setMaximumDate:[NSDate date]];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(transactionDictionary){
        txtFieldDate.text = [transactionDictionary objectForKey:ktxtTransactionDate];
        txtFieldFinance.text = [transactionDictionary objectForKey:ktxtPlayerName];
        txtFieldPaid.text = [transactionDictionary objectForKey:ktxtPaidCharges];
        txtFieldNotPaid.text = [transactionDictionary objectForKey:ktxtUnPaidCharges];
        txtFieldCharge.text = [transactionDictionary objectForKey:ktxtCharges];
    }
    else{
        txtFieldDate.text = @"";
        txtFieldFinance.text = @"";
        txtFieldPaid.text = @"";
        txtFieldNotPaid.text = @"";
        txtFieldCharge.text = @"";
    }
}


- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)addTransactionFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddTransactionSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)addTransactionSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kAddTransactionSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert setTag:101];
    [alert show];
}

- (void)editTransactionFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditTransactionSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)editTransactionSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditTransactionFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kEditTransactionSuccess object:nil];
    NSDictionary *dictionary = notification.object;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert setTag:101];
    [alert show];
}

- (IBAction)saveButtonClicked:(id)sender{
    if([txtFieldDate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select date" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldFinance.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter finance" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldCharge.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter charge" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldPaid.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter amount paid" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldNotPaid.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter amount not paid" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        if(transactionDictionary){
            [activityIndicator startAnimating];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editTransactionFailed:) name:kEditTransactionFailed object:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editTransactionSuccess:) name:kEditTransactionSuccess object:nil];
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:leagueId,ktxtLeagueId,txtFieldFinance.text,ktxtPlayerName,txtFieldCharge.text,ktxtCharges,txtFieldPaid.text,ktxtPaidCharges,txtFieldNotPaid.text,ktxtUnPaidCharges,txtFieldDate.text,ktxtTransactionDate,playerId,ktxtPlayerId,[transactionDictionary objectForKey:ktxtTransactionId],ktxtTransactionId, nil];
            [[WebService sharedWebService] callEditTransactionDetailWebService:dictionary];
        }
        else{
            [activityIndicator startAnimating];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addTransactionFailed:) name:kAddTransactionFailed object:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addTransactionSuccess:) name:kAddTransactionSuccess object:nil];
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:leagueId,ktxtLeagueId,txtFieldFinance.text,ktxtPlayerName,txtFieldCharge.text,ktxtCharges,txtFieldPaid.text,ktxtPaidCharges,txtFieldNotPaid.text,ktxtUnPaidCharges,txtFieldDate.text,ktxtTransactionDate,playerId,ktxtPlayerId, nil];
            [[WebService sharedWebService] callAddTransactionDetailWebService:dictionary];
        }
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtFieldDate){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [datePickerBackground setFrame:CGRectMake(datePickerBackground.frame.origin.x,self.view.frame.size.height-datePickerBackground.frame.size.height,datePickerBackground.frame.size.width,datePickerBackground.frame.size.height)];
        [UIView commitAnimations];
        return NO;
    }
    else if(textField == txtFieldFinance){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldFinance.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldCharge){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldCharge.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldPaid){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldPaid.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldNotPaid){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldNotPaid.frame.origin.y) animated:YES];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldFinance){
        [txtFieldFinance resignFirstResponder];
        [txtFieldCharge becomeFirstResponder];
    }
    else if(textField == txtFieldCharge){
        [txtFieldCharge resignFirstResponder];
        [txtFieldPaid becomeFirstResponder];
    }
    else if(textField == txtFieldPaid){
        [txtFieldPaid resignFirstResponder];
        [txtFieldNotPaid becomeFirstResponder];
    }
    else if(textField == txtFieldNotPaid){
        [txtFieldNotPaid resignFirstResponder];
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,0) animated:YES];
    }
    return YES;
}

- (IBAction)datePickerDoneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [datePickerBackground setFrame:CGRectMake(datePickerBackground.frame.origin.x,1200,datePickerBackground.frame.size.width,datePickerBackground.frame.size.height)];
    [UIView commitAnimations];
    NSDate *date = datePicker.date;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *stringDate = [dateFormatter stringFromDate:date];
    txtFieldDate.text = stringDate;
}
- (IBAction)datePickerCancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [datePickerBackground setFrame:CGRectMake(datePickerBackground.frame.origin.x,1200,datePickerBackground.frame.size.width,datePickerBackground.frame.size.height)];
    [UIView commitAnimations];
}

@end
