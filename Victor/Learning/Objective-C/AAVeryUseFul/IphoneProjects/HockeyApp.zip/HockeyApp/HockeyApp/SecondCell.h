//
//  SecondCell.h
//  HockeyApp
//
//  Created by Amit Parmar on 23/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblDate;
@property (nonatomic, strong) IBOutlet UILabel *lblHomeTeam;
@property (nonatomic, strong) IBOutlet UILabel *lblAwayTeam;
@property (nonatomic, strong) IBOutlet UILabel *lblHomeGoal;
@property (nonatomic, strong) IBOutlet UILabel *lblAwayGoal;

@end
