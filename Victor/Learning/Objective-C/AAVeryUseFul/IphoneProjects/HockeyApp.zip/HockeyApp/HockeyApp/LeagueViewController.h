//
//  LeagueViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 23/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeagueViewController : UIViewController{
    
}

@property (nonatomic, strong) IBOutlet UIButton *btnLeague;
@property (nonatomic, strong) IBOutlet UIButton *btnTeam;
@property (nonatomic, strong) IBOutlet UIButton *btnCategory;
@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIPickerView *picker;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) NSString *playerId;
@property (nonatomic) BOOL isLeagueList;
@property (nonatomic) BOOL isTeamList;
@property (nonatomic, strong) NSArray *leagueList;
@property (nonatomic, strong) NSArray *teamList;
@property (nonatomic, strong) NSDictionary *selectedLeague;
@property (nonatomic, strong) NSDictionary *selectedTeam;
@property (nonatomic, strong) NSString *selectedCategory;
@property (nonatomic, strong) NSArray *categoryArray;
@property (nonatomic, strong) IBOutlet UITableView *tblView;
@property (nonatomic, strong) NSArray *array1;
@property (nonatomic, strong) NSArray *array2;
@property (nonatomic, strong) NSArray *array3;
@property (nonatomic, strong) NSArray *array4;


- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;
- (IBAction)btnLeagueClicked:(id)sender;
- (IBAction)btnTeamClicked:(id)sender;
- (IBAction)btnCategoryClicked:(id)sender;

- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;

@end
