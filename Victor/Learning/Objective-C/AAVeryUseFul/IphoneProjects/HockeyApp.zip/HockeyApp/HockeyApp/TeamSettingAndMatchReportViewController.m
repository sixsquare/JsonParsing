//
//  TeamSettingAndMatchReportViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 25/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "TeamSettingAndMatchReportViewController.h"
#import "TeamSettingsViewController.h"
#import "MatchReportViewController.h"

@implementation TeamSettingAndMatchReportViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)teamSettingsClicked:(id)sender{
    TeamSettingsViewController *teamSelectionViewController = [[TeamSettingsViewController alloc] initWithNibName:@"TeamSettingsViewController" bundle:nil];
    [self.navigationController pushViewController:teamSelectionViewController animated:YES];
}
- (IBAction)matchReportClicked:(id)sender{
    MatchReportViewController *financeViewController = [[MatchReportViewController alloc] initWithNibName:@"MatchReportViewController" bundle:nil];
    [self.navigationController pushViewController:financeViewController animated:YES];
}
- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
