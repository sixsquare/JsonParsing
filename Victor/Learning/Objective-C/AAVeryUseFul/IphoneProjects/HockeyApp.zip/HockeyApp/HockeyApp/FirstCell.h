//
//  FirstCell.h
//  HockeyApp
//
//  Created by Amit Parmar on 23/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblDate;
@property (nonatomic, strong) IBOutlet UILabel *lblHomeTeam;
@property (nonatomic, strong) IBOutlet UILabel *lblAwayTeam;
@property (nonatomic, strong) IBOutlet UILabel *lblPlace;

@end
