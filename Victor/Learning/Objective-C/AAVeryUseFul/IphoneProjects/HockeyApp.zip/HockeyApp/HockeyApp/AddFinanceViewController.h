//
//  AddFinanceViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFinanceViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITextField *txtFieldDate;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldFinance;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldCharge;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPaid;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldNotPaid;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) IBOutlet UIView *datePickerBackground;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;

@property (nonatomic, strong) NSDictionary *financeDictionary;
@property (nonatomic, strong) NSString *leagueId;
@property (nonatomic, strong) NSString *playerId;

- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;
- (IBAction)saveButtonClicked:(id)sender;

- (IBAction)datePickerDoneButtonClicked:(id)sender;
- (IBAction)datePickerCancelButtonClicked:(id)sender;

@end
