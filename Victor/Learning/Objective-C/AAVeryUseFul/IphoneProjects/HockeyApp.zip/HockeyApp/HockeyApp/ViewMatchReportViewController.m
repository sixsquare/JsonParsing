//
//  ViewMatchReportViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 23/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "ViewMatchReportViewController.h"
#import "PlayerStandingCell.h"

@implementation ViewMatchReportViewController

@synthesize btnLeague;
@synthesize btnMatch;
@synthesize activityIndicator;
@synthesize lblHomeTeam;
@synthesize txtFieldGoal1;
@synthesize txtFieldAssist1;
@synthesize txtFieldRedcard1;
@synthesize txtFieldYellowCard1;
@synthesize txtFieldTotalPoints1;
@synthesize lblAwayTeam;
@synthesize txtFieldGoal2;
@synthesize txtFieldAssist2;
@synthesize txtFieldRedcard2;
@synthesize txtFieldYellowCard2;
@synthesize txtFieldTotalPoints2;
@synthesize scrollView;
@synthesize pickerBackground;
@synthesize picker;
@synthesize playerId;
@synthesize isLeagueList;
@synthesize isMatchList;
@synthesize leagueList;
@synthesize matchList;
@synthesize selectedLeague;
@synthesize selectedMatch;
@synthesize matchPoint;
@synthesize homeTeamArray;
@synthesize awayTeamArray;
@synthesize lblHomeTeam1;
@synthesize lblAwayTeam1;
@synthesize tblView1;
@synthesize tblView2;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void) playerPointFailed:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerPointSuccess object:nil];
    [self.tblView1 setHidden:YES];
    [self.tblView2 setHidden:YES];
}
- (void) playerPointSuccess:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectPlayerPointSuccess object:nil];
    homeTeamArray = [notification.object objectForKey:@"HomeTeamPlayerList"];
    awayTeamArray = [notification.object objectForKey:@"AwayPlayerTeamList"];
    if([homeTeamArray count] > 0){
        [self.tblView1 setHidden:NO];
        [self.tblView1 reloadData];
    }
    else{
        [self.tblView1 setHidden:YES];
    }
    
    if([awayTeamArray count] > 0){
        [self.tblView2 setHidden:NO];
        [self.tblView2 reloadData];
    }
    else{
        [self.tblView2 setHidden:YES];
    }
}
- (void) callPlayerPointWebService{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerPointFailed:) name:kSelectPlayerPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerPointSuccess:) name:kSelectPlayerPointSuccess object:nil];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedMatch objectForKey:@"HomeTeamNameId"],ktxtHomeTeamId,[selectedMatch objectForKey:@"AwayTeamNameId"],ktxtAwayTeamId, nil];
    [[WebService sharedWebService] callSelectPlayerPointWebService:dictionary];
}

- (void) matchPointFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectMatchPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectMatchPointSuccess object:nil];
}

- (void) fillData{
    if(matchPoint){
        lblHomeTeam.text = [matchPoint objectForKey:@"HomeTeamName"];
        lblAwayTeam.text = [matchPoint objectForKey:@"AwayTeamName"];
        lblHomeTeam1.text = [matchPoint objectForKey:@"HomeTeamName"];
        lblAwayTeam1.text = [matchPoint objectForKey:@"AwayTeamName"];
        txtFieldGoal1.text =[matchPoint objectForKey:@"HTGoal"];
        txtFieldGoal2.text = [matchPoint objectForKey:@"ATGoal"];
        txtFieldAssist1.text = [matchPoint objectForKey:@"HTAssist"];
        txtFieldAssist2.text = [matchPoint objectForKey:@"ATAssist"];
        txtFieldRedcard1.text = [matchPoint objectForKey:@"HTRedCard"];
        txtFieldRedcard2.text = [matchPoint objectForKey:@"ATRedCard"];
        txtFieldYellowCard1.text = [matchPoint objectForKey:@"HTYellowPoint"];
        txtFieldYellowCard2.text = [matchPoint objectForKey:@"ATYellowPoint"];
        txtFieldTotalPoints1.text = [matchPoint objectForKey:@"HTPoints"];
        txtFieldTotalPoints2.text = [matchPoint objectForKey:@"ATPoints"];
    }
    else{
        lblHomeTeam.text = @"";
        lblAwayTeam.text = @"";
        txtFieldGoal1.text = @"";
        txtFieldGoal2.text = @"";
        txtFieldAssist1.text = @"";
        txtFieldAssist2.text = @"";
        txtFieldRedcard1.text = @"";
        txtFieldRedcard2.text = @"";
        txtFieldYellowCard1.text = @"";
        txtFieldYellowCard2.text = @"";
        txtFieldTotalPoints1.text = @"";
        txtFieldTotalPoints2.text = @"";
    }
}
- (void) matchPointSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectMatchPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSelectMatchPointSuccess object:nil];
    matchPoint = [notification.object objectForKey:@"MatchObject"];
    [self fillData];
}

- (void) selectMatchPointTeamWise{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchPointFailed:) name:kSelectMatchPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchPointSuccess:) name:kSelectMatchPointSuccess object:nil];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,[selectedMatch objectForKey:@"MatchId"],ktxtMatchId, nil];
    [[WebService sharedWebService] callSelectMatchPointWebService:dictionary];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1450)];
    
    [txtFieldGoal1 setReturnKeyType:UIReturnKeyNext];
    [txtFieldGoal2 setReturnKeyType:UIReturnKeyNext];
    [txtFieldAssist1 setReturnKeyType:UIReturnKeyNext];
    [txtFieldAssist2 setReturnKeyType:UIReturnKeyNext];
    [txtFieldRedcard1 setReturnKeyType:UIReturnKeyNext];
    [txtFieldRedcard2 setReturnKeyType:UIReturnKeyNext];
    [txtFieldYellowCard1 setReturnKeyType:UIReturnKeyNext];
    [txtFieldYellowCard2 setReturnKeyType:UIReturnKeyNext];
    [txtFieldTotalPoints1 setReturnKeyType:UIReturnKeyDone];
    [txtFieldTotalPoints2 setReturnKeyType:UIReturnKeyDone];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
    if(selectedLeague && selectedMatch){
        [self selectMatchPointTeamWise];
        [self callPlayerPointWebService];
    }
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) leaugeListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
}
- (void) leaugeListSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    leagueList = [notification.object objectForKey:@"LeagueList"];
    if([leagueList count] > 0){
        isLeagueList = true;
        isMatchList = false;
        selectedLeague = [leagueList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
    }
}

- (IBAction)leagueButtonClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}

- (void) finishedMatchFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFinishedMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFinishedMatchSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void) finishedMatchSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFinishedMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kFinishedMatchSuccess object:nil];
    NSDictionary *dictinary = notification.object;
    matchList = [dictinary objectForKey:@"MatchList"];
    if([matchList count] > 0){
        isMatchList = true;
        isLeagueList = false;
        selectedMatch = [matchList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
    }
}
- (IBAction)matchButtonClicked:(id)sender{
    if(selectedLeague){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finishedMatchFailed:) name:kFinishedMatchFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finishedMatchSuccess:) name:kFinishedMatchSuccess object:nil];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId,[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId, nil];
        [[WebService sharedWebService] callGetFinishedMatchListWebService:dictionary];
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtFieldGoal1){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldGoal1.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldGoal2){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldGoal2.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldRedcard1){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldRedcard1.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldRedcard2){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldRedcard2.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldTotalPoints1){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldTotalPoints1.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldTotalPoints2){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldTotalPoints2.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldYellowCard1){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldYellowCard1.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldYellowCard2){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldYellowCard2.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldAssist1){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldAssist1.frame.origin.y) animated:YES];
    }
    else if(textField == txtFieldAssist2){
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,txtFieldAssist2.frame.origin.y) animated:YES];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldGoal1){
        [txtFieldGoal1 resignFirstResponder];
        [txtFieldAssist1 becomeFirstResponder];
    }
    else if(textField == txtFieldAssist1){
        [txtFieldAssist1 resignFirstResponder];
        [txtFieldRedcard1 becomeFirstResponder];
    }
    else if(textField == txtFieldRedcard1){
        [txtFieldRedcard1 resignFirstResponder];
        [txtFieldYellowCard1 becomeFirstResponder];
    }
    else if(textField == txtFieldYellowCard1){
        [txtFieldYellowCard1 resignFirstResponder];
        [txtFieldTotalPoints1 becomeFirstResponder];
    }
    else if(textField == txtFieldTotalPoints1){
        [txtFieldTotalPoints1 resignFirstResponder];
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,0) animated:YES];
    }
    else if(textField == txtFieldGoal2){
        [txtFieldGoal2 resignFirstResponder];
        [txtFieldAssist2 becomeFirstResponder];
    }
    else if(textField == txtFieldAssist2){
        [txtFieldAssist2 resignFirstResponder];
        [txtFieldRedcard2 becomeFirstResponder];
    }
    else if(textField == txtFieldRedcard2){
        [txtFieldRedcard2 resignFirstResponder];
        [txtFieldYellowCard2 becomeFirstResponder];
    }
    else if(textField == txtFieldYellowCard2){
        [txtFieldYellowCard2 resignFirstResponder];
        [txtFieldTotalPoints2 becomeFirstResponder];
    }
    else if(textField == txtFieldTotalPoints2){
        [txtFieldTotalPoints2 resignFirstResponder];
        [scrollView setContentOffset:CGPointMake(scrollView.frame.origin.x,0) animated:YES];
    }
    return YES;
}
- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    if(isLeagueList){
        [btnLeague setTitle:[selectedLeague objectForKey:@"Title"] forState:UIControlStateNormal];
    }
    else{
        [btnMatch setTitle:[NSString stringWithFormat:@"%@ - %@",[selectedMatch objectForKey:@"HomeTeamName"],[selectedMatch objectForKey:@"AwayTeamName"]] forState:UIControlStateNormal];
        [self selectMatchPointTeamWise];
        [self callPlayerPointWebService];
    }
    isLeagueList = false;
    isMatchList = false;
}
- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    if(isLeagueList){
        [btnLeague setTitle:@"Select League" forState:UIControlStateNormal];
        selectedLeague = false;
        isLeagueList = false;
    }
    else{
        [btnMatch setTitle:@"Select Match" forState:UIControlStateNormal];
        selectedMatch = nil;
        isMatchList = false;
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(isLeagueList){
        return [leagueList count];
    }
    else{
        return [matchList count];
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(isLeagueList){
        return [[leagueList objectAtIndex:row] objectForKey:@"Title"];
    }
    else{
        return [NSString stringWithFormat:@"%@ - %@",[[matchList objectAtIndex:row] objectForKey:@"HomeTeamName"],[[matchList objectAtIndex:row] objectForKey:@"AwayTeamName"]];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(isLeagueList){
        selectedLeague = [leagueList objectAtIndex:row];
    }
    else{
        selectedMatch = [matchList objectAtIndex:row];
    }
}

- (void)saveMatchPointFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSaveMatchPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSaveMatchPointSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void)saveMatchPointSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSaveMatchPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSaveMatchPointSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (IBAction)saveButtonClicked:(id)sender{
    if(!selectedLeague){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select league" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if(!selectedMatch){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select match" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if(matchPoint){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveMatchPointFailed:) name:kSaveMatchPointFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveMatchPointSuccess:) name:kSaveMatchPointSuccess object:nil];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedMatch objectForKey:@"MatchId"],ktxtMatchId,[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,[matchPoint objectForKey:@"PointId"],ktxtPointId,[selectedMatch objectForKey:@"HomeTeamNameId"],ktxtHomeTeamId,[selectedMatch objectForKey:@"AwayTeamNameId"],ktxtAwayTeamId,txtFieldGoal1.text,ktxtHTGoal,txtFieldAssist1.text,ktxtHTAssist,txtFieldRedcard1.text,ktxtHTRedCard,txtFieldYellowCard1.text,ktxtHTYellowPoint,txtFieldTotalPoints1.text,ktxtHTPoints,txtFieldGoal2.text,ktxtATGoal,txtFieldAssist2.text,ktxtATAssist,txtFieldRedcard1.text,ktxtATRedCard,txtFieldYellowCard2.text,ktxtATYellowPoint,txtFieldTotalPoints2.text,ktxtATPoints, nil];
        [[WebService sharedWebService] callSaveMatchPointWebService:dictionary];
    }
    else{
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveMatchPointFailed:) name:kSaveMatchPointFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveMatchPointSuccess:) name:kSaveMatchPointSuccess object:nil];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedMatch objectForKey:@"MatchId"],ktxtMatchId,[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,@"0",ktxtPointId,[selectedMatch objectForKey:@"HomeTeamNameId"],ktxtHomeTeamId,[selectedMatch objectForKey:@"AwayTeamNameId"],ktxtAwayTeamId,txtFieldGoal1.text,ktxtHTGoal,txtFieldAssist1.text,ktxtHTAssist,txtFieldRedcard1.text,ktxtHTRedCard,txtFieldYellowCard1.text,ktxtHTYellowPoint,txtFieldTotalPoints1.text,ktxtHTPoints,txtFieldGoal2.text,ktxtATGoal,txtFieldAssist2.text,ktxtATAssist,txtFieldRedcard1.text,ktxtATRedCard,txtFieldYellowCard2.text,ktxtATYellowPoint,txtFieldTotalPoints2.text,ktxtATPoints, nil];
        [[WebService sharedWebService] callSaveMatchPointWebService:dictionary];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(tableView == self.tblView1){
        return [homeTeamArray count];
    }
    else if(tableView == self.tblView2){
        return [awayTeamArray count];
    }
    else{
        return 0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,40)];
    [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
    
    UILabel *lbl1 = [[UILabel alloc] init];
    [lbl1 setFrame:CGRectMake(5, 0, 63, 21)];
    [lbl1 setText:@"Player"];
    [lbl1 setBackgroundColor:[UIColor clearColor]];
    [lbl1 setTextColor:[UIColor whiteColor]];
    [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl1];
    
    UILabel *lbl2 = [[UILabel alloc] init];
    [lbl2 setFrame:CGRectMake(74, 0, 63, 21)];
    [lbl2 setText:@"Team"];
    [lbl2 setBackgroundColor:[UIColor clearColor]];
    [lbl2 setTextColor:[UIColor whiteColor]];
    [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl2];
    
    UILabel *lbl3 = [[UILabel alloc] init];
    [lbl3 setFrame:CGRectMake(148, 0, 20, 21)];
    [lbl3 setText:@"G"];
    [lbl3 setBackgroundColor:[UIColor clearColor]];
    [lbl3 setTextColor:[UIColor whiteColor]];
    [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl3];
    
    UILabel *lbl4 = [[UILabel alloc] init];
    [lbl4 setFrame:CGRectMake(176, 0,20,21)];
    [lbl4 setText:@"A"];
    [lbl4 setBackgroundColor:[UIColor clearColor]];
    [lbl4 setTextColor:[UIColor whiteColor]];
    [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl4];
    
    UILabel *lbl5 = [[UILabel alloc] init];
    [lbl5 setFrame:CGRectMake(200, 0,20,21)];
    [lbl5 setText:@"R"];
    [lbl5 setBackgroundColor:[UIColor clearColor]];
    [lbl5 setTextColor:[UIColor whiteColor]];
    [lbl5 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl5];
    
    UILabel *lbl6 = [[UILabel alloc] init];
    [lbl6 setFrame:CGRectMake(228, 0,20,21)];
    [lbl6 setText:@"Y"];
    [lbl6 setBackgroundColor:[UIColor clearColor]];
    [lbl6 setTextColor:[UIColor whiteColor]];
    [lbl6 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl6];
    
    UILabel *lbl7 = [[UILabel alloc] init];
    [lbl7 setFrame:CGRectMake(255, 0,64,21)];
    [lbl7 setText:@"Points"];
    [lbl7 setBackgroundColor:[UIColor clearColor]];
    [lbl7 setTextColor:[UIColor whiteColor]];
    [lbl7 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    [view addSubview:lbl7];
    
    return view;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(tableView == self.tblView1){
        PlayerStandingCell *cell =(PlayerStandingCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"PlayerStandingCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (PlayerStandingCell *) currentObject;
                    break;
                }
            }
        }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.lblPlayerName.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"PlayerName"];
        cell.lblMatch.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"TeamName"];
        cell.lblG.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"TGoal"];
        cell.lblA.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"TAssist"];
        cell.lblR.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"TRedCard"];
        cell.lblY.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"TYellowPoint"];
        cell.lblPoints.text = [[homeTeamArray objectAtIndex:indexPath.row] objectForKey:@"TPoints"];
        
        return cell;
    }
    else{
        PlayerStandingCell *cell =(PlayerStandingCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"PlayerStandingCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (PlayerStandingCell *) currentObject;
                    break;
                }
            }
        }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.lblPlayerName.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"PlayerName"];
        cell.lblMatch.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"TeamName"];
        cell.lblG.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"TGoal"];
        cell.lblA.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"TAssist"];
        cell.lblR.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"TRedCard"];
        cell.lblY.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"TYellowPoint"];
        cell.lblPoints.text = [[awayTeamArray objectAtIndex:indexPath.row] objectForKey:@"TPoints"];
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 29;
}

@end
