
//
//  SelectYourChoice.m
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "SelectYourChoiceController.h"
#import "LoginViewController.h"
#import "PlayerDetailsController.h"
#import "LeagueAndMatchController.h"
#import "ManagerCoachViewController.h"
#import "TeamSettingAndMatchReportViewController.h"

@interface SelectYourChoiceController ()

@end

@implementation SelectYourChoiceController
@synthesize moveToLoginController;
@synthesize button;
@synthesize keysAndValuesArr;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) pushReceivedMoveToNextPage:(NSString *)text{
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    NSString *playerId;
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
    
    PlayerDetailsController *playerDetailViewController = [[PlayerDetailsController alloc] initWithNibName:@"PlayerDetailsController" bundle:nil];
    [playerDetailViewController fetchUpcomingMatch:playerId];
    [self.navigationController pushViewController:playerDetailViewController animated:YES];
}
#pragma mark Navigate To new Controller

- (IBAction)playerDetails:(id)sender {
    if(![[NSUserDefaults standardUserDefaults] objectForKey:kProfileData]){
        LoginViewController *loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        [self.navigationController pushViewController:loginViewController animated:YES];
    }
    else{
        NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
        int roleId = [[dictionary objectForKey:@"RoleId"] intValue];
        if(roleId != 1){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"You can not able to access this section" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
        else{
            PlayerDetailsController *playerDetailViewController = [[PlayerDetailsController alloc] initWithNibName:@"PlayerDetailsController" bundle:nil];
            [self.navigationController pushViewController:playerDetailViewController animated:YES];
        }
    }
}

- (IBAction)backAction:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)matchReportAction:(id)sender {
    if(![[NSUserDefaults standardUserDefaults] objectForKey:kProfileData]){
        LoginViewController *loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        [self.navigationController pushViewController:loginViewController animated:YES];
    }
    else{
        LeagueAndMatchController *leagueAndMatchController = [[LeagueAndMatchController alloc] initWithNibName:@"LeagueAndMatchController" bundle:nil];
        [self.navigationController pushViewController:leagueAndMatchController animated:YES];
    }
  
}

- (IBAction)teamSettingAction:(id)sender {
    
    if(![[NSUserDefaults standardUserDefaults] objectForKey:kProfileData]){
        LoginViewController *loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        [self.navigationController pushViewController:loginViewController animated:YES];
    }
    else{
        NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
        int roleId = [[dictionary objectForKey:@"RoleId"] intValue];
        if(roleId != 3 && roleId != 2){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"You can not able to access this section" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
        else{
            TeamSettingAndMatchReportViewController *teamsetting = [[TeamSettingAndMatchReportViewController alloc] initWithNibName:@"TeamSettingAndMatchReportViewController" bundle:nil];
            [self.navigationController pushViewController:teamsetting animated:YES];
        }
    }
}

- (IBAction)matchSchedule:(id)sender {
    if(![[NSUserDefaults standardUserDefaults] objectForKey:kProfileData]){
        LoginViewController *loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        [self.navigationController pushViewController:loginViewController animated:YES];
    }
    else{
        NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
        int roleId = [[dictionary objectForKey:@"RoleId"] intValue];
        if(roleId != 3 && roleId != 2){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"You can not able to access this section" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
        else{
            ManagerCoachViewController *managerCoachViewController = [[ManagerCoachViewController alloc] initWithNibName:@"ManagerCoachViewController" bundle:nil];
            [self.navigationController pushViewController:managerCoachViewController animated:YES];
        }
    }
}

#pragma mark View will Appear

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}



@end
