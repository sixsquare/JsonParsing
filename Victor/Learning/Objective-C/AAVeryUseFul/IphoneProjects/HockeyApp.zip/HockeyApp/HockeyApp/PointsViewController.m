//
//  PointsViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 27/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "PointsViewController.h"

@implementation PointsViewController

@synthesize txtFieldGoal;
@synthesize txtFieldAssist;
@synthesize txtFieldRedcard;
@synthesize txtFieldYellowCard;
@synthesize txtFieldTotalPoints;
@synthesize activityIndicator;

@synthesize selectedMatch;
@synthesize selectedLeague;
@synthesize selectedPlayer;
@synthesize lblPlayerName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(selectedPlayer){
        txtFieldGoal.text = [selectedPlayer objectForKey:@"TGoal"];
        txtFieldAssist.text = [selectedPlayer objectForKey:@"TAssist"];
        txtFieldRedcard.text = [selectedPlayer objectForKey:@"TRedCard"];
        txtFieldYellowCard.text = [selectedPlayer objectForKey:@"TYellowPoint"];
        txtFieldTotalPoints.text = [selectedPlayer objectForKey:@"TPoints"];
        lblPlayerName.text = [selectedPlayer objectForKey:@"PlayerName"];
    }
    else{
        txtFieldGoal.text = @"";
        txtFieldAssist.text = @"";
        txtFieldRedcard.text = @"";
        txtFieldYellowCard.text = @"";
        txtFieldTotalPoints.text = @"";
        lblPlayerName.text = @"";
    }
}
- (void)savePointsFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerPointSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)savePointsSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSavePlayerPointSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert setTag:101];
    [alert show];
}

- (IBAction)saveButtonClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(savePointsFailed:) name:kSavePlayerPointFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(savePointsSuccess:) name:kSavePlayerPointSuccess object:nil];
    if(![selectedPlayer objectForKey:@"PointId"] || [[selectedPlayer objectForKey:@"PointId"] isEqual:[NSNull null]]){
         NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedMatch objectForKey:@"MatchId"],ktxtMatchId,[selectedMatch objectForKey:@"HomeTeamNameId"],ktxtTeamId,selectedLeague,ktxtLeagueId,@"0",ktxtPointId,txtFieldGoal.text,ktxtHTGoal,txtFieldAssist.text,ktxtHTAssist,txtFieldRedcard.text,ktxtHTRedCard,txtFieldYellowCard.text,ktxtHTYellowPoint,txtFieldTotalPoints.text,ktxtHTPoints,[selectedPlayer objectForKey:@"Playerid"],ktxtPlayerId, nil];
        [[WebService sharedWebService] callSavePlayerPointWebService:dictionary];
    }
    else{
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedMatch objectForKey:@"MatchId"],ktxtMatchId,[selectedMatch objectForKey:@"HomeTeamNameId"],ktxtTeamId,selectedLeague,ktxtLeagueId,[selectedPlayer objectForKey:@"PointId"],ktxtPointId,txtFieldGoal.text,ktxtHTGoal,txtFieldAssist.text,ktxtHTAssist,txtFieldRedcard.text,ktxtHTRedCard,txtFieldYellowCard.text,ktxtHTYellowPoint,txtFieldTotalPoints.text,ktxtHTPoints,[selectedPlayer objectForKey:@"Playerid"],ktxtPlayerId, nil];
        [[WebService sharedWebService] callSavePlayerPointWebService:dictionary];
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtFieldRedcard){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-50,self.view.frame.size.width,self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldYellowCard){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-100,self.view.frame.size.width,self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldTotalPoints){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-150,self.view.frame.size.width,self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldGoal){
        [txtFieldGoal resignFirstResponder];
        [txtFieldAssist becomeFirstResponder];
    }
    else if(textField == txtFieldAssist){
        [txtFieldAssist resignFirstResponder];
        [txtFieldRedcard becomeFirstResponder];
    }
    else if(textField == txtFieldRedcard){
        [txtFieldRedcard resignFirstResponder];
        [txtFieldYellowCard becomeFirstResponder];
    }
    else if(textField == txtFieldYellowCard){
        [txtFieldYellowCard resignFirstResponder];
        [txtFieldTotalPoints becomeFirstResponder];
    }
    else if(textField == txtFieldTotalPoints){
        [txtFieldTotalPoints resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,0,self.view.frame.size.width,self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}


@end
