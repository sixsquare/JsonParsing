//
//  PlayerStandingCell.h
//  HockeyApp
//
//  Created by Amit Parmar on 25/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerStandingCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblPlayerName;
@property (nonatomic, strong) IBOutlet UILabel *lblMatch;
@property (nonatomic, strong) IBOutlet UILabel *lblG;
@property (nonatomic, strong) IBOutlet UILabel *lblA;
@property (nonatomic, strong) IBOutlet UILabel *lblR;
@property (nonatomic, strong) IBOutlet UILabel *lblY;
@property (nonatomic, strong) IBOutlet UILabel *lblPoints;
@end
