//
//  TeamStandingCell.h
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamStandingCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblTeam;
@property (nonatomic, strong) IBOutlet UILabel *lblG;
@property (nonatomic, strong) IBOutlet UILabel *lblA;
@property (nonatomic, strong) IBOutlet UILabel *lblR;
@property (nonatomic, strong) IBOutlet UILabel *lblY;
@property (nonatomic, strong) IBOutlet UILabel *lblPoints;

@end
