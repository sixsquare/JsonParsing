//
//  LeagueViewController.m
//  HockeyApp
//
//  Created by Amit Parmar on 23/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "LeagueViewController.h"
#import "FirstCell.h"
#import "SecondCell.h"
#import "TeamStandingCell.h"
#import "PlayerStandingCell.h"

@implementation LeagueViewController

@synthesize btnLeague;
@synthesize btnTeam;
@synthesize btnCategory;
@synthesize picker;
@synthesize pickerBackground;
@synthesize activityIndicator;
@synthesize playerId;
@synthesize isLeagueList;
@synthesize isTeamList;
@synthesize leagueList;
@synthesize teamList;
@synthesize selectedLeague;
@synthesize selectedTeam;
@synthesize selectedCategory;
@synthesize categoryArray;
@synthesize tblView;
@synthesize array1;
@synthesize array2;
@synthesize array3;
@synthesize array4;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSDictionary *dictionary = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    playerId = [dictionary objectForKey:@"Playerid"];
    if(!playerId)
        [dictionary objectForKey:@"txtUserId"];
    
    categoryArray = [NSArray arrayWithObjects:@"Next Match Fixture",@"Previous Match Result",@"Team Standing",@"Player Standing", nil];
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButtonClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)logoutButtonClicked:(id)sender{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) leaugeListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [self.tblView setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
}
- (void) leaugeListSuccess:(NSNotification *)notification{
    isLeagueList = true;
    isTeamList = false;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeListSuccess object:nil];
    leagueList = [notification.object objectForKey:@"LeagueList"];
    if([leagueList count] > 0){
        selectedLeague = [leagueList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
        NSLog(@"Leauge List=%@",notification.object);
    }
}


- (IBAction)btnLeagueClicked:(id)sender{
    [activityIndicator startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListFailed:) name:kLeaugeListFailed object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leaugeListSuccess:) name:kLeaugeListSuccess object:nil];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:playerId,ktxtUserId, nil];
    [[WebService sharedWebService] callLeaugeListWebService:dictionary];
}

- (void) teamListFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeWiseTeamListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeWiseTeamListSuccess object:nil];
}
- (void) teamListSuccess:(NSNotification *)notification{
    isLeagueList = false;
    isTeamList = true;
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeWiseTeamListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLeaugeWiseTeamListSuccess object:nil];
    teamList = [notification.object objectForKey:@"TeamList"];
    if([teamList count] > 0){
        selectedTeam = [teamList objectAtIndex:0];
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
        [UIView commitAnimations];
        [picker reloadAllComponents];
        NSLog(@"Team List=%@",notification.object);
    }
}


- (IBAction)btnTeamClicked:(id)sender{
    if(selectedLeague){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamListFailed:) name:kLeaugeWiseTeamListFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamListSuccess:) name:kLeaugeWiseTeamListSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId, nil];
        [[WebService sharedWebService] callLeaugeWiseTeamListWebService:dictionary];
    }
}
- (IBAction)btnCategoryClicked:(id)sender{
    isLeagueList = false;
    isTeamList = false;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,self.view.frame.size.height-pickerBackground.frame.size.height,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    [picker reloadAllComponents];
}
- (void)teamWiseUpComingListFailed:(NSNotification *) notification{
    [activityIndicator stopAnimating];
    [self.tblView setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamWiseUpcomingMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamWiseUpcomingMatchSuccess object:nil];
}

- (void)teamWiseUpComingListSuccess:(NSNotification *) notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamWiseUpcomingMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamWiseUpcomingMatchSuccess object:nil];
    array1 = [notification.object objectForKey:@"MatchList"];
    if(![array1 isEqual:[NSNull null]] && [array1 count] > 0){
        [self.tblView setHidden:NO];
        [self.tblView reloadData];
    }
    else{
        [self.tblView setHidden:YES];
    }
}

- (void)previousMatchFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [self.tblView setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPreviousMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPreviousMatchSuccess object:nil];
}
- (void)previousMatchSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPreviousMatchFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPreviousMatchSuccess object:nil];
    array2 = [notification.object objectForKey:@"TeamObject"];
    if( ![array2 isEqual:[NSNull null]] && [array2 count] > 0){
        [self.tblView setHidden:NO];
        [self.tblView reloadData];
    }
    else{
        [self.tblView setHidden:YES];
    }
}

- (void)teamStandingFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [self.tblView setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamStandingFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamStandingSuccess object:nil];
}
- (void)teamStandingSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamStandingFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kTeamStandingSuccess object:nil];
    array3 = [notification.object objectForKey:@"TeamObject"];
    if(![array3 isEqual:[NSNull null]] && [array3 count] > 0){
        [self.tblView setHidden:NO];
        [self.tblView reloadData];
    }
    else{
        [self.tblView setHidden:YES];
    }
}

- (void)playerStandingFailed:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [self.tblView setHidden:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerStandingListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerStandingListSuccess object:nil];
}
- (void)playerStandingSuccess:(NSNotification *)notification{
    [activityIndicator stopAnimating];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerStandingListFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kPlayerStandingListSuccess object:nil];
    array4 = [notification.object objectForKey:@"PlayerStandingList"];
    if(![array4 isEqual:[NSNull null]] && [array4 count] > 0){
        [self.tblView setHidden:NO];
        [self.tblView reloadData];
    }
    else{
        [self.tblView setHidden:YES];
    }
}
- (void) callWebService:(NSString *)category{
    if([selectedCategory isEqualToString:@"Next Match Fixture"]){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamWiseUpComingListFailed:) name:kTeamWiseUpcomingMatchFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamWiseUpComingListSuccess:) name:kTeamWiseUpcomingMatchSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,[selectedTeam objectForKey:@"TeamId"],ktxtTeamId, nil];
        [[WebService sharedWebService] callTeamWiseUpcomingMatchWebService:dictionary];
    }
    else if([selectedCategory isEqualToString:@"Previous Match Result"]){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(previousMatchFailed:) name:kPreviousMatchFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(previousMatchSuccess:) name:kPreviousMatchSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId,[selectedTeam objectForKey:@"TeamId"],ktxtTeamId, nil];
        [[WebService sharedWebService] callPreviousMatchResultWebService:dictionary];
    }
    else if([selectedCategory isEqualToString:@"Team Standing"]){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamStandingFailed:) name:kTeamStandingFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(teamStandingSuccess:) name:kTeamStandingSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId, nil];
        [[WebService sharedWebService] callTeamStaningWebService:dictionary];
    }
    else if([selectedCategory isEqualToString:@"Player Standing"]){
        [activityIndicator startAnimating];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerStandingFailed:) name:kPlayerStandingListFailed object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerStandingSuccess:) name:kPlayerStandingListSuccess object:nil];
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[selectedLeague objectForKey:@"LeagueId"],ktxtLeagueId, nil];
        [[WebService sharedWebService] callPlayerStandingListWebService:dictionary];
    }
}

- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    if(isLeagueList){
        [btnLeague setTitle:[selectedLeague objectForKey:@"Title"] forState:UIControlStateNormal];
    }
    else if(isTeamList){
        [btnTeam setTitle:[selectedTeam objectForKey:@"TeamName"] forState:UIControlStateNormal];
    }
    else{
        if(selectedCategory){
            [btnCategory setTitle:selectedCategory forState:UIControlStateNormal];
            [self callWebService:selectedCategory];
        }
    }
    isLeagueList = false;
    isTeamList = false;
    [UIView commitAnimations];
}
- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200,pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    [UIView commitAnimations];
    
    if(isLeagueList){
      isLeagueList = false;
      selectedLeague = nil;
      [btnLeague setTitle:@"Select League" forState:UIControlStateNormal];
    }
    else if(isTeamList){
        isTeamList = false;
        selectedTeam = nil;
        [btnTeam setTitle:@"Select Team" forState:UIControlStateNormal];
    }
    else{
       [btnCategory setTitle:@"Select Category" forState:UIControlStateNormal];
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(isLeagueList){
        return [leagueList count];
    }
    else if(isTeamList){
        return [teamList count];
    }
    else{
        return [categoryArray count];
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(isLeagueList){
        return [[leagueList objectAtIndex:row] objectForKey:@"Title"];
    }
    else if(isTeamList){
        return [[teamList objectAtIndex:row] objectForKey:@"TeamName"];
    }
    else{
        return [categoryArray objectAtIndex:row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(isLeagueList){
        selectedLeague = [leagueList objectAtIndex:row];
    }
    else if(isTeamList){
        selectedTeam = [teamList objectAtIndex:row];
    }
    else{
        selectedCategory = [categoryArray objectAtIndex:row];
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    [view setBackgroundColor:[UIColor clearColor]];
    return view;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if([selectedCategory isEqualToString:@"Next Match Fixture"]){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,40)];
        [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
        
        UILabel *lbl1 = [[UILabel alloc] init];
        [lbl1 setFrame:CGRectMake(5, 0, 54, 21)];
        [lbl1 setText:@"Date"];
        [lbl1 setBackgroundColor:[UIColor clearColor]];
        [lbl1 setTextColor:[UIColor whiteColor]];
        [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl1];
        
        UILabel *lbl2 = [[UILabel alloc] init];
        [lbl2 setFrame:CGRectMake(70, 0, 100, 21)];
        [lbl2 setText:@"Home Team"];
        [lbl2 setBackgroundColor:[UIColor clearColor]];
        [lbl2 setTextColor:[UIColor whiteColor]];
        [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl2];
        
        UILabel *lbl3 = [[UILabel alloc] init];
        [lbl3 setFrame:CGRectMake(145, 0, 100, 21)];
        [lbl3 setText:@"Away Team"];
        [lbl3 setBackgroundColor:[UIColor clearColor]];
        [lbl3 setTextColor:[UIColor whiteColor]];
        [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl3];
        
        UILabel *lbl4 = [[UILabel alloc] init];
        [lbl4 setFrame:CGRectMake(232, 0,101,21)];
        [lbl4 setText:@"Place"];
        [lbl4 setBackgroundColor:[UIColor clearColor]];
        [lbl4 setTextColor:[UIColor whiteColor]];
        [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl4];
        
        return view;
    }
    else if([selectedCategory isEqualToString:@"Previous Match Result"]){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,40)];
        [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
        
        UILabel *lbl1 = [[UILabel alloc] init];
        [lbl1 setFrame:CGRectMake(5, 0, 64, 21)];
        [lbl1 setText:@"Date"];
        [lbl1 setBackgroundColor:[UIColor clearColor]];
        [lbl1 setTextColor:[UIColor whiteColor]];
        [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl1];
        
        UILabel *lbl2 = [[UILabel alloc] init];
        [lbl2 setFrame:CGRectMake(77, 0, 81, 21)];
        [lbl2 setText:@"Home Team"];
        [lbl2 setBackgroundColor:[UIColor clearColor]];
        [lbl2 setTextColor:[UIColor whiteColor]];
        [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl2];
        
        UILabel *lbl3 = [[UILabel alloc] init];
        [lbl3 setFrame:CGRectMake(163, 0, 81, 21)];
        [lbl3 setText:@"Away Team"];
        [lbl3 setBackgroundColor:[UIColor clearColor]];
        [lbl3 setTextColor:[UIColor whiteColor]];
        [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl3];
        
        UILabel *lbl4 = [[UILabel alloc] init];
        [lbl4 setFrame:CGRectMake(252, 0,40,21)];
        [lbl4 setText:@"HG"];
        [lbl4 setBackgroundColor:[UIColor clearColor]];
        [lbl4 setTextColor:[UIColor whiteColor]];
        [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl4];
        
        UILabel *lbl5 = [[UILabel alloc] init];
        [lbl5 setFrame:CGRectMake(297, 0,40,21)];
        [lbl5 setText:@"AG"];
        [lbl5 setBackgroundColor:[UIColor clearColor]];
        [lbl5 setTextColor:[UIColor whiteColor]];
        [lbl5 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl5];
        
        return view;
    }
    else if([selectedCategory isEqualToString:@"Team Standing"]){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,40)];
        [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
        
        UILabel *lbl1 = [[UILabel alloc] init];
        [lbl1 setFrame:CGRectMake(5, 0, 102, 21)];
        [lbl1 setText:@"Team"];
        [lbl1 setBackgroundColor:[UIColor clearColor]];
        [lbl1 setTextColor:[UIColor whiteColor]];
        [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl1];
        
        UILabel *lbl2 = [[UILabel alloc] init];
        [lbl2 setFrame:CGRectMake(115, 0, 20, 21)];
        [lbl2 setText:@"G"];
        [lbl2 setBackgroundColor:[UIColor clearColor]];
        [lbl2 setTextColor:[UIColor whiteColor]];
        [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl2];
        
        UILabel *lbl3 = [[UILabel alloc] init];
        [lbl3 setFrame:CGRectMake(143, 0, 20, 21)];
        [lbl3 setText:@"A"];
        [lbl3 setBackgroundColor:[UIColor clearColor]];
        [lbl3 setTextColor:[UIColor whiteColor]];
        [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl3];
        
        UILabel *lbl4 = [[UILabel alloc] init];
        [lbl4 setFrame:CGRectMake(167, 0,20,21)];
        [lbl4 setText:@"R"];
        [lbl4 setBackgroundColor:[UIColor clearColor]];
        [lbl4 setTextColor:[UIColor whiteColor]];
        [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl4];
        
        UILabel *lbl5 = [[UILabel alloc] init];
        [lbl5 setFrame:CGRectMake(191, 0,20,21)];
        [lbl5 setText:@"Y"];
        [lbl5 setBackgroundColor:[UIColor clearColor]];
        [lbl5 setTextColor:[UIColor whiteColor]];
        [lbl5 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl5];
        
        UILabel *lbl6 = [[UILabel alloc] init];
        [lbl6 setFrame:CGRectMake(229, 0,64,21)];
        [lbl6 setText:@"Points"];
        [lbl6 setBackgroundColor:[UIColor clearColor]];
        [lbl6 setTextColor:[UIColor whiteColor]];
        [lbl6 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl6];
        
        return view;
    }
    else if([selectedCategory isEqualToString:@"Player Standing"]){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,0,320,40)];
        [view setBackgroundColor:[UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1.0]];
        
        UILabel *lbl1 = [[UILabel alloc] init];
        [lbl1 setFrame:CGRectMake(5, 0, 63, 21)];
        [lbl1 setText:@"Player"];
        [lbl1 setBackgroundColor:[UIColor clearColor]];
        [lbl1 setTextColor:[UIColor whiteColor]];
        [lbl1 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl1];
        
        UILabel *lbl2 = [[UILabel alloc] init];
        [lbl2 setFrame:CGRectMake(74, 0, 63, 21)];
        [lbl2 setText:@"Team"];
        [lbl2 setBackgroundColor:[UIColor clearColor]];
        [lbl2 setTextColor:[UIColor whiteColor]];
        [lbl2 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl2];
        
        UILabel *lbl3 = [[UILabel alloc] init];
        [lbl3 setFrame:CGRectMake(148, 0, 20, 21)];
        [lbl3 setText:@"G"];
        [lbl3 setBackgroundColor:[UIColor clearColor]];
        [lbl3 setTextColor:[UIColor whiteColor]];
        [lbl3 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl3];
        
        UILabel *lbl4 = [[UILabel alloc] init];
        [lbl4 setFrame:CGRectMake(176, 0,20,21)];
        [lbl4 setText:@"A"];
        [lbl4 setBackgroundColor:[UIColor clearColor]];
        [lbl4 setTextColor:[UIColor whiteColor]];
        [lbl4 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl4];
        
        UILabel *lbl5 = [[UILabel alloc] init];
        [lbl5 setFrame:CGRectMake(200, 0,20,21)];
        [lbl5 setText:@"R"];
        [lbl5 setBackgroundColor:[UIColor clearColor]];
        [lbl5 setTextColor:[UIColor whiteColor]];
        [lbl5 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl5];
        
        UILabel *lbl6 = [[UILabel alloc] init];
        [lbl6 setFrame:CGRectMake(228, 0,20,21)];
        [lbl6 setText:@"Y"];
        [lbl6 setBackgroundColor:[UIColor clearColor]];
        [lbl6 setTextColor:[UIColor whiteColor]];
        [lbl6 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl6];
        
        UILabel *lbl7 = [[UILabel alloc] init];
        [lbl7 setFrame:CGRectMake(255, 0,64,21)];
        [lbl7 setText:@"Points"];
        [lbl7 setBackgroundColor:[UIColor clearColor]];
        [lbl7 setTextColor:[UIColor whiteColor]];
        [lbl7 setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
        [view addSubview:lbl7];
        
        return view;
    }
    else{
        return nil;
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if([selectedCategory isEqualToString:@"Next Match Fixture"]){
        return [array1 count];
    }
    else if([selectedCategory isEqualToString:@"Previous Match Result"]){
        return [array2 count];
    }
    else if([selectedCategory isEqualToString:@"Team Standing"]){
        return [array3 count];
    }
    else if([selectedCategory isEqualToString:@"Player Standing"]){
        return [array4 count];
    }
    else{
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([selectedCategory isEqualToString:@"Next Match Fixture"]){
        FirstCell *cell =(FirstCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"FirstCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (FirstCell *) currentObject;
                    break;
                }
            }
        }
        cell.lblDate.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"StartDate"];
        cell.lblHomeTeam.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"HomeTeamName"];
        cell.lblAwayTeam.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"AwayTeamName"];
        cell.lblPlace.text = [[array1 objectAtIndex:indexPath.row] objectForKey:@"MatchVenue"];
        return cell;
    }
    else if([selectedCategory isEqualToString:@"Previous Match Result"]){
        SecondCell *cell =(SecondCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SecondCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (SecondCell *) currentObject;
                    break;
                }
            }
        }
        cell.lblDate.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"MatchDate"];
        cell.lblHomeTeam.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"HomeTeamName"];
        cell.lblAwayTeam.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"AwayTeamName"];
        cell.lblHomeGoal.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"HTGoal"];
        cell.lblAwayGoal.text = [[array2 objectAtIndex:indexPath.row] objectForKey:@"ATGoal"];
        return cell;
    }
    else if([selectedCategory isEqualToString:@"Team Standing"]){
        TeamStandingCell *cell =(TeamStandingCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"TeamStandingCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (TeamStandingCell *) currentObject;
                    break;
                }
            }
        }
        cell.lblTeam.text = [[array3 objectAtIndex:indexPath.row] objectForKey:@"TeamName"];
        cell.lblG.text = [[array3 objectAtIndex:indexPath.row] objectForKey:@"HTGoal"];
        cell.lblA.text = [[array3 objectAtIndex:indexPath.row] objectForKey:@"HTAssist"];
        cell.lblR.text = [[array3 objectAtIndex:indexPath.row] objectForKey:@"HTRedCard"];
        cell.lblY.text = [[array3 objectAtIndex:indexPath.row] objectForKey:@"HTYellowPoint"];
        cell.lblPoints.text = [[array3 objectAtIndex:indexPath.row] objectForKey:@"HTPoints"];
        return cell;
    }
    else if([selectedCategory isEqualToString:@"Player Standing"]){
        PlayerStandingCell *cell =(PlayerStandingCell*) [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
        if (cell == nil){
            NSArray *topLevelObjects;
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"PlayerStandingCell" owner:self options:nil];
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell = (PlayerStandingCell *) currentObject;
                    break;
                }
            }
        }
        cell.lblPlayerName.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"PlayerName"];
        cell.lblMatch.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"TeamName"];
        cell.lblG.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"TGoal"];
        cell.lblA.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"TAssist"];
        cell.lblR.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"TRedCard"];
        cell.lblY.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"TYellowPoint"];
        cell.lblPoints.text = [[array4 objectAtIndex:indexPath.row] objectForKey:@"TPoints"];
        return cell;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 29;
}
@end
