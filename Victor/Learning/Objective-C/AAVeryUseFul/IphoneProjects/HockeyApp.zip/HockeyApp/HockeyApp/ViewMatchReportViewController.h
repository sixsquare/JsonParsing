//
//  ViewMatchReportViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 23/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewMatchReportViewController : UIViewController


@property (nonatomic, strong) IBOutlet UIButton *btnLeague;
@property (nonatomic, strong) IBOutlet UIButton *btnMatch;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;

@property (nonatomic, strong) IBOutlet UILabel *lblHomeTeam;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldGoal1;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldAssist1;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldRedcard1;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldYellowCard1;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldTotalPoints1;

@property (nonatomic, strong) IBOutlet UILabel *lblAwayTeam;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldGoal2;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldAssist2;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldRedcard2;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldYellowCard2;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldTotalPoints2;
@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIPickerView *picker;

@property (nonatomic, strong) IBOutlet UILabel *lblHomeTeam1;
@property (nonatomic, strong) IBOutlet UILabel *lblAwayTeam1;
@property (nonatomic, strong) IBOutlet UITableView *tblView1;
@property (nonatomic, strong) IBOutlet UITableView *tblView2;

@property (nonatomic) BOOL isLeagueList;
@property (nonatomic) BOOL isMatchList;
@property (nonatomic, strong) NSArray *leagueList;
@property (nonatomic, strong) NSArray *matchList;
@property (nonatomic, strong) NSDictionary *selectedLeague;
@property (nonatomic, strong) NSDictionary *selectedMatch;
@property (nonatomic, strong) NSString *playerId;

@property (nonatomic, strong) NSDictionary *matchPoint;

@property (nonatomic, strong) NSArray *homeTeamArray;
@property (nonatomic, strong) NSArray *awayTeamArray;

- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

- (IBAction)leagueButtonClicked:(id)sender;
- (IBAction)matchButtonClicked:(id)sender;
- (IBAction)saveButtonClicked:(id)sender;
@end
