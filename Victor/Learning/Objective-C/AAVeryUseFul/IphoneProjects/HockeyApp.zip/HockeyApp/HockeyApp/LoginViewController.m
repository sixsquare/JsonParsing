//
//  LoginViewController.m
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "LoginViewController.h"



@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize userNameTxt;
@synthesize passwordTxt;
@synthesize scrollView;
@synthesize activityIndicator;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [userNameTxt setReturnKeyType:UIReturnKeyNext];
    [passwordTxt setReturnKeyType:UIReturnKeyDone];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccess:) name:kLoginSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginFailed:) name:kLoginFailed object:nil];
}

- (void)forgotPassFailed:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kForgorPassFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kForgorPassSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}
- (void)forgotPassSuccess:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kForgorPassFailed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kForgorPassSuccess object:nil];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[notification.object objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
       [self.navigationController popViewControllerAnimated:YES];
    }
    else if([alertView tag] == 102 && buttonIndex == 0){
        if([[alertView textFieldAtIndex:0].text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0){
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(forgotPassFailed:) name:kForgorPassFailed object:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(forgotPassSuccess:) name:kForgorPassSuccess object:nil];
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:[alertView textFieldAtIndex:0].text,@"txtEMail", nil];
            [[WebService sharedWebService] callForgotPasswordWebService:dictionary];
        }
    }
}
- (void) loginSuccess:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [activityIndicator stopAnimating];
    NSLog(@"Data=%@",notification.object);
    NSDictionary *dictionary = notification.object;
    NSDictionary *userProfile = [dictionary objectForKey:@"UserProfile"];
    [[NSUserDefaults standardUserDefaults] setObject:userProfile forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert setTag:101];
    [alert show];
}

- (void) loginFailed:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [activityIndicator stopAnimating];
    NSDictionary *dictionary = notification.object;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[dictionary objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)loginAction:(id)sender {
    if([userNameTxt.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter username" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([passwordTxt.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        [userNameTxt resignFirstResponder];
        [passwordTxt resignFirstResponder];
        [activityIndicator startAnimating];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userNameTxt.text,kUserName,passwordTxt.text,kPassword,[[NSUserDefaults standardUserDefaults] objectForKey:kDeviceToken],kDeviceToken, nil];
        [[WebService sharedWebService] callLoginWebService:dictionary];
    }
}

- (IBAction)forgetPasswordAction:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please Enter your email address" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",@"Cancel", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert setTag:102];
    [alert show];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == userNameTxt){
        [userNameTxt resignFirstResponder];
        [passwordTxt becomeFirstResponder];
    }
    else if(textField == passwordTxt){
        [passwordTxt resignFirstResponder];
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == userNameTxt){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,passwordTxt.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == passwordTxt){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,passwordTxt.frame.origin.y+30,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    return YES;
}

#pragma mark -
#pragma mark Notifications

- (void)keyboardWillShow:(NSNotification *)notification {
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.3];
	
	CGRect frame = self.keyboardToolbar.frame;
	frame.origin.y = self.view.frame.size.height - 220.0;
	self.keyboardToolbar.frame = frame;
	
	[UIView commitAnimations];
}

- (void)keyboardWillHide:(NSNotification *)notification {
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.3];
	
	CGRect frame = self.keyboardToolbar.frame;
	frame.origin.y = self.view.frame.size.height;
	self.keyboardToolbar.frame = frame;
	
	[UIView commitAnimations];
}


-(void)textFieldDidBeginEditing:(UITextField *)textField{
    static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
    static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
    static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
    static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
    static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;
    
    CGRect textFieldRect =
    [self.view convertRect:textField.bounds fromView:textField];
    CGRect viewRect =
    [self.view convertRect:self.view.bounds fromView:self.view];
    
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator = midline - viewRect.origin.y - MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator = (MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION) * viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    
    UIInterfaceOrientation orientation =
    [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [self.view setFrame:viewFrame];
    [UIView commitAnimations];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
    
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}


@end
