//
//  AppDelegate.h
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"

@class LoginViewController;
@class SelectYourChoiceController;


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic) UINavigationController *navigationController;
@property(strong,nonatomic) SelectYourChoiceController *loginController;

@end
