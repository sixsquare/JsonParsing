//
//  LoginViewController.h
//  HockeyApp
//
//  Created by Ntech Technologies on 1/16/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "SelectYourChoiceController.h"
#import "PlayerDetailsController.h"


@class TPKeyboardAvoidingScrollView;

@interface LoginViewController : UIViewController  <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate>
{
    CGFloat animatedDistance;
}

@property (strong, nonatomic)  UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UITextField *passwordTxt;
@property (strong, nonatomic) IBOutlet UITextField *userNameTxt;
@property (nonatomic, strong) IBOutlet UIView *keyboardToolbar;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;


- (IBAction)loginAction:(id)sender;
- (IBAction)forgetPasswordAction:(id)sender;
- (void) loginSuccess:(NSNotification *)notification;
- (void) loginFailed:(NSNotification *)notification;


@end
