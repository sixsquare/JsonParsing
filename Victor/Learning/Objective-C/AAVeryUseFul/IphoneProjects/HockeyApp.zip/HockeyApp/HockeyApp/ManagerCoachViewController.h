//
//  ManagerCoachViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManagerCoachViewController : UIViewController

- (IBAction)teamSelectionButtonClicked:(id)sender;
- (IBAction)financeClicked:(id)sender;
- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

@end
