//
//  TeamSelectionViewController.h
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamSelectionViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIButton *btnLeague;
@property (nonatomic, strong) IBOutlet UIButton *btnDefenders;
@property (nonatomic, strong) IBOutlet UIButton *btnMidFielders;
@property (nonatomic, strong) IBOutlet UIButton *btnAttackers;
@property (nonatomic, strong) IBOutlet UIButton *btnOpponent;
@property (nonatomic, strong) IBOutlet UITextView *txtView;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIPickerView *picker;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;

@property (nonatomic, strong) NSString *playerId;

@property (nonatomic) BOOL isLeagueList;
@property (nonatomic) BOOL isDefender;
@property (nonatomic) BOOL isMidFielder;
@property (nonatomic) BOOL isAttacker;
@property (nonatomic) BOOL isOpponent;

@property (nonatomic, strong) NSArray *leagueList;
@property (nonatomic, strong) NSArray *tempArray;
@property (nonatomic, strong) NSArray *opponentArray;

@property (nonatomic, strong) NSDictionary *selectedLeague;
@property (nonatomic, strong) NSString *selectedDefender;
@property (nonatomic, strong) NSString *selectedMidFielder;
@property (nonatomic, strong) NSString *selectedAttacker;
@property (nonatomic, strong) NSDictionary *selectedOpponent;

@property (nonatomic, strong) NSMutableArray *arrayPlayerIds;
@property (nonatomic, strong) NSArray *players;


- (IBAction)backButtonClicked:(id)sender;
- (IBAction)logoutButtonClicked:(id)sender;

- (IBAction)btnLeagueClicked:(id)sender;
- (IBAction)btnDefendersClicked:(id)sender;
- (IBAction)btnMidFieldersClicked:(id)sender;
- (IBAction)btnAttackersClicked:(id)sender;
- (IBAction)btnOpponentClicked:(id)sender;
- (IBAction)saveButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;

@end
