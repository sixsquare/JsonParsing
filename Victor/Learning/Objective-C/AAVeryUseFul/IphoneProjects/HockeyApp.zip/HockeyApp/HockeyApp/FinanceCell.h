//
//  FinanceCell.h
//  HockeyApp
//
//  Created by Amit Parmar on 24/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FinanceCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblFinance;
@property (nonatomic, strong) IBOutlet UILabel *lblCharge;
@property (nonatomic, strong) IBOutlet UILabel *lblPaid;
@property (nonatomic, strong) IBOutlet UILabel *lblNotPaid;
@property (nonatomic, strong) IBOutlet UIButton *btnDelete;
@property (nonatomic, strong) IBOutlet UIButton *btnEdit;

@end
