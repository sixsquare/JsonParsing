//
//  SurveySetupViewController.m
//  POS
//
//  Created by N-tech Technologies on 2/14/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "SurveySetupViewController.h"

@interface SurveySetupViewController ()

@end

@implementation SurveySetupViewController
@synthesize popover;
@synthesize btnQuestiontype;
@synthesize lblQuestiontype;
@synthesize lblQuestion;
@synthesize txtQuestion;
@synthesize txtOption_1;
@synthesize txtOption_2;
@synthesize txtOption_3;
@synthesize txtOption_4;
@synthesize btnSave;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(IBAction)btnSaveClicked:(id)sender {
    
    txtQuestion.hidden = YES;
    lblQuestion.hidden = YES;
    txtOption_1.hidden = YES;
    txtOption_2.hidden = YES;
    txtOption_3.hidden = YES;
    txtOption_4.hidden = YES;
    btnSave.hidden = YES;

}

-(IBAction)btnQuestiontypeClicked:(id)sender{
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    txtQuestion.hidden = YES;
    lblQuestion.hidden = YES;
    txtOption_1.hidden = YES;
    txtOption_2.hidden = YES;
    txtOption_3.hidden = YES;
    txtOption_4.hidden = YES;
    btnSave.hidden = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
