//
//  SurveySetupViewController.h
//  POS
//
//  Created by N-tech Technologies on 2/14/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SurveySetupViewController : UIViewController 

@property (nonatomic, retain) UIPopoverController *popover;
@property (nonatomic,strong) IBOutlet UIButton *btnQuestiontype;
@property (nonatomic,strong) IBOutlet UILabel *lblQuestiontype;
@property (nonatomic,strong) IBOutlet UILabel *lblQuestion;
@property (nonatomic,strong) IBOutlet UITextView *txtQuestion;
@property (nonatomic,strong) IBOutlet UITextField *txtOption_1;
@property (nonatomic,strong) IBOutlet UITextField *txtOption_2;
@property (nonatomic,strong) IBOutlet UITextField *txtOption_3;
@property (nonatomic,strong) IBOutlet UITextField *txtOption_4;
@property (nonatomic,strong) IBOutlet UIButton *btnSave;

-(IBAction)btnQuestiontypeClicked:(id)sender;
-(IBAction)btnSaveClicked:(id)sender;

@end
