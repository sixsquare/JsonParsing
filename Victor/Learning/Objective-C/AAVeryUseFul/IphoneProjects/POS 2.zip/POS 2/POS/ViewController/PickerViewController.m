//
//  PickerViewController.m
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "PickerViewController.h"

@implementation PickerViewController

@synthesize tblView;
@synthesize itemsArray;
@synthesize selectedArray;
@synthesize pickerViewControllerDelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [self.tblView setEditing:YES animated:YES];
     self.tblView.allowsMultipleSelectionDuringEditing = YES;
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)cancelButtonClicked:(id)sender{
    [pickerViewControllerDelegate selectedItems:@""];
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)doneButtonClicked:(id)sender{
    if([selectedArray count] == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select at least one product" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }else{
        [pickerViewControllerDelegate selectedItems:[selectedArray componentsJoinedByString:@","]];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [itemsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
    if(!cell){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Identifier"];
    }
    cell.textLabel.text = [itemsArray objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:selectedArray];
    [array addObject:[itemsArray objectAtIndex:indexPath.row]];
    selectedArray = array;
}
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:selectedArray];
    [array removeObject:[itemsArray objectAtIndex:indexPath.row]];
    selectedArray = array;
}
@end
