//
//  RegistrationViewController.h
//  POS
//
//  Created by Ntech.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistrationViewController : UIViewController <UISplitViewControllerDelegate>{
    
}

@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIButton *btnTermsAndCondition;
@property (nonatomic, strong) IBOutlet UIButton *btnSubmit;
@property (nonatomic, strong) IBOutlet UIButton *btnRCYes;
@property (nonatomic, strong) IBOutlet UIButton *btnRCNo;
@property (nonatomic) BOOL checkRC;

@property (nonatomic, strong) IBOutlet UITextField *txtFieldContactName;
@property (nonatomic, strong) IBOutlet UITextField *txtRegistrationId;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldAlternateEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldContactNumber;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldAlternateContactNumber;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldCountry;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldCity;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldState;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldContactPerson;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldDesignation;
@property (weak, nonatomic) IBOutlet UIImageView *imgOutletName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldConfirmPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldOutletName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldNoOfOutlets;

@property (nonatomic, strong) IBOutlet UIView *pickerBackgroundView;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;


@property (nonatomic, strong) NSDictionary *selectedCountry;
@property (nonatomic, strong) NSDictionary *selectedState;
@property (nonatomic, strong) NSDictionary *selectedCity;

@property (nonatomic) BOOL isCountryPicker;
@property (nonatomic) BOOL isStatePicker;
@property (nonatomic) BOOL isCityPicker;

@property (nonatomic, strong) NSArray *countryArray;
@property (nonatomic, strong) NSArray *stateArray;
@property (nonatomic, strong) NSArray *cityArray;

- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnTermsAndConditionClicked:(id)sender;
- (IBAction)btnSubmitClicked:(id)sender;
- (IBAction)btnRCYesClicked:(id)sender;
- (IBAction)btnRCNoClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)termsAndConditionLinkClicked:(id)sender;

@end
