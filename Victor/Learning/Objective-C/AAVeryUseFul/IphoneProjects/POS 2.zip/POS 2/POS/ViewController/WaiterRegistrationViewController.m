//
//  WaiterRegistrationViewController.m
//  POS
//
//  Created by Ntech Technologies on 2/13/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "WaiterRegistrationViewController.h"

@interface WaiterRegistrationViewController ()

@end

@implementation WaiterRegistrationViewController

@synthesize txtFieldFirstName;
@synthesize txtFieldLastName;
@synthesize txtFieldEmail;
@synthesize txtFieldContactNumber;
@synthesize txtFieldSocialSecurityNumber;
@synthesize txtFieldDrivingLicenceNumber;
@synthesize txtFieldUserName;
@synthesize txtFieldPassword;
@synthesize txtFieldConfirmPassword;
@synthesize txtFieldBirthDate;
@synthesize txtFieldGender;
@synthesize txtFieldImageName;
@synthesize pickerBackgroundView;
@synthesize pickerView;
@synthesize imagePickerPopoverController;
@synthesize imageView;
@synthesize choosenImage;
@synthesize btnUpload;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [txtFieldFirstName setReturnKeyType:UIReturnKeyNext];
    [txtFieldLastName setReturnKeyType:UIReturnKeyNext];
    [txtFieldEmail setReturnKeyType:UIReturnKeyNext];
    [txtFieldContactNumber setReturnKeyType:UIReturnKeyNext];
    [txtFieldSocialSecurityNumber setReturnKeyType:UIReturnKeyNext];
    [txtFieldDrivingLicenceNumber setReturnKeyType:UIReturnKeyNext];
    [txtFieldUserName setReturnKeyType:UIReturnKeyNext];
    [txtFieldPassword setReturnKeyType:UIReturnKeyNext];
    [txtFieldConfirmPassword setReturnKeyType:UIReturnKeyNext];
    [txtFieldBirthDate setReturnKeyType:UIReturnKeyNext];
    [txtFieldGender setReturnKeyType:UIReturnKeyDone];
}
- (IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnSubmitClicked:(id)sender{
    if([txtFieldFirstName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length==0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter First name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldLastName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Last Name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter email id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldContactNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Contact Number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldSocialSecurityNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Social Security Number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldDrivingLicenceNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Driving Licence Number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter User Name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if(![txtFieldConfirmPassword.text isEqualToString:txtFieldConfirmPassword.text]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Password not matched with confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    
    else if([txtFieldBirthDate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Birth Date" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldGender.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter Gender" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Waiter registered successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}

- (IBAction)btnImageuploadClicked:(id)sender{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePickerPopoverController = [[UIPopoverController alloc] initWithContentViewController:imagePicker];
    [imagePickerPopoverController presentPopoverFromRect:btnUpload.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
   
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *finalImage = nil;
    NSString *stringPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSError *error = nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:stringPath])
        [[NSFileManager defaultManager] createDirectoryAtPath:stringPath withIntermediateDirectories:NO attributes:nil error:&error];
    
    NSString *fileName = [stringPath stringByAppendingFormat:@"/profile.png"];
    [txtFieldImageName setText:fileName];
    NSLog(@"txtFieldImageName %@",txtFieldImageName.text);
    NSData *data = UIImagePNGRepresentation(finalImage);
    [data writeToFile:fileName atomically:YES];
    
    [imagePickerPopoverController dismissPopoverAnimated:YES];
}

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,800, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    else{
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,1200, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,800, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    else{
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,1200, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
   if(textField == txtFieldPassword){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -100, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldConfirmPassword){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -150, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldBirthDate){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -200, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldGender){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -250, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == txtFieldFirstName){
        [txtFieldFirstName resignFirstResponder];
        [txtFieldLastName becomeFirstResponder];
    }
    else if(textField == txtFieldLastName){
        [txtFieldLastName resignFirstResponder];
        [txtFieldEmail becomeFirstResponder];
    }
    else if(textField == txtFieldEmail){
        [txtFieldEmail resignFirstResponder];
        [txtFieldContactNumber becomeFirstResponder];
    }
    else if(textField == txtFieldContactNumber){
        [txtFieldContactNumber resignFirstResponder];
        [txtFieldSocialSecurityNumber becomeFirstResponder];
    }
    else if(textField == txtFieldSocialSecurityNumber){
        [txtFieldSocialSecurityNumber resignFirstResponder];
        [txtFieldDrivingLicenceNumber becomeFirstResponder];
    }
    else if(textField == txtFieldDrivingLicenceNumber){
        [txtFieldDrivingLicenceNumber resignFirstResponder];
        [txtFieldUserName becomeFirstResponder];
    }
    else if(textField == txtFieldUserName){
        [txtFieldUserName resignFirstResponder];
        [txtFieldPassword becomeFirstResponder];
    }
    else if(textField == txtFieldPassword){
        [txtFieldPassword resignFirstResponder];
        [txtFieldConfirmPassword becomeFirstResponder];
    }
    else if(textField == txtFieldConfirmPassword){
        [txtFieldConfirmPassword resignFirstResponder];
        [txtFieldBirthDate becomeFirstResponder];
    }
    else if(textField == txtFieldBirthDate){
        [txtFieldBirthDate resignFirstResponder];
        [txtFieldGender becomeFirstResponder];
    }
    else if(textField == txtFieldGender){
        [txtFieldGender resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,0, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    return YES;
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

@end
