//
//  RestaurantRegistrationViewController.m
//  POS
//
//  Created by N-tech Technologies on 2/13/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "RestaurantRegistrationViewController.h"

@interface RestaurantRegistrationViewController ()

@end

@implementation RestaurantRegistrationViewController
@synthesize txtAddress;
@synthesize txtUsername;
@synthesize txtPassword;
@synthesize txtConfirmPassword;
@synthesize txtCountry;
@synthesize txtState;
@synthesize txtCity;
@synthesize txtZipcode;
@synthesize txtContactNo;
@synthesize txtAlternateContactNo;
@synthesize txtManagerName;
@synthesize txtEmailID;
@synthesize txtNoOfEmployees;

@synthesize pickerBackgroundView;
@synthesize pickerView;

@synthesize selectedCity;
@synthesize selectedCountry;
@synthesize selectedState;

@synthesize isCityPicker;
@synthesize isCountryPicker;
@synthesize isStatePicker;

@synthesize cityArray;
@synthesize countryArray;
@synthesize stateArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    //[txtAddress setReturnKeyType:UIReturnKeyNext];
    [txtUsername setReturnKeyType:UIReturnKeyNext];
    [txtPassword setReturnKeyType:UIReturnKeyNext];
    [txtConfirmPassword setReturnKeyType:UIReturnKeyNext];
    [txtZipcode setReturnKeyType:UIReturnKeyNext];
    [txtContactNo setReturnKeyType:UIReturnKeyNext];
    [txtAlternateContactNo setReturnKeyType:UIReturnKeyNext];
    [txtEmailID setReturnKeyType:UIReturnKeyNext];
    [txtNoOfEmployees setReturnKeyType:UIReturnKeyDone];

}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}
- (IBAction)btnSubmitClicked:(id)sender{
 
    if([txtUsername.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter company user name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }

    else if([txtZipcode.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter zip code" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtContactNo.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter contact number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtAlternateContactNo.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter alternate contact number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtEmailID.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter email id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtNoOfEmployees.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter no of employees" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        
    }
}

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,800, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    else{
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,1200, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
    if(isCountryPicker){
        selectedCountry = nil;
    }
    if(isStatePicker){
        selectedState = nil;
    }
    if(isCityPicker){
        selectedCity = nil;
    }
}
- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,800, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    else{
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,1200, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
    if(isCountryPicker){
    }
    if(isStatePicker){
    }
    if(isCityPicker){
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
//    if(textField == txtCountry){
//        // Call Country Web Service here
//        return NO;
//    }
//    else if(textField == txtState){
//        // Call state Web Service here
//        return NO;
//    }

    if(textField == txtContactNo){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -100, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtAlternateContactNo){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -150, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtEmailID){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -200, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtNoOfEmployees){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-250, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
   
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
  
     if(textField == txtUsername){
        [txtUsername resignFirstResponder];
        [txtPassword becomeFirstResponder];
    }
    else if(textField == txtPassword){
        [txtPassword resignFirstResponder];
        [txtConfirmPassword becomeFirstResponder];
    }
    else if(textField == txtConfirmPassword){
        [txtConfirmPassword resignFirstResponder];
        [txtZipcode becomeFirstResponder];
    }
    else if(textField == txtZipcode){
        [txtZipcode resignFirstResponder];
        [txtContactNo becomeFirstResponder];
    }
    else if(textField == txtContactNo){
        [txtContactNo resignFirstResponder];
        [txtAlternateContactNo becomeFirstResponder];
    }
    else if(textField == txtAlternateContactNo){
        [txtAlternateContactNo resignFirstResponder];
        [txtEmailID becomeFirstResponder];
    }
    else if(textField == txtEmailID){
        [txtEmailID resignFirstResponder];
        [txtNoOfEmployees becomeFirstResponder];
    }
    else if(textField == txtNoOfEmployees){
        [txtNoOfEmployees resignFirstResponder];
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,0, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    
    return YES;
}


@end
