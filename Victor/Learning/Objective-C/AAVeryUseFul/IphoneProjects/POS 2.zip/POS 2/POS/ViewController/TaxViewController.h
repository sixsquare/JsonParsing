//
//  TaxViewController.h
//  POS
//
//  Created by Ntech Technologies on 2/14/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TaxViewController : UIViewController 

@property (weak, nonatomic) IBOutlet UIButton *btnSave;
@property (weak, nonatomic) IBOutlet UITextField *txtTaxName;
@property (weak, nonatomic) IBOutlet UITextField *txtTaxPercent;

- (IBAction)btnSaveClicked:(id)sender;

@end
