//
//  RestaurantListViewController.h
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RestaurantListViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITableView *tblView;

- (IBAction)addRestaurantButtonClicked:(id)sender;
@end
