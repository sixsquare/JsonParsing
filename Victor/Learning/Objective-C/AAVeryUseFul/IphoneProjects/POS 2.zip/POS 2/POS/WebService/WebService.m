//
//  WebService.m
//  HockeyApp
//
//  Created by Amit Parmar on 21/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import "WebService.h"
#import "ASIFormDataRequest.h"

static WebService *webService;
@implementation WebService


+(WebService *)sharedWebService{
    if(!webService){
        webService = [[WebService alloc] init];
    }
    return webService;
}

// -----------------------------------------------------------------------------------------

#pragma mark
#pragma mark Country Request/Response

// -----------------------------------------------------------------------------------------
- (void)countryResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kCountryFail object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kCountrySuccess object:dictionary];
        }
    }
}
- (void) callCountryWebService{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(countryResponse:)];
    [request startAsynchronous];
}

// -----------------------------------------------------------------------------------------

#pragma mark
#pragma mark State Request/Response

// -----------------------------------------------------------------------------------------
- (void)stateResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kStateFail object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kStateSuccess object:dictionary];
        }
    }
}

- (void) callStateWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(stateResponse:)];
    [request startAsynchronous];
}

// -----------------------------------------------------------------------------------------

#pragma mark
#pragma mark City Request/Response

// -----------------------------------------------------------------------------------------
- (void)cityResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kCityFail object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kCitySuccess object:dictionary];
        }
    }
}

- (void) callCityWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(cityResponse:)];
    [request startAsynchronous];
}

// -----------------------------------------------------------------------------------------

#pragma mark
#pragma mark Vendor Registration Request/Response

// -----------------------------------------------------------------------------------------
- (void)vendorRegistrationResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kVendorRegistrationFail object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kVendorRegistrationSuccess object:dictionary];
        }
    }
}
- (void) callVendorRegistrationWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(vendorRegistrationResponse:)];
    [request startAsynchronous];
}

// -----------------------------------------------------------------------------------------

#pragma mark
#pragma mark Restaurant Registration Request/Response

// -----------------------------------------------------------------------------------------
- (void)restaurantRegistrationResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kRestaurantFail object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kRestaurantSuccess object:dictionary];
        }
    }
}

- (void) callRestaurantRegistrationWebService:(NSDictionary *)dictionary{
    NSString *url = @"http://soccerapp.astrowow.com/webservice/add-finance-to-team.php";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(restaurantRegistrationResponse:)];
    [request startAsynchronous];
}

// -----------------------------------------------------------------------------------------

#pragma mark
#pragma mark Login Request/Response

// -----------------------------------------------------------------------------------------
- (void)loginResponse:(ASIFormDataRequest *)request{
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[request responseData] options: NSJSONReadingMutableContainers error: nil];
    if(dictionary){
        int status = [[dictionary objectForKey:@"status"] intValue];
        if(status == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:dictionary];
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSuccess object:dictionary];
        }
    }
}

- (void) callLoginWebService:(NSDictionary *)dictionary{
    NSString *url = @"";
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(loginResponse:)];
    [request startAsynchronous];
}

@end