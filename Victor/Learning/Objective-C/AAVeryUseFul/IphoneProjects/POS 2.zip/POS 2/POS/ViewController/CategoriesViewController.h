//
//  CategoriesViewController.h
//  POS
//
//  Created by Ntech Technologies on 2/26/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoriesViewController : UIViewController

@end
