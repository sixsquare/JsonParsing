//
//  LoginViewController.h
//  POS
//
//  Created by Ntech.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITextField *textFieldUsername;
@property (nonatomic, strong) IBOutlet UITextField *textFieldPassword;
@property (nonatomic, strong) IBOutlet UIButton *btnLogin;
@property (nonatomic, strong) IBOutlet UIButton *btnRegistration;
@property (nonatomic, strong) IBOutlet UIButton *btnForgotPassword;
@property (nonatomic, strong) IBOutlet UIImageView *backGroundImageView;
@property (nonatomic, strong) IBOutlet UIImageView *loginBackgroundImageView;

- (IBAction)loginButtonClicked:(id)sender;
- (IBAction)registrationButtonClicked:(id)sender;
- (IBAction)forgotPasswordButtonClicked:(id)sender;

@end
