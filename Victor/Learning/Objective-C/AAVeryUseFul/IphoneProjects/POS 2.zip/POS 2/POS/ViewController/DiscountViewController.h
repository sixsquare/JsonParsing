//
//  DiscountViewController.h
//  POS
//
//  Created by N-tech Technologies on 2/14/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PickerViewController.h"

@interface DiscountViewController : UIViewController <UIPopoverControllerDelegate,PickerViewControllerDelegate>

@property (nonatomic, strong) IBOutlet UITextField *txtDiscountName;
@property (nonatomic, strong) IBOutlet UITextField *txtDiscountPercent;
@property (nonatomic, strong) IBOutlet UITextView *txtProducts;
@property (nonatomic, strong) IBOutlet UIButton *btnSave;
@property (nonatomic, strong) UIPopoverController *popOver;

-(IBAction)btnSaveClicked:(id)sender;

@end
