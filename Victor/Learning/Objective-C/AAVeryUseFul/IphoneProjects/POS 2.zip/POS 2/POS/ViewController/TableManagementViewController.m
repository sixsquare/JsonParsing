//
//  TableManagementViewController.m
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "TableManagementViewController.h"

@implementation TableManagementViewController
@synthesize scrollView;
@synthesize tableCount;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 1){
        NSMutableDictionary *dictionary = [[NSMutableDictionary alloc] initWithDictionary:[[NSUserDefaults standardUserDefaults] objectForKey:kStoredTableConfiguration]];
        [dictionary setObject:[alertView textFieldAtIndex:0].text forKey:[NSString stringWithFormat:@"%d",[alertView tag]-1000]];
        [[NSUserDefaults standardUserDefaults] setObject:dictionary forKey:kStoredTableConfiguration];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (void) tableButtonClicked:(id) sender{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Enter Number Of Chairs" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Cancel",@"Done", nil];
    [alert setTag:[sender tag]];
    [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [alert textFieldAtIndex:0].text = [[[NSUserDefaults standardUserDefaults] objectForKey:kStoredTableConfiguration] objectForKey:[NSString stringWithFormat:@"%d",[sender tag]-1000]];
    [alert show];
}

- (void) storeTableData{
    NSMutableDictionary *dictionary = [[NSMutableDictionary alloc] init];
    for(int i=0;i<tableCount;i++){
        [dictionary setObject:@"" forKey:[NSString stringWithFormat:@"%d",i+1]];
    }
    [[NSUserDefaults standardUserDefaults] setObject:dictionary forKey:kStoredTableConfiguration];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void) createTables{
    int x = 55;
    int y = 60;
    int count = 0;
    for(int i=0;i<tableCount;i++){
        if(count >= 3){
            count = 0;
            x = 55;
            y = y + 230;
        }
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(x, y, 100, 100)];
        [button setTitle:[NSString stringWithFormat:@"Table-%d",i+1] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTag:1000+i+1];
        [button addTarget:self action:@selector(tableButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [button setBackgroundColor:[UIColor blueColor]];
        [scrollView addSubview:button];
        count++;
        x = x + 230;
    }
    int newCount = 0;
    if(tableCount%3 != 0){
       newCount = (tableCount/3)+1;
    }
    else{
        newCount = tableCount/3;
    }
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*230)+60)];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    if(![[NSUserDefaults standardUserDefaults] objectForKey:kStoredTableConfiguration]){
        [self storeTableData];
    }
    else{
        tableCount = [[[[NSUserDefaults standardUserDefaults] objectForKey:kStoredTableConfiguration] allKeys] count];
    }
    [self createTables];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction) addTableButtonClicked:(id)sender{
    int x = (tableCount%3)*230+55;
    int y = (tableCount/3)*230+60;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:CGRectMake(x, y, 100, 100)];
    [button setTitle:[NSString stringWithFormat:@"Table-%d",tableCount+1] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button setTag:1000+tableCount+1];
    [button addTarget:self action:@selector(tableButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button setBackgroundColor:[UIColor blueColor]];
    [scrollView addSubview:button];
    
    NSMutableDictionary *dictionary = [[NSMutableDictionary alloc] initWithDictionary:[[NSUserDefaults standardUserDefaults] objectForKey:kStoredTableConfiguration]];
    [dictionary setObject:@"" forKey:[NSString stringWithFormat:@"%d",tableCount+1]];
    [[NSUserDefaults standardUserDefaults] setObject:dictionary forKey:kStoredTableConfiguration];
    [[NSUserDefaults standardUserDefaults] synchronize];
    tableCount++;
    
    int newCount = 0;
    if(tableCount%3 != 0){
        newCount = (tableCount/3)+1;
    }
    else{
        newCount = tableCount/3;
    }
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*230)+60)];
    
}
@end
