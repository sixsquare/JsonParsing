//
//  RestaurantListViewController.m
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "RestaurantListViewController.h"
#import "RestaurantRegistrationViewController.h"

@implementation RestaurantListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)addRestaurantButtonClicked:(id)sender{
    RestaurantRegistrationViewController *restaurantRegistrationViewController = [[RestaurantRegistrationViewController alloc] initWithNibName:@"RestaurantRegistrationViewController" bundle:nil];
    [self.navigationController pushViewController:restaurantRegistrationViewController animated:YES];
}

@end
