//
//  RestaurantRegistrationViewController.h
//  POS
//
//  Created by N-tech Technologies on 2/13/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RestaurantRegistrationViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIButton *btnSubmit;

@property (nonatomic, strong) IBOutlet UITextView  *txtAddress;
@property (nonatomic, strong) IBOutlet UITextField *txtUsername;
@property (nonatomic, strong) IBOutlet UITextField *txtPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtConfirmPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtCountry;
@property (nonatomic, strong) IBOutlet UITextField *txtState;
@property (nonatomic, strong) IBOutlet UITextField *txtCity;
@property (nonatomic, strong) IBOutlet UITextField *txtZipcode;
@property (nonatomic, strong) IBOutlet UITextField *txtContactNo;
@property (nonatomic, strong) IBOutlet UITextField *txtAlternateContactNo;
@property (nonatomic, strong) IBOutlet UITextField *txtManagerName;
@property (nonatomic, strong) IBOutlet UITextField *txtEmailID;
@property (nonatomic, strong) IBOutlet UITextField *txtNoOfEmployees;

@property (nonatomic, strong) IBOutlet UIView *pickerBackgroundView;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;

@property (nonatomic, strong) NSDictionary *selectedCountry;
@property (nonatomic, strong) NSDictionary *selectedState;
@property (nonatomic, strong) NSDictionary *selectedCity;

@property (nonatomic) BOOL isCountryPicker;
@property (nonatomic) BOOL isStatePicker;
@property (nonatomic) BOOL isCityPicker;

@property (nonatomic, strong) NSArray *countryArray;
@property (nonatomic, strong) NSArray *stateArray;
@property (nonatomic, strong) NSArray *cityArray;

- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSubmitClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;

@end
