//
//  MenuSetupViewController.h
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuSetupViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (nonatomic, strong) IBOutlet UITextField *txtCategory;
@property (nonatomic, strong) IBOutlet UITextField *txtProduct;
@property (nonatomic, strong) IBOutlet UITextField *txtType;
@property (nonatomic, strong) IBOutlet UITextField *txtProductName;
@property (nonatomic, strong) IBOutlet UITextView  *txtProductDescription;
@property (nonatomic, strong) IBOutlet UITextField *txtCurrency;
@property (nonatomic, strong) IBOutlet UITextField *txtPrice;
@property (nonatomic, strong) IBOutlet UITextView *txtIngredients;
@property (nonatomic, strong) IBOutlet UITextField *txtImageUpload;
@property (nonatomic, strong) UIPopoverController *imagePickerPopoverController;
@property (nonatomic, strong) IBOutlet UIButton *btnUpload;

@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIPickerView *picker;

- (IBAction)uploadButtonClicked:(id)sender;
- (IBAction)saveButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;


@end
