//
//  LoginViewController.m
//  POS
//
//  Created by Ntech.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "SplitController.h"
#import "RestaurantListViewController.h"
#import "RegistrationViewController.h"

@implementation LoginViewController

@synthesize textFieldUsername;
@synthesize textFieldPassword;
@synthesize btnLogin;
@synthesize btnRegistration;
@synthesize btnForgotPassword;
@synthesize backGroundImageView;
@synthesize loginBackgroundImageView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [textFieldUsername setReturnKeyType:UIReturnKeyNext];
    [textFieldPassword setReturnKeyType:UIReturnKeyDone];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)loginButtonClicked:(id)sender{
    if([textFieldUsername.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter email id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([textFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        SplitController *splitController = [[SplitController alloc] initWithStyle:UITableViewStylePlain];
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:splitController];
        [navigationController setNavigationBarHidden:YES];
        RestaurantListViewController *restaurantListViewController = [[RestaurantListViewController alloc] initWithNibName:@"RestaurantListViewController" bundle:nil];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:restaurantListViewController];
        [navController setNavigationBarHidden:YES];
        [AppDelegate delegete].splitViewController = [[UISplitViewController alloc] init];
        [AppDelegate delegete].splitViewController.viewControllers = [NSArray arrayWithObjects:navigationController, navController, nil];
        [AppDelegate delegete].window.rootViewController = [AppDelegate delegete].splitViewController;
    }
}

- (IBAction)registrationButtonClicked:(id)sender{
    RegistrationViewController *registrationViewController = [[RegistrationViewController alloc] initWithNibName:@"RegistrationViewController" bundle:nil];
    [self.navigationController pushViewController:registrationViewController animated:YES];
    
}
- (IBAction)forgotPasswordButtonClicked:(id)sender{
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == textFieldUsername){
        [textFieldUsername resignFirstResponder];
        [textFieldPassword becomeFirstResponder];
    }
    else if(textField == textFieldPassword){
        [textFieldPassword resignFirstResponder];
    }
    return YES;
}

@end
