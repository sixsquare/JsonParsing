//
//  WaiterRegistrationViewController.h
//  POS
//
//  Created by Ntech Technologies on 2/13/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaiterRegistrationViewController : UIViewController<UITextFieldDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate,UIScrollViewDelegate, UIPopoverControllerDelegate>

@property (nonatomic, strong) IBOutlet UIButton *btnBack;

@property (nonatomic, strong) IBOutlet UIButton *btnSubmit;

@property (nonatomic, strong) IBOutlet UITextField *txtFieldFirstName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldLastName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldContactNumber;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldSocialSecurityNumber;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldDrivingLicenceNumber;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldUserName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldConfirmPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldBirthDate;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldGender;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldImageName;
@property (nonatomic, strong) UIImage *choosenImage;
@property (nonatomic, strong) UIPopoverController *imagePickerPopoverController;
@property(nonatomic, strong)UIView *imageView;
@property (nonatomic, strong) IBOutlet UIButton *btnUpload;


@property (nonatomic, strong) IBOutlet UIView *pickerBackgroundView;
@property (nonatomic, strong) IBOutlet UIPickerView *pickerView;


- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnImageuploadClicked:(id)sender;
- (IBAction)btnSubmitClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;

@end
