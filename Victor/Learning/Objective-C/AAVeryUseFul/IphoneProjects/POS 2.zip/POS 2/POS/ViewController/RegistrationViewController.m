//
//  RegistrationViewController.m
//  POS
//
//  Created by Ntech.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "RegistrationViewController.h"
#import "TermsAndConditionViewController.h"

@implementation RegistrationViewController

@synthesize btnBack;
@synthesize btnTermsAndCondition;
@synthesize btnSubmit;
@synthesize btnRCYes;
@synthesize btnRCNo;
@synthesize checkRC;
@synthesize txtFieldContactName;
@synthesize txtRegistrationId;
@synthesize txtFieldEmail;
@synthesize txtFieldAlternateEmail;
@synthesize txtFieldContactNumber;
@synthesize txtFieldAlternateContactNumber;
@synthesize txtFieldCountry;
@synthesize txtFieldCity;
@synthesize txtFieldState;
@synthesize txtFieldContactPerson;
@synthesize txtFieldDesignation;
@synthesize txtFieldPassword;
@synthesize txtFieldConfirmPassword;
@synthesize txtFieldOutletName;
@synthesize txtFieldNoOfOutlets;
@synthesize pickerBackgroundView;
@synthesize pickerView;
@synthesize isCountryPicker;
@synthesize isStatePicker;
@synthesize isCityPicker;
@synthesize selectedCountry;
@synthesize selectedCity;
@synthesize selectedState;
@synthesize imgOutletName;

@synthesize countryArray;
@synthesize stateArray;
@synthesize cityArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    txtFieldOutletName.hidden = NO;
    txtFieldNoOfOutlets.hidden = YES;
    imgOutletName.hidden = YES;
    checkRC = NO;
    [txtFieldContactName setReturnKeyType:UIReturnKeyNext];
    [txtRegistrationId setReturnKeyType:UIReturnKeyNext];
    [txtFieldEmail setReturnKeyType:UIReturnKeyNext];
    [txtFieldAlternateEmail setReturnKeyType:UIReturnKeyNext];
    [txtFieldContactNumber setReturnKeyType:UIReturnKeyNext];
    [txtFieldAlternateContactNumber setReturnKeyType:UIReturnKeyNext];
    [txtFieldCountry setReturnKeyType:UIReturnKeyNext];
    [txtFieldCity setReturnKeyType:UIReturnKeyNext];
    [txtFieldState setReturnKeyType:UIReturnKeyNext];
    [txtFieldContactPerson setReturnKeyType:UIReturnKeyNext];
    [txtFieldDesignation setReturnKeyType:UIReturnKeyNext];
    [txtFieldPassword setReturnKeyType:UIReturnKeyNext];
    [txtFieldConfirmPassword setReturnKeyType:UIReturnKeyNext];
    if (checkRC) {
        [txtFieldOutletName setReturnKeyType:UIReturnKeyNext];
        [txtFieldNoOfOutlets setReturnKeyType:UIReturnKeyDone];
    } else {
        [txtFieldOutletName setReturnKeyType:UIReturnKeyDone];
    }
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnRCYesClicked:(id)sender{
    checkRC = YES;
    [btnRCYes setBackgroundImage:[UIImage imageNamed:@"radio-active.png"] forState:UIControlStateNormal];
    [btnRCNo setBackgroundImage:[UIImage imageNamed:@"radio-empty.png"] forState:UIControlStateNormal];
    txtFieldOutletName.hidden = NO;
    txtFieldNoOfOutlets.hidden = NO;
    imgOutletName.hidden = NO;

}

- (IBAction)btnRCNoClicked:(id)sender{
    checkRC = NO;
    [btnRCYes setBackgroundImage:[UIImage imageNamed:@"radio-empty.png"] forState:UIControlStateNormal];
    [btnRCNo setBackgroundImage:[UIImage imageNamed:@"radio-active.png"] forState:UIControlStateNormal];
    txtFieldOutletName.hidden = NO;
    txtFieldNoOfOutlets.hidden = YES;
    imgOutletName.hidden = YES;
}

- (IBAction)btnTermsAndConditionClicked:(id)sender{
    if([sender tag] == 101){
        [btnTermsAndCondition setTag:102];
        [btnTermsAndCondition setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
    else{
        [btnTermsAndCondition setTag:101];
        [btnTermsAndCondition setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
}
- (IBAction)btnSubmitClicked:(id)sender{
    if([txtFieldContactName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter contact name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtRegistrationId.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter company registration id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter email id" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if(![txtFieldPassword.text isEqualToString:txtFieldConfirmPassword.text]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Password not matched with confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldCountry.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter country" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldState.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter state" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldCity.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter city" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldContactNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter contact number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldContactPerson.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter name of contact person" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtFieldDesignation.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter designation" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if (checkRC) {
        if([txtFieldOutletName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter outlet name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
        else if([txtFieldNoOfOutlets.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter No of outlets" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
    }
    else if (!checkRC) {
        if([txtFieldOutletName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter outlet name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
        }
    }
    else if([btnTermsAndCondition tag] == 101){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please check and agree to terms and condition" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        
    }
}

- (IBAction)termsAndConditionLinkClicked:(id)sender{
    TermsAndConditionViewController *termsAndCondition = [[TermsAndConditionViewController alloc] initWithNibName:@"TermsAndConditionViewController" bundle:nil];
    [self.navigationController pushViewController:termsAndCondition animated:YES];
}

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,800, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    else{
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,1200, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
    if(isCountryPicker){
        selectedCountry = nil;
    }
    if(isStatePicker){
        selectedState = nil;
    }
    if(isCityPicker){
        selectedCity = nil;
    }
}
- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,800, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    else{
        [pickerBackgroundView setFrame:CGRectMake(pickerBackgroundView.frame.origin.x,1200, pickerBackgroundView.frame.size.width,pickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
    if(isCountryPicker){
    }
    if(isStatePicker){
    }
    if(isCityPicker){
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtFieldCountry){
        // Call Country Web Service here
        return NO;
    }
    else if(textField == txtFieldState){
        // Call state Web Service here
        return NO;
    }
    if(textField == txtFieldCity){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -50, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
        // Call city Web Service here
        return NO;
    }
    else if(textField == txtFieldContactNumber){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -100, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldAlternateContactNumber){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -150, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldContactPerson){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -200, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if(textField == txtFieldDesignation){
        [UIView beginAnimations:nil context:nil];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -250, self.view.frame.size.width,self.view.frame.size.height)];
        [UIView setAnimationDuration:0.5];
        [UIView commitAnimations];
    }
    else if (checkRC) {
        if(textField == txtFieldOutletName){
            [UIView beginAnimations:nil context:nil];
            [self.view setFrame:CGRectMake(self.view.frame.origin.x, -350, self.view.frame.size.width,self.view.frame.size.height)];
            [UIView setAnimationDuration:0.5];
            [UIView commitAnimations];
        }
        else if(textField == txtFieldNoOfOutlets){
            [UIView beginAnimations:nil context:nil];
            [self.view setFrame:CGRectMake(self.view.frame.origin.x, -400, self.view.frame.size.width,self.view.frame.size.height)];
            [UIView setAnimationDuration:0.5];
            [UIView commitAnimations];
        }
    }
    else if (!checkRC) {
        if(textField == txtFieldOutletName){
            [UIView beginAnimations:nil context:nil];
            [self.view setFrame:CGRectMake(self.view.frame.origin.x, -350, self.view.frame.size.width,self.view.frame.size.height)];
            [UIView setAnimationDuration:0.5];
            [UIView commitAnimations];
        }
    }

    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldContactName){
        [txtFieldContactName resignFirstResponder];
        [txtRegistrationId becomeFirstResponder];
    }
    else if(textField == txtRegistrationId){
        [txtRegistrationId resignFirstResponder];
        [txtFieldEmail becomeFirstResponder];
    }
    else if(textField == txtFieldEmail){
        [txtFieldEmail resignFirstResponder];
        [txtFieldAlternateEmail becomeFirstResponder];
    }
    else if(textField == txtFieldAlternateEmail){
        [txtFieldAlternateEmail resignFirstResponder];
        [txtFieldPassword becomeFirstResponder];
    }
    else if(textField == txtFieldPassword){
        [txtFieldPassword resignFirstResponder];
        [txtFieldConfirmPassword becomeFirstResponder];
    }
    else if(textField == txtFieldConfirmPassword){
        [txtFieldConfirmPassword resignFirstResponder];
        [txtFieldCountry becomeFirstResponder];
    }
    else if(textField == txtFieldCountry){
        [txtFieldCountry resignFirstResponder];
        [txtFieldState becomeFirstResponder];
    }
    else if(textField == txtFieldState){
        [txtFieldState resignFirstResponder];
        [txtFieldCity becomeFirstResponder];
    }
    else if(textField == txtFieldCity){
        [txtFieldCity resignFirstResponder];
        [txtFieldContactNumber becomeFirstResponder];
    }
    else if(textField == txtFieldContactNumber){
        [txtFieldContactNumber resignFirstResponder];
        [txtFieldAlternateContactNumber becomeFirstResponder];
    }
    else if(textField == txtFieldAlternateContactNumber){
        [txtFieldAlternateContactNumber resignFirstResponder];
        [txtFieldContactPerson becomeFirstResponder];
    }
    else if(textField == txtFieldContactPerson){
        [txtFieldContactPerson resignFirstResponder];
        [txtFieldDesignation becomeFirstResponder];
    }
    else if(textField == txtFieldDesignation){
        [txtFieldDesignation resignFirstResponder];
        [txtFieldOutletName becomeFirstResponder];
    }
    else if (checkRC) {
        if(textField == txtFieldOutletName){
            [txtFieldOutletName resignFirstResponder];
            [txtFieldNoOfOutlets becomeFirstResponder];
        }
        else if(textField == txtFieldNoOfOutlets){
            [txtFieldNoOfOutlets resignFirstResponder];
            [UIView beginAnimations:nil context:nil];
            [self.view setFrame:CGRectMake(self.view.frame.origin.x,0, self.view.frame.size.width,self.view.frame.size.height)];
            [UIView setAnimationDuration:0.5];
            [UIView commitAnimations];
        }
    }
    else if (!checkRC) {
        if(textField == txtFieldOutletName){
            [txtFieldOutletName resignFirstResponder];
            [UIView beginAnimations:nil context:nil];
            [self.view setFrame:CGRectMake(self.view.frame.origin.x,0, self.view.frame.size.width,self.view.frame.size.height)];
            [UIView setAnimationDuration:0.5];
            [UIView commitAnimations];
        }
    }

    return YES;
}



@end
