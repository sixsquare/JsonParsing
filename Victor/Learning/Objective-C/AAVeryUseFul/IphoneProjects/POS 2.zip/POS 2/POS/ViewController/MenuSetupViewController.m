//
//  MenuSetupViewController.m
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "MenuSetupViewController.h"


@implementation MenuSetupViewController

@synthesize txtCategory;
@synthesize txtProduct;
@synthesize txtType;
@synthesize txtProductName;
@synthesize txtProductDescription;
@synthesize txtCurrency;
@synthesize txtPrice;
@synthesize txtIngredients;
@synthesize txtImageUpload;
@synthesize imagePickerPopoverController;
@synthesize btnUpload;
@synthesize pickerBackground;
@synthesize picker;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (IBAction)uploadButtonClicked:(id)sender{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePickerPopoverController = [[UIPopoverController alloc] initWithContentViewController:imagePicker];
    [imagePickerPopoverController presentPopoverFromRect:btnUpload.frame
                                                  inView:self.view
                                permittedArrowDirections:UIPopoverArrowDirectionAny
                                                animated:YES];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *finalImage = nil;
    NSString *stringPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0];
    NSError *error = nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:stringPath])
        [[NSFileManager defaultManager] createDirectoryAtPath:stringPath withIntermediateDirectories:NO attributes:nil error:&error];
    
    NSString *fileName = [stringPath stringByAppendingFormat:@"/profile.png"];
    [txtImageUpload setText:fileName];
    NSData *data = UIImagePNGRepresentation(finalImage);
    [data writeToFile:fileName atomically:YES];
    
    [imagePickerPopoverController dismissPopoverAnimated:YES];
}

- (IBAction)saveButtonClicked:(id)sender{
    if([txtCategory.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select product category" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtProduct.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select product" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtProductName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter product name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtProductDescription.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter product description" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtCurrency.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please select currency" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else if([txtPrice.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter price" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Product Uploaded Successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(txtCategory == textField){
        return NO;
    }
    else if(txtProduct == textField){
        return NO;
    }
    else if(txtPrice == textField){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-100,self.view.frame.size.width,self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtProductName){
        [txtProductName resignFirstResponder];
        [txtProductDescription becomeFirstResponder];
    }
    return YES;
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    if(textView == txtIngredients){
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [self.view setFrame:CGRectMake(self.view.frame.origin.x,-200,self.view.frame.size.width,self.view.frame.size.height)];
        [UIView commitAnimations];
    }
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if([text isEqualToString:@"\n"]){
        [textView resignFirstResponder];
        if(textView == txtIngredients){
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.5];
            [self.view setFrame:CGRectMake(self.view.frame.origin.x,0,self.view.frame.size.width,self.view.frame.size.height)];
            [UIView commitAnimations];
        }
    }
    return YES;
}

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,800, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    else{
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,800, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    else{
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    [UIView commitAnimations];
}

- (void) selectedItems:(NSString *)items{
    NSLog(@"");
}
@end
