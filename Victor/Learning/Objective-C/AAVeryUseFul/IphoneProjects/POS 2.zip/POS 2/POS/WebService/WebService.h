//
//  WebService.h
//  HockeyApp
//
//  Created by Amit Parmar on 21/01/14.
//  Copyright (c) 2014 Ntech Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebService : NSObject

+(WebService *)sharedWebService;

// Country selection web services
- (void) callCountryWebService;
- (void) callStateWebService:(NSDictionary *)dictionary;
- (void) callCityWebService:(NSDictionary *)dictionary;

// Registration and login web services
- (void) callVendorRegistrationWebService:(NSDictionary *)dictionary;
- (void) callRestaurantRegistrationWebService:(NSDictionary *)dictionary;
- (void) callLoginWebService:(NSDictionary *)dictionary;


@end
