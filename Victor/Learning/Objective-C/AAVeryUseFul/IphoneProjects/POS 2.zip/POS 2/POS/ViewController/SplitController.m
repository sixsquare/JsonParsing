//
//  SplitController.m
//  POS
//
//  Created by N-tech Technologies on 2/13/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "SplitController.h"
#import "WaiterRegistrationViewController.h"
#import "RestaurantListViewController.h"
#import "MenuSetupViewController.h"
#import "DiscountViewController.h"
#import "TaxViewController.h"
#import "AppDelegate.h"
#import "TableManagementViewController.h"
#import "SurveySetupViewController.h"
#import "ReportsViewController.h"
#import "LoginViewController.h"
#import "CategoriesViewController.h"

@interface SplitController ()

@end

@implementation SplitController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIView* bview = [[UIView alloc] init];
    bview.backgroundColor = [UIColor blackColor];
    [self.tableView setBackgroundView:bview];
 
    UIImage *buttonImage = [UIImage imageNamed:@"back-button.png"];
    
    //create the button and assign the image
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    
    [button setFrame:CGRectMake(self.tableView.frame.origin.x-5,self.tableView.frame.origin.y-45,50,50)];
    [button addTarget:self action:@selector(clickActionItem:) forControlEvents:UIControlEventTouchUpInside];
    [self.tableView addSubview:button];
    self.tableView.contentInset = UIEdgeInsetsMake(30, 0, 0, 0);
}

-(void)clickActionItem:(id)sender
{
    LoginViewController *restaurantListViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:restaurantListViewController];
    [navController setNavigationBarHidden:YES];
    
    [AppDelegate delegete].window.rootViewController = navController;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 9;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
       cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell setBackgroundColor:[UIColor blackColor]];
    cell.textLabel.textColor = [UIColor whiteColor];
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"Restaurant Registration";
            break;
        case 1:
            cell.textLabel.text = @"Waiter Registration";
            break;
        case 2:
            cell.textLabel.text = @"Table/Layout Management";
            break;
        case 3:
            cell.textLabel.text = @"Menu Setup";
            break;
        case 4:
            cell.textLabel.text = @"Taxes & Vat Setup";
            break;
        case 5:
            cell.textLabel.text = @"Discount Setup";
            break;
        case 6:
            cell.textLabel.text = @"Survey Setup";
            break;
        case 7:
            cell.textLabel.text = @"Reports";
            break;
        case 8:
            cell.textLabel.text = @"Categories";
            break;

        default:
            break;
    }
    
    return cell;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 1){
        TableManagementViewController *tableManagementViewController = [[TableManagementViewController alloc] initWithNibName:@"TableManagementViewController" bundle:nil];
        tableManagementViewController.tableCount = [[alertView textFieldAtIndex:0].text intValue];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], tableManagementViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
}


- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    //forced clear color due to textlabel turning white after deselect
    [cell.contentView setBackgroundColor:[UIColor blackColor]];
    return indexPath;
}

- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [aTableView cellForRowAtIndexPath:indexPath];

    //forced clear color due to textlabel turning white after deselect
    [cell.contentView setBackgroundColor:[UIColor colorWithRed:0.29f green:0.29f blue:0.29f alpha:1.0f]];
    if (indexPath.row == 0) {
        RestaurantListViewController *restaurantListViewController = [[RestaurantListViewController alloc] initWithNibName:@"RestaurantListViewController" bundle:nil];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:restaurantListViewController];
        [navController setNavigationBarHidden:YES];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], navController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    } else if (indexPath.row == 1) {
        WaiterRegistrationViewController *waiterRegistrationViewController = [[WaiterRegistrationViewController alloc] initWithNibName:@"WaiterRegistrationViewController" bundle:nil];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], waiterRegistrationViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
    else if (indexPath.row == 2) {
        if([[NSUserDefaults standardUserDefaults] objectForKey:kStoredTableConfiguration]){
            TableManagementViewController *tableManagementViewController = [[TableManagementViewController alloc] initWithNibName:@"TableManagementViewController" bundle:nil];
            NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], tableManagementViewController, nil];
            [AppDelegate delegete].splitViewController.viewControllers = newVCs;
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Enter Number of tables" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Cancel",@"Done", nil];
            [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
            [alert setTag:101];
            [alert show];
        }
    }
    else if (indexPath.row == 3) {
        MenuSetupViewController *menuSetupViewController = [[MenuSetupViewController alloc] initWithNibName:@"MenuSetupViewController" bundle:nil];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], menuSetupViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
    else if (indexPath.row == 4) {
        TaxViewController *taxViewController = [[TaxViewController alloc] initWithNibName:@"TaxViewController" bundle:nil];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], taxViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
    else if (indexPath.row == 5) {
        DiscountViewController *discountViewController = [[DiscountViewController alloc] initWithNibName:@"DiscountViewController" bundle:nil];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], discountViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
    else if (indexPath.row == 6) {
        SurveySetupViewController *discountViewController = [[SurveySetupViewController alloc] initWithNibName:@"SurveySetupViewController" bundle:nil];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], discountViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
    else if (indexPath.row == 7) {
        ReportsViewController *reportsViewController = [[ReportsViewController alloc] initWithNibName:@"ReportsViewController" bundle:nil];
        NSArray *newVCs = [NSArray arrayWithObjects:[[AppDelegate delegete].splitViewController.viewControllers objectAtIndex:0], reportsViewController, nil];
        [AppDelegate delegete].splitViewController.viewControllers = newVCs;
    }
    else if (indexPath.row == 8) {
        CategoriesViewController *categoriesViewController = [[CategoriesViewController alloc] initWithNibName:@"CategoriesViewController" bundle:nil];
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:categoriesViewController];
        [navController setNavigationBarHidden:YES];
        [AppDelegate delegete].window.rootViewController = navController;
    }
}


@end
