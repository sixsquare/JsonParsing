//
//  PickerViewController.h
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PickerViewControllerDelegate <NSObject>

- (void) selectedItems:(NSString *)items;

@end

@interface PickerViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITableView *tblView;
@property (nonatomic, strong) NSArray *itemsArray;
@property (nonatomic, strong) NSArray *selectedArray;
@property (nonatomic ,strong) id <PickerViewControllerDelegate> pickerViewControllerDelegate;

- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;

@end
