//
//  TableManagementViewController.h
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableManagementViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic) int tableCount;

- (IBAction) addTableButtonClicked:(id)sender;

@end
