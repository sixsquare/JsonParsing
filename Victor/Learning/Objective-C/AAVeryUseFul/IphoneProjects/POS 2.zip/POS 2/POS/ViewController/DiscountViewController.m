//
//  DiscountViewController.m
//  POS
//
//  Created by N-tech Technologies on 2/14/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "DiscountViewController.h"
#import "PickerViewController.h"

@interface DiscountViewController ()

@end

@implementation DiscountViewController
@synthesize txtDiscountName;
@synthesize txtDiscountPercent;
@synthesize txtProducts;
@synthesize btnSave;
@synthesize popOver;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

-(IBAction)btnSaveClicked:(id)sender{
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    PickerViewController *pickerViewController = [[PickerViewController alloc] initWithNibName:@"PickerViewController" bundle:nil];
    pickerViewController.itemsArray = [NSArray arrayWithObjects:@"Item1",@"Item2",@"Item3",@"Item4",@"Item5",@"Item6",@"Item7",@"Item8",@"Item9",@"Item10", nil];
    pickerViewController.pickerViewControllerDelegate = self;
    popOver = [[UIPopoverController alloc] initWithContentViewController:pickerViewController];
    [popOver presentPopoverFromRect:txtProducts.frame
                             inView:self.view
           permittedArrowDirections:UIPopoverArrowDirectionAny
                           animated:YES];
    return NO;
}

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (void) selectedItems:(NSString *)items{
    txtProducts.text = items;
    [popOver dismissPopoverAnimated:YES];
}

@end
