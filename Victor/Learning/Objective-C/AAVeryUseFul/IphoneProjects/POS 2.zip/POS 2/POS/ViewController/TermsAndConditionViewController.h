//
//  TermsAndConditionViewController.h
//  POS
//
//  Created by Ntech.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsAndConditionViewController : UIViewController <UISplitViewControllerDelegate>

@property(nonatomic, strong) IBOutlet UIWebView *webView;
- (IBAction)backButtonClicked:(id)sender;

@end
