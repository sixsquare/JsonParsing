//
//  AppConstants.h
//  POS
//
//  Created by Amit Parmar on 11/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#ifndef POS_AppConstants_h
#define POS_AppConstants_h

#define kAppTitle  @"POS"

#define kCountrySuccess @"CountrySuccess"
#define kCountryFail    @"CountryFail"
#define kStateSuccess   @"StateSuccess"
#define kStateFail      @"StateFail"
#define kCitySuccess    @"CitySuccess"
#define kCityFail       @"CityFail"

#define kLoginSuccess   @"LoginSuccess"
#define kLoginFail      @"LoginFail"

#define kVendorRegistrationSuccess @"VendorRegistrationSuccess"
#define kVendorRegistrationFail    @"VendorRegistrationFail"

#define kRestaurantSuccess  @"RestaurantSuccess"
#define kRestaurantFail     @"RestaurantFail"

#define kWaiterRegistration     @"RestaurantFail"
#define kRestaurantFail     @"RestaurantFail"
#define kRestaurantFail     @"RestaurantFail"
#define kRestaurantFail     @"RestaurantFail"

#define kStoredTableConfiguration @"TableConfiguration"

#endif
