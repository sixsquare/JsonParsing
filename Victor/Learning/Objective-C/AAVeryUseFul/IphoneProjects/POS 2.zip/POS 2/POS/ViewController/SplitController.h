//
//  SplitController.h
//  POS
//
//  Created by N-tech Technologies on 2/13/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplitController : UITableViewController
@property (nonatomic, weak) UIImageView *thumbnailImageView;

@end
