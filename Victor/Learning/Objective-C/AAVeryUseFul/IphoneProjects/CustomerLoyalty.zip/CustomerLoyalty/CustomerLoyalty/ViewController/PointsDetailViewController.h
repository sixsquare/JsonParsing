//
//  PointsDetailViewController.h
//  CustomerLoyalty
//
//  Created by Amit Parmar on 13/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PointsDetailViewController : UIViewController

- (IBAction)backButtonClicked:(id)sender;

@end
