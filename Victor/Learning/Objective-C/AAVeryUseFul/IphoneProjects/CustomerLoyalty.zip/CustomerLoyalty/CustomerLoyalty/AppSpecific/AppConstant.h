//
//  AppConstant.h
//  CustomerLoyalty
//
//  Created by Amit Parmar on 13/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#ifndef CustomerLoyalty_AppConstant_h
#define CustomerLoyalty_AppConstant_h

#define kAppTitle @"Customer Loyalty"

#endif
