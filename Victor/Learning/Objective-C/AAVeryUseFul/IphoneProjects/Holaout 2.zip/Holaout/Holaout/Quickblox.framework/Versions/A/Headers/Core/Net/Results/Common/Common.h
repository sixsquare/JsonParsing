/*
 *  Common.h
 *  BaseService
 *
 *
 */
#import "Base/Result.h"
#import "Task/TaskResult.h"
#import "Paged/PagedResult.h"
#import "Binary/BinaryResult.h"
