/*
 *  Query.h
 *  LocationService
 *
 
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "GeoData/QBGeoDataQueries.h"
#import "Places/QBPlacesQueries.h"