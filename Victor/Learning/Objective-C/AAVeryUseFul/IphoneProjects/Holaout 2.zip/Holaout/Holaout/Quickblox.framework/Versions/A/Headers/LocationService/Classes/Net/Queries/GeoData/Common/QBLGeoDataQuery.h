//
//  QBLGeoDataQuery.h
//  LocationService
//

//  Copyright 2011 QuickBlox  team. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface QBLGeoDataQuery : QBQuery {

}

@end