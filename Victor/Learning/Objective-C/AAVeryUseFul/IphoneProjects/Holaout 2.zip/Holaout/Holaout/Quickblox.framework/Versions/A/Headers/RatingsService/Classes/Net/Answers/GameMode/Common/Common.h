//
//  Common.h
//  Quickblox
//
//  Created by Igor Khomenko on 6/16/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Base/QBRGameModeAnswer.h"
#import "Paged/QBRGameModePagedAnswer.h"
