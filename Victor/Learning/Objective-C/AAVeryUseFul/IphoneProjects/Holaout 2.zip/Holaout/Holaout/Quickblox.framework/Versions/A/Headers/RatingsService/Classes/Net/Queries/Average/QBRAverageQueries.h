//
//  QBRAverageQueries.h
//  Quickblox
//
//  Created by Igor Khomenko on 6/22/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Common/QBRAverageQuery.h"
#import "Get/QBRAverageGetQuery.h"