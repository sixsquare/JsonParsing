/*
 *  EventQueries.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import "Common/QBMEventQuery.h"
#import "Create/QBMEventCreateQuery.h"
#import "Get/QBMEventGetQuery.h"
#import "Update/QBMEventUpdateQuery.h"
#import "Delete/QBMEventDeleteQuery.h"
