//
//  Enums.h
//  RatingsService
//
//  Created by Andrey Kozlov on 4/13/11.
//  Copyright 2011 QuickBlox. All rights reserved.
//

enum QBRScoreSortByKind {
	ScoreSortByKindNone,
	ScoreSortByKindCreatedAt,
	ScoreSortByKindValue,
};