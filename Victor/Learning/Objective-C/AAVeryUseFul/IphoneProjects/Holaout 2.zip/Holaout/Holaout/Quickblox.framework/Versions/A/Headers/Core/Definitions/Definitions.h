/*
 *  Definitions.h
 *  BaseService
 *
 *
 */
#import "Enums.h"
#import "Consts.h"
#import "Delegates.h"
#import "Macro.h"

