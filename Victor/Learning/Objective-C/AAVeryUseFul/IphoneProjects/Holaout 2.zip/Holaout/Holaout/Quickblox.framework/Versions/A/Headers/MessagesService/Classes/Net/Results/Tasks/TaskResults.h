/*
 *  TaskResults.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import "GetToken/QBMGetTokenTaskResult.h"
#import "RegisterSubscription/QBMRegisterSubscriptionTaskResult.h"
#import "SendPush/QBMSendPushTaskResult.h"
#import "UnregisterSubscription/QBMUnregisterSubscriptionTaskResult.h"
