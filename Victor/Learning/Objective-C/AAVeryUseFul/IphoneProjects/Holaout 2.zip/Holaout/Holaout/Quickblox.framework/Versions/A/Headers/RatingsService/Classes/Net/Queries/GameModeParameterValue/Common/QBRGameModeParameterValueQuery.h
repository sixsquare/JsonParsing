//
//  QBRGameModeParameterValueQuery.h
//  RatingsService
//
//  Created by Igor Khomenko on 6/25/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QBRGameModeParameterValueQuery : QBQuery

@end
