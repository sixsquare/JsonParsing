/*
 *  Tasks.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import "GetTokenPerformer/QBMGetTokenPerformer.h"
#import "Subscription/QBMRegisterSubscriptionTask.h"
#import "SendPush/QBMSendPushTask.h"
#import "Subscription/QBMUnregisterSubscriptionTask.h"
