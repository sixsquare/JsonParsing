/*
 *  PushToken.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "Common/QBMPushTokenQuery.h"
#import "Create/QBMPushTokenCreateQuery.h"
#import "Delete/QBMPushTokenDeleteQuery.h"
