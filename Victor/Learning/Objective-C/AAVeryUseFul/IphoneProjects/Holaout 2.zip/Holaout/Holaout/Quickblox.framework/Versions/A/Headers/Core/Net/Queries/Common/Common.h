/*
 *  Common.h
 *  BaseService
 *
 *
 */

#import "Base/QBQuery.h"
#import "Paged/PagedQuery.h"