//
//  Common.h
//  Quickblox
//
//  Created by mac user on 2/25/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Base/QBLPlaceAnswer.h"
#import "Paged/QBLPlacePagedAnswer.h"
