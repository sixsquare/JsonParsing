/*
 *  Net.h
 *  BaseService
 *
 *
 */

#import "REST/REST.h"
#import "Answers/Answers.h"
#import "Queries/Queries.h"
#import "Requests/Requests.h"
#import "Results/Results.h"
#import "Tasks/Tasks.h"
#import "Server/Server.h"
