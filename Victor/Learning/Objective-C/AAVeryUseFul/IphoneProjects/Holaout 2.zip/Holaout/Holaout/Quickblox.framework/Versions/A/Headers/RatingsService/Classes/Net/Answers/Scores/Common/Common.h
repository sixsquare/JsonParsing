//
//  Common.h
//  Quickblox
//
//  Created by Igor Khomenko on 6/22/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Base/QBRScoreAnswer.h"
#import "Paged/QBRScorePagedAnswer.h"