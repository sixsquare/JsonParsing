//
//  QBDeviceUDIDHelper.h
//  Quickblox
//
//  Created by Igor Khomenko on 11/16/13.
//  Copyright (c) 2013 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QBDeviceUDIDHelper : NSObject

+ (NSString *)deviceUDID;

@end
