/*
 *  Subscription.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "Common/QBMSubscriptionQuery.h"
#import "Create/QBMSubscriptionCreateQuery.h"
#import "Delete/QBMSubscriptionDeleteQuery.h"
#import "Get/QBMSubscriptionGetQuery.h"
