//
//  QBArrayToStringHelper.h
//  Quickblox
//
//  Created by IgorKh on 3/12/13.
//  Copyright (c) 2013 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QBArrayToStringHelper : NSObject

+ (NSString *)convert:(NSArray *)array;

@end
