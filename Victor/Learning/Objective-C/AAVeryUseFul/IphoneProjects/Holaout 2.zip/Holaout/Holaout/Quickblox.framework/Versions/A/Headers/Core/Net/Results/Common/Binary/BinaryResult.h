//
//  BinaryResult.h
//  BaseService
//
//

#import <Foundation/Foundation.h>


@interface BinaryResult : Result {

}
@property (nonatomic,readonly) NSData* data;
@end
