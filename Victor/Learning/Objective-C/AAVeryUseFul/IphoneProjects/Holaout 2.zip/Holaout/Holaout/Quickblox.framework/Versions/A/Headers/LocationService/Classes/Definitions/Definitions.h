/*
 *  Definitions.h
 *  LocationService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */


#import "Enums.h"
#import "Structs.h"
#import "GPConst/QBLGPConst.h"
#import "Consts.h"