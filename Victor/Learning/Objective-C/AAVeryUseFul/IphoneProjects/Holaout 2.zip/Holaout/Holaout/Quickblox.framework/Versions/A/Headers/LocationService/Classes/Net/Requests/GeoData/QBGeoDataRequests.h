/*
 *  QBGeoDataRequests.h
 *  LocationService
 *
 
 *  Copyright 2011 Quickblox team. All rights reserved.
 *
 */

#import "Get/QBLGeoDataGetRequest.h"
#import "Delete/QBLGeoDataDeleteRequest.h"
