//
//  Server.h
//  Quickblox
//
//  Created by IgorKh on 8/14/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "CustomObjects/QBCustomObjects.h"
