//
//  Common.h
//  Quickblox
//
//  Created by IgorKh on 8/17/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Base/QBCOCustomObjectResult.h"
#import "Base/QBCOMultiDeleteResult.h"
#import "Paged/QBCOCustomObjectPagedResult.h"
