/*
 *  Answer.h
 *  AuthService
 *

 *  Copyright 2010 Mob1serv team. All rights reserved.
 *
 */

#import "Auth/Auth.h"