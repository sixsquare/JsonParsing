/*
 *  QBGeoDataAnswers.h
 *  LocationService
 *
 
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "Common/Common.h"

