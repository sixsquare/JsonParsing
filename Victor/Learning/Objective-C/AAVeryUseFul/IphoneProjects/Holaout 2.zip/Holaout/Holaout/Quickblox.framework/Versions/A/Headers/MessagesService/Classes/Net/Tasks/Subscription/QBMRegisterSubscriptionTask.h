//
//  QBMRegisterSubscriptionTask.h
//  MessagesService
//

//  Copyright 2011 QuickBlox team. All rights reserved.
//

@interface QBMRegisterSubscriptionTask : Task {
}

@end
