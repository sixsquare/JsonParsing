//
//  QBMUnregisterSubscriptionTask.h
//  Quickblox
//
//  Created by Ruslan on 9/3/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

@interface QBMUnregisterSubscriptionTask : Task{
}

@end
