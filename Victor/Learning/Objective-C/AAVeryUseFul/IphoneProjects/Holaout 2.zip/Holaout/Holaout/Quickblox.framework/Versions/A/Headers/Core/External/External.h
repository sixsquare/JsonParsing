/*
 *  External.h
 *  BaseService
 *
 *
 */

#import "Novocaine/QBAudioIOService.h"
#import "AFNetworking-1.x/AFNetworking/QBAFNetworking.h"
#import "AFNetworking-1.x/QBAPIClient.h"