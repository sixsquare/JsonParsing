/*
 *  ChatServiceFramework.h
 *  ChatService
 *
 
 *  Copyright 2012 QuickBlox team. All rights reserved.
 *
 */

#import "Classes/Classes.h"