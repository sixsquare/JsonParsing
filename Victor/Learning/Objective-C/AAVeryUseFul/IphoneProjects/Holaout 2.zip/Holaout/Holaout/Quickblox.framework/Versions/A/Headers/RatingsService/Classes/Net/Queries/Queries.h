//
//  Query.h
//  QuickBlox
//
//  Created by Andrey Kozlov on 4/13/11.
//  Copyright 2011 QuickBlox. All rights reserved.
//

#import "GameMode/QBRGameModeQueries.h"
#import "Scores/Scores.h"
#import "Average/QBRAverageQueries.h"
#import "GameModeParameterValue/QBRGameModeParameterValueQueries.h"