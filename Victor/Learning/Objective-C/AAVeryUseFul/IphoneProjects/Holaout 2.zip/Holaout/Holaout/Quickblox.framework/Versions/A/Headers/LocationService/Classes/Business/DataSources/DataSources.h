/*
 *  DataSources.h
 *  LocationService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import "Location/QBLLocationDataSource.h"