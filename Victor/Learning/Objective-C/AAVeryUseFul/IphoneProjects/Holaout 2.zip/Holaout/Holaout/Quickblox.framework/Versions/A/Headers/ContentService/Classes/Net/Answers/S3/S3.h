/*
 *  S3.h
 *  ContentService
 *
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "Common/QBCS3Answer.h"
#import "Post/QBCS3PostAnswer.h"

