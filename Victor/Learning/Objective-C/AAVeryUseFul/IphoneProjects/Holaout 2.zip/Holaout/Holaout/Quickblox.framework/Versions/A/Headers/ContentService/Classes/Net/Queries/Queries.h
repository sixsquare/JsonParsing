//
//  Queries.h
//  ContentService
//
//  Copyright 2010 QuickBlox team. All rights reserved.
//

#import "Blob/BlobQueries.h"
#import "BlobObjectAccess/BlobObjectAccessQueries.h"