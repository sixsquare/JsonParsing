/*
 *  Defnitions.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import "Consts.h"
#import "Enums.h"
