//
//  BlobQuery.h
//  ContentService
//
//  Copyright 2011 QuickBlox team. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QBCBlobQuery : QBQuery {

}

@end