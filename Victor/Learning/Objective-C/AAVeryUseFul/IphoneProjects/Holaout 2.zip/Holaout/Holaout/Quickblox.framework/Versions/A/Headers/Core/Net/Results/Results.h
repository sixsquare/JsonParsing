/*
 *  Results.h
 *  BaseService
 *
 *
 */

#import "Common/Common.h"