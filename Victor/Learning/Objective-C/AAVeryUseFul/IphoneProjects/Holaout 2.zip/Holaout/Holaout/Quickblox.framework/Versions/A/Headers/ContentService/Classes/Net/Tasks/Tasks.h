/*
 *  Tasks.h
 *  Core
 *
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "DownloadFile/QBCFileDownloadTask.h"
#import "UploadFile/QBCFileUploadTask.h"
#import "UpdateFile/QBCFileUpdateTask.h"


