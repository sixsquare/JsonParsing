/*
 *  Queries.h
 *  AuthService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import "Auth/Auth.h"

