/*
 *  Results.h
 *  AuthService
 *

 *  Copyright 2010 Quickblox team. All rights reserved.
 *
 */

#import "Auth/Auth.h"
