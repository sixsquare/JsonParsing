//
//  QBMSubscriptionQuery.h
//  MessagesService
//

//  Copyright 2010 QuickBlox team. All rights reserved.
//

@interface QBMSubscriptionQuery : QBQuery {

}

@end
