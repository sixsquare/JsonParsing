//
//  Queries.h
//  Quickblox
//
//  Created by IgorKh on 8/14/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "CustomObject/CustomObject.h"
#import "Permissions/Permissions.h"
#import "File/File.h"