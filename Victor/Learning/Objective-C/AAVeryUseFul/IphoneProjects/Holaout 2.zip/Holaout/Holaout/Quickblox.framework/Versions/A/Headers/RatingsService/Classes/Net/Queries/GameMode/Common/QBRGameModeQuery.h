//
//  QBRGameModeQuery.h
//  RatingsService
//
//  Created by Igor Khomenko on 6/7/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QBRGameModeQuery : QBQuery{
    
}

@end
