//
//  Structs.h
//  LocationService
//

//  Copyright 2011 QuickBlox team. All rights reserved.
//

struct QBLGeoDataRect{
	CLLocationCoordinate2D coord1;
	CLLocationCoordinate2D coord2;
};