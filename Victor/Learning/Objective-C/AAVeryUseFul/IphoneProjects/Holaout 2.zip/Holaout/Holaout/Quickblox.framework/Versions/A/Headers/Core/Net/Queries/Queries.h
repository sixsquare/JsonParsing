/*
 *  Queries.h
 *  BaseService
 *
 *
 */
#import "Common/Common.h"
