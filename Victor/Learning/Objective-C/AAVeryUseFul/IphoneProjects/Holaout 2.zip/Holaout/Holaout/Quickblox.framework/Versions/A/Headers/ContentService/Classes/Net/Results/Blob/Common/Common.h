//
//  Common.h
//  ContentService
//
//  Created by Igor Khomenko on 7/12/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Base/QBCBlobResult.h"
#import "Paged/QBCBlobPagedResult.h"
