/*
 *  Common.h
 *  BaseService
 *
 *
 */

#import "Base/Request.h"
#import "Paged/PagedRequest.h"