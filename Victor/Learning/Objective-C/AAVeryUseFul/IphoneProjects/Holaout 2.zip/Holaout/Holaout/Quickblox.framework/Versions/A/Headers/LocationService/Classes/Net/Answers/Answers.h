/*
 *  Answer.h
 *  LocationService
 *
 
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import "GeoData/QBGeoDataAnswers.h"
#import "Place/QBPlaceAnswers.h"