//
//  CustomObjects.h
//  Quickblox
//
//  Created by IgorKh on 8/15/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Common/Common.h"
