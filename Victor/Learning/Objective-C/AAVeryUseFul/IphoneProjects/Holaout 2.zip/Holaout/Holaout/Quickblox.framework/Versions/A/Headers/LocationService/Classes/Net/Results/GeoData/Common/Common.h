//
//  Common.h
//  LocationService
//
//  Created by Igor Khomenko on 2/4/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import "Base/QBLGeoDataResult.h"
#import "Paged/QBLGeoDataPagedResult.h"