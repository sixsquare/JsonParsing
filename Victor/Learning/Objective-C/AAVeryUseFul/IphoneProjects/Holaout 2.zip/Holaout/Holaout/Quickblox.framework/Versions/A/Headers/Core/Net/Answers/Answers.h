/*
 *  Answers.h
 *  BaseService
 *
 *
 */

#import "Common/Common.h"
#import "Entity/EntityAnswer.h"