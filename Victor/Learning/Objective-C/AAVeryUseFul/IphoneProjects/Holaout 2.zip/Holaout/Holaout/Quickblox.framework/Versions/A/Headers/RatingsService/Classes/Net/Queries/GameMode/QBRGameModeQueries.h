//
//  QBRGameModeQueries.h
//  RatingsService
//
//  Created by Andrey Kozlov on 4/15/11.
//  Copyright 2011 QuickBlox. All rights reserved.
//

#import "Common/QBRGameModeQuery.h"
#import "Create/QBRGameModeCreateQuery.h"
#import "Delete/QBRGameModeDeleteQuery.h"
#import "Get/QBRGameModeGetQuery.h"
#import "Update/QBRGameModeUpdateQuery.h"